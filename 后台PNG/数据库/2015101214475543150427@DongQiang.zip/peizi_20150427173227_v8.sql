
 /* 插入数据 `lzh_article_category` */
 INSERT INTO `lzh_article_category` VALUES ('8','关于我们','','','','<div><img style=\"margin: 10px; width: 360px; float: right; height: 256px\" alt=\"\" src=\"/UF/Uploads/Article/20131125183424.gif\" /> 　　XXX网站隶属于XXXXXX管理有限公司。XXXXXX经工商局登记注册于2013年成立，注册资本1000万。位于XXXXXXXXXXXXXXXXXXXXXXXXX。是目前XX地区最安全、最专业的网络信贷理财平台之一</div><div>XXXX顺应全球电子商务未来发展的趋势，充分挖掘互联网金融市场潜力，通过建立一个安全、高效、诚信、互惠互助的网络借贷平台，让人们有机会相互帮助实现双赢的结果，帮助投资者及创业者更好地应对目前世界金融危机影响下的经济困境。</div><div>我们深信，依赖现代网络创新技术将民间借贷引入的模式，定会在快捷、便利、透明的体系下得到更健康的发展，并实现利益最大化！</div><div>XXXXX严格遵守国家相关法律法规，并敦促其会员在信息发布和使用过程中严格遵守相关法规。同时，我们也将竭尽所能，不断完善对网站平台的管理！</div><div>让我们携起手来，愿您的财富同xxxx一起成长！</div><div>愿您的创业梦想，在盛世下飞翔！</div><div>&nbsp;</div><div><div><strong><span style=\"font-size: 24px\">P2P平台介绍</span></strong></div><div>XXXXX采用创新的技术和理念，通过互联网建立一个安全、高效、诚信的平台，规范了个人之间的借贷行为，使之更加安全、有效。让人们有机会得到帮助，以及帮助到需要的朋友，同时得到更好的回报。</div><div>现实中朋友家人之间往往由于面子等问题不方便借款以及不好意思催款。XXXXX鼓励大家通过这一平台来帮助解决这些问题。另外，如果朋友家人正好没有钱帮您，而朋友的朋友很可能有闲钱，大家通过人人聚财这个平台就可传递这种信赖关系,扩大信赖的朋友圈子，解决自己的问题。</div><div>通过下面图片可以了解XXXXX如何工作的：需要钱的人发布信息，其他人以竞标方式参与，聚合大众的力量，以市场化的方式决定利率，以及监督借款行为。</div><div style=\"text-align: center\">&nbsp;<img style=\"margin: 0px; float: none\" alt=\"\" src=\"/UF/Uploads/Article/20131125182918.gif\" /></div><div><strong><span style=\"font-size: 24px\">平成立目的台</span></strong></div><div>为有需要帮助的人伸出援手！为有能力的人实现资产增值！让我们成为成功路上最好的伙伴！&nbsp;</div><div>&nbsp;</div><div><strong><span style=\"font-size: 24px\">愿景</span></strong></div><div>打造一个全民参与、安全、高效、诚信、互惠互利的互联网金融服务平台</div><div>&nbsp;</div></div>','2','1','0','aboutus','1','1386379033','0','article');/* DBReback Separation */
 /* 插入数据 `lzh_article_category` */
 INSERT INTO `lzh_article_category` VALUES ('7','担保机构','','','','','3','1','0','danbao','1','1386326249','0','article');/* DBReback Separation */
 /* 插入数据 `lzh_article_category` */
 INSERT INTO `lzh_article_category` VALUES ('9','网站公告','','','','','10','1','0','gonggao','0','1389929083','0','article');/* DBReback Separation */
 /* 插入数据 `lzh_article_category` */
 INSERT INTO `lzh_article_category` VALUES ('10','财融天下','','','','<div class=\"lk aus-box\"><div class=\"main\"><div class=\"title\"><img src=\"/Style/H/1/Stock/img/aus-tit1.png\" /></div><div class=\"cont\" style=\"text-align:left;\">&nbsp;&nbsp;&nbsp; “财融天下”是北京淘伟科技有限公司（简称“淘伟科技”，www.taoweikeji.com）旗下独立运营的互联网配资服务平台。由业内资深互联网精英及研发工程师共同组建而成，是淘伟科技倾力打造，独立研发的多元化配资服务平台。将互联网配资服务与投资理财服务相结合，致力于为广大股民、投资者轻松实现股票配资，财富增值，让您的配资简单化，理财自由化，盈利放大化。<br /> &nbsp;&nbsp;&nbsp;&nbsp; 我们只专注互联网服务垂直领域，有多年的开发运营经验，将互联网产品做到多元化、细分化、极致化。与传统的线下配资相比，“财融天下”摆脱了：超高的利息、地域的限制、繁杂的操作、低效死板的风控，从而实现了资本与投资机会的高效整合。通过配资平台，您可以实时快捷的获得1-10倍杠杆率，瞬间放大您的操盘资金，获得高收益。<br /> &nbsp;&nbsp;&nbsp;&nbsp; 在风控方面，我们从法律安全保障、资金安全保障和信息安全保障三大板块入手，层层审核，层层筛选，确保项目风控与投资者的投资安全为，做您身边最专业的互联网配资服务平台。</div></div></div><div class=\"lk aus-box\"><div class=\"main\"><div class=\"title\"><img src=\"/Style/H/1/Stock/img/aus-tit3.png\" /></div><div class=\"box\"><div class=\"div\"><div class=\"img\"><img alt=\"\" src=\"/Style/H/1/Stock/img/aus-icoo1.png\" /></div><div>资金优势</div><p>对客户交易资金的管理完全按照\"专户专款专用\"的标准模式进行运作，采用第三方合作机构进行监管。</p></div><div class=\"div\"><div class=\"img\"><img alt=\"\" src=\"/Style/H/1/Stock/img/aus-icoo2.png\" /></div><div>软件优势</div><p>客户可通过下载恒生电子提供的客户端进行股票交易，交易委托通过恒生电子交易系统实时进入合作券商在市场上成交，确保交易安全、快捷。</p></div><div class=\"div\"><div class=\"img\"><img alt=\"\" src=\"/Style/H/1/Stock/img/aus-icoo3.png\" /></div><div>服务优势</div><p>低门槛最低1000元起即可配资，最高300万。高收益高杠杆率，最高可放大到10倍。费率灵活，可根据不同的费率配资不同的金额。</p></div></div></div></div><p><br /><br />&nbsp;</p><p>&nbsp;</p>','10','0','8','jianjie','0','1389931247','0','article');/* DBReback Separation */
 /* 插入数据 `lzh_article_category` */
 INSERT INTO `lzh_article_category` VALUES ('11','公司证件','','','','<p>&nbsp; <img alt=\"\" style=\"float:none;margin:0px;\" src=\"/UF/Uploads/Article/20150407175123.jpg\" />&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; <img alt=\"\" style=\"float:none;margin-left:80px;\" src=\"/UF/Uploads/Article/20150407175134.jpg\" /></p>','0','0','8','zizhi','1','1389931315','0','article');/* DBReback Separation */
 /* 插入数据 `lzh_article_category` */
 INSERT INTO `lzh_article_category` VALUES ('16','资费说明','','','','<p><span style=\"color:#f90;\"><strong>投资人资费说明</strong></span></p><p>1.&nbsp;利息管理费5%；（新上线初期免费）<br />2.&nbsp;低于20000元以下的提现每笔2元，20000元以上提现每笔3元，单次提现限额50000，每天提现金额不限；（新上线初期免费）<br />3. 非投标回款以及充值15天内提现的收取0.5%手续费。<br />4.&nbsp;投资人线上充值暂无奖励；<br />5.&nbsp;线下充值奖励：单笔充值金额大于等于5000元充值返现0.2%，充值金额大于等于20000元返现0.25%，充值金额大于等于50000元返现0.3%；推荐返现0.1%，以被推荐人实际投标金额计算；到期回款金额续投三月标以内（不含三月标）返现0.1%，续投三月标以上（含三月标）返现0.2%。</p><p>&nbsp;</p><p><span style=\"color:#f90;\"><strong>借款人资费说明</strong></span></p><p>1.&nbsp;平台成交服务费3%。<br />2.&nbsp;综合担保费2% 综合担保费用包含为借款人提供担保、顾问咨询、介绍等服务。<br />3.&nbsp;充值费用：线上0.2%手续费，线下以银行实际扣费为主；<br />4.&nbsp;VIP认证费用150元/年；<br />5.&nbsp;借款管理费，每月收取借款总额0.5%<br />6.&nbsp;现场评估费：本地1%，异地2%。<br />7.&nbsp;逾期第二天由平台垫付本息，对借款人每天加收0.1%罚息。如超过10天仍未还款由工作人员上门催收另收本金1%催收费。</p>','0','0','8','zfsm','1','1389940055','0','article');/* DBReback Separation */
 /* 插入数据 `lzh_article_category` */
 INSERT INTO `lzh_article_category` VALUES ('17','政策法规','','','','<p>&nbsp;</p><p style=\"text-align:center;margin:0cm 0cm 0pt;\" align=\"center\"><span style=\"color:#f00;\"><strong><span style=\"font-family:宋体;font-size:15pt;\">相关政策法规</span></strong></span></p><p style=\"text-align:left;margin:0cm 0cm 0pt;\" align=\"left\"><font size=\"3\"><span style=\"font-family:宋体;color:#333333;\">1</span><span style=\"font-family:宋体;color:#333333;\">、<span style=\"color:#f90;\"><strong>民间借贷受法律保护</strong></span></span></font></p><p style=\"text-align:left;text-indent:21pt;margin:0cm 0cm 0pt;\" align=\"left\"><span style=\"font-family:宋体;color:#333333;\"><font size=\"3\">民间借贷是指公民之间、公民与法人之间、公民与其它组织之间的借贷。只要双方当事人意思表示真实即可认定有效，因借贷产生的抵押相应有效，但利率不得超过人民银行规定的相关利率。民间借贷是一种直接融资渠道，银行借贷则是一种间接融资渠道。民间借贷是民间资本的一种投资渠道，是民间金融的一种形式。</font></span></p><p style=\"text-align:left;text-indent:21pt;margin:0cm 0cm 0pt;\" align=\"left\"><span style=\"font-family:宋体;color:#333333;\"><font size=\"3\">《合同法》和《最高人民法院关于人民法院审理借贷案件的若干意见》从法律上肯定了民间借贷行为的合法性，同时，可以采用第三方对借款提供担保的方式，保障出借人收回借款本金、利息的权利。民间借贷受法律保护。依据《最高人民法院关于人民法院审理借贷案件的若干意见》的规定，公民之间、公民与法人之间、公民与其他组织之间的借贷属于民间借贷，作为一种民事法律行为，在行为人具有完全民事行为能力（年满<span>18</span>周岁，且不存在足以影响自身行为的精神疾病的情形）、意思表示真实且不违反法律、行政法规禁止性规定的情况下，民间借贷受法律保护。<span> </span></font></span></p><p style=\"text-align:left;text-indent:21pt;margin:0cm 0cm 0pt;\" align=\"left\">&nbsp;</p><p style=\"text-align:left;margin:0cm 0cm 0pt;\" align=\"left\"><font size=\"3\"><span style=\"font-family:宋体;color:#333333;\">2</span><span style=\"font-family:宋体;color:#333333;\">、<strong><span style=\"color:#f90;\">利率规定</span></strong></span></font></p><p style=\"text-align:left;text-indent:21pt;margin:0cm 0cm 0pt;\" align=\"left\"><span style=\"font-family:宋体;color:#333333;\"><font size=\"3\">《合同法》第二百一十一条：自然人之间的借款合同对支付利息没有约定或者约定不明确的，视为不支付利息。自然人之间的借款合同约定支付利息的，借款的利率不得违反国家有关限制借款利率的规定。《最高人民法院关于人民法院审理借贷案件的若干意见》第六条：民间借贷的利率可以适当高于银行的利率，各地人民法院可根据本地区的实际情况具体掌握，但最高不得超过银行同类贷款利率的四倍（包含利率本数）。超出此限度的，超出部分的利息不予保护。<span> </span></font></span></p><p style=\"text-align:left;text-indent:21pt;margin:0cm 0cm 0pt;\" align=\"left\">&nbsp;</p><p style=\"text-align:left;margin:0cm 0cm 0pt;\" align=\"left\"><font size=\"3\"><span style=\"font-family:宋体;color:#333333;\">3</span><span style=\"font-family:宋体;color:#333333;\">、<span style=\"color:#f90;\"><strong>电子合同规定</strong></span></span></font></p><p style=\"text-align:left;text-indent:21pt;margin:0cm 0cm 0pt;\" align=\"left\"><span style=\"font-family:宋体;color:#333333;\"><font size=\"3\">《合同法》第二章第十条规定：当事人订立合同，有书面形式、口头形式和其他形式。第十一条规定：书面形式是指合同书、信件和数据电文（包括电报、电传、传真、电子数据交换和电子邮件）等可以有形地表现所载内容的形式。<span> </span></font></span></p><p style=\"text-align:left;margin:0cm 0cm 0pt;\" align=\"left\"><span style=\"font-family:宋体;color:#333333;\"><font size=\"3\">&nbsp;</font></span></p><p style=\"text-align:left;margin:0cm 0cm 0pt;\" align=\"left\"><font size=\"3\"><span style=\"font-family:宋体;color:#333333;\">4</span><span style=\"font-family:宋体;color:#333333;\">、<span style=\"color:#f90;\"><strong>担保规定</strong></span></span></font></p><p style=\"text-align:left;text-indent:21pt;margin:0cm 0cm 0pt;\" align=\"left\"><span style=\"font-family:宋体;color:#333333;\"><font size=\"3\">《合同法》第一百九十八条订立借款合同，贷款人可以要求借款人提供担保。担保依照《中华人民共和国担保法》的规定。《最高人民法院关于人民法院审理借贷案件的若干意见》第十三条：在借贷关系中，仅起联系、介绍作用的人，不承担保证责任。对债务的履行确有保证意思表示的，应认定为保证人，承担保证责任。<span> </span></font></span></p><p style=\"text-align:left;margin:0cm 0cm 0pt;\" align=\"left\"><span style=\"font-family:宋体;color:#333333;\"><font size=\"3\">&nbsp;</font></span></p><p style=\"text-align:left;margin:0cm 0cm 0pt;\" align=\"left\"><font size=\"3\"><span style=\"font-family:宋体;color:#333333;\">5</span><span style=\"font-family:宋体;color:#333333;\">、<span style=\"color:#f90;\"><strong>居间平台收费规定</strong></span></span></font></p><p style=\"text-align:left;text-indent:21pt;margin:0cm 0cm 0pt;\" align=\"left\"><span style=\"font-family:宋体;color:#333333;\"><font size=\"3\">《合同法》第二十三章“居间合同”中第四百二十六条规定：居间人促成合同成立的，委托人应当按照约定支付报酬。对居间人的报酬没有约定或者约定不明确，依照本法第六十一条的规定仍不能确定的，根据居间人的劳务合理确定。因此贷款服务机构的存在和服务费的收取都是符合法律规定并受法律保护的。盛世汇盈既不吸储，也不放贷，作为一个网络信用管理及借贷服务中介机构，其业务范围和经营活动完全符合相关法律和国家的政策规定。盛世汇盈将在国家法律和相关政策的指引下，为广大借款人、出借人提供优质、高效的服务。</font></span></p><p style=\"text-align:left;text-indent:21pt;margin:0cm 0cm 0pt;\" align=\"left\"><span style=\"font-family:宋体;color:#333333;\"><font size=\"3\">&nbsp;</font></span></p>','0','0','8','zcfgd','1','1389940204','0','article');/* DBReback Separation */
 /* 插入数据 `lzh_article_category` */
 INSERT INTO `lzh_article_category` VALUES ('21','安全保障','','','','<p><img style=\"float:none;margin:0px;\" alt=\"\" src=\"/UF/Uploads/Article/20140721160415.jpg\" /></p><p><img style=\"float:none;margin:0px;\" alt=\"\" src=\"/UF/Uploads/Article/20140721160428.jpg\" /></p>','6','1','0','anquan','1','1405929442','0','article');/* DBReback Separation */
 /* 插入数据 `lzh_article_category` */
 INSERT INTO `lzh_article_category` VALUES ('28','联系我们','','','','<p>&nbsp;</p><p>&nbsp;</p><p style=\"font-size:16px;margin-left:20px;\">&nbsp;</p><table style=\"width:1000px;\" class=\"\" align=\"left\" border=\"0\"><tbody><tr><td style=\"text-align:center;\"><p style=\"text-align:center;\"><span style=\"font-size:14px;\">&nbsp;公司名称</span></p></td><td><p><span style=\"font-size:14px;\">&nbsp;北京淘伟科技有限公司</span></p></td></tr><tr><td style=\"text-align:center;\"><span style=\"font-size:14px;\">&nbsp;</span><span style=\"font-size:14px;\">公司</span><span style=\"font-size:14px;\">地址</span></td><td><span style=\"font-size:14px;\">&nbsp;北京市昌平区回龙观北清路1号珠江摩尔国际中心3号楼一单元1709</span></td></tr><tr><td>&nbsp;</td><td><span style=\"font-size:14px;\">&nbsp;北京淘伟科技有限公司客服中心</span></td></tr><tr><td>&nbsp;</td><td><span style=\"font-size:14px;\">&nbsp;北京市昌平区回龙观北清路1号珠江摩尔国际中心3号楼一单元1612</span></td></tr><tr><td style=\"text-align:center;\"><span style=\"font-size:14px;\">&nbsp;配资专员</span></td><td><span style=\"font-size:14px;\">&nbsp;1709－10000－18</span></td></tr><tr><td><span style=\"font-size:14px;\">&nbsp;</span></td><td><span style=\"font-size:14px;\">&nbsp;1709－10000－68</span></td></tr><tr><td>&nbsp;</td><td><span style=\"font-size:14px;\">&nbsp;1709－10000－98</span></td></tr><tr><td style=\"text-align:center;\"><span style=\"font-size:14px;\">&nbsp;合作电话</span></td><td><span style=\"font-size:14px;\">&nbsp;1709－10000－99</span></td></tr><tr><td style=\"text-align:center;\"><span style=\"font-size:14px;\">&nbsp;理财咨询</span></td><td><span style=\"font-size:14px;\">&nbsp;170－900－88866</span></td></tr><tr><td><span style=\"font-size:14px;\">&nbsp;</span></td><td><span style=\"font-size:14px;\">&nbsp;170－900－88899</span></td></tr><tr><td style=\"text-align:center;\"><span style=\"font-size:14px;\">&nbsp;公司电话</span></td><td><span style=\"font-size:14px;\">&nbsp;4006－575859</span></td></tr></tbody></table><p style=\"font-size:16px;margin-left:20px;\">&nbsp;</p><p style=\"font-size:16px;margin-left:20px;\">&nbsp;</p><p><br p=\"\" />&nbsp;</p><br /><br />','0','0','8','lianxi','0','1428032375','0','article');/* DBReback Separation */
 /* 插入数据 `lzh_article_category` */
 INSERT INTO `lzh_article_category` VALUES ('29','配资简介','','','','<br />','9','1','8','peizi','1','1428372721','0','article');/* DBReback Separation */
 /* 插入数据 `lzh_article_category` */
 INSERT INTO `lzh_article_category` VALUES ('32','操作指引','','','','','8','1','8','zhiyin','1','1428376186','0','article');/* DBReback Separation */
 /* 插入数据 `lzh_article_category` */
 INSERT INTO `lzh_article_category` VALUES ('33','安全保障','','','','<p style=\"text-indent:25px;color:rgb(102, 102, 102);font-family:Microsoft Yahei, Tahoma, Helvetica, Arial, 宋体, sans-serif;font-size:14px;\">&nbsp; 在风控方面，我们从法律安全保障、资金安全保障和信息安全保障三大板块入手，层层审核，层层筛选，确保项目风控与投资者的投资安全为，做您身边最专业的互联网配资服务平台。</p><h2 class=\"txt-title\" style=\"margin-top:24px;margin-bottom:24px;font-size:14px;font-weight:normal;color:rgb(102, 102, 102);font-family:Microsoft Yahei, Tahoma, Helvetica, Arial, 宋体, sans-serif;\"><span class=\"index-word\" style=\"font-size:20px;padding:5px 10px;color:rgb(255, 255, 255);font-weight:bold;background:rgb(252, 133, 68);\">专</span>&nbsp;<span class=\"txt-word\" style=\"font-size:20px;\">专业团队信心保障</span></h2><p><span style=\"color:rgb(102, 102, 102);font-family:Microsoft Yahei, Tahoma, Helvetica, Arial, 宋体, sans-serif;font-size:14px;text-indent:25px;\">财融天下以普惠金融的梦想及互联网金融创新的基因凝聚了一批充满阳光、活力和进取精神的金融、运营、互联网技术精英，他们是金融创新未来的筑梦者，也是脚踏实地的践行者。财融天下成立至今，牢记自律和诚信的生存根本，在行业中辛苦耕耘，业绩逐月攀升，业务不断拓展，已达相当规摸，优势渐显。</span></p><h2 class=\"txt-title\" style=\"margin-top:24px;margin-bottom:24px;font-size:14px;font-weight:normal;color:rgb(102, 102, 102);font-family:Microsoft Yahei, Tahoma, Helvetica, Arial, 宋体, sans-serif;\"><span class=\"index-word\" style=\"font-size:20px;padding:5px 10px;color:rgb(255, 255, 255);font-weight:bold;background:rgb(249, 68, 73);\">银</span>&nbsp;<span class=\"txt-word\" style=\"font-size:20px;\">银行监管资金安全</span></h2><p><span style=\"color:rgb(102, 102, 102);font-family:Microsoft Yahei, Tahoma, Helvetica, Arial, 宋体, sans-serif;font-size:14px;text-indent:25px;\">财融天下把客户的利益放在首位，对客户的每一笔投资，都进行专业、严格的风控管理。目前我方按照“专户专款专用\"的标准模式对客户交易资金进行保管运作，因此客户在财融天下的交易资金是可以完全放心的。</span></p><h2 style=\"margin-top:24px;margin-bottom:24px;font-size:14px;font-weight:normal;color:rgb(102, 102, 102);font-family:Microsoft Yahei, Tahoma, Helvetica, Arial, 宋体, sans-serif;\"><span class=\"title\" style=\"display:block;width:164px;height:41px;color:rgb(255, 255, 255);font-size:18px;font-weight:bold;text-align:center;padding-right:10px;background:url(http://hrcf168.com/Content/v1.0/img/help-img/title-bg.png) no-repeat;\">严格的风控体系</span></h2><p>&nbsp;</p><div class=\"con-wrap\" style=\"color:rgb(102, 102, 102);font-family:Microsoft Yahei, Tahoma, Helvetica, Arial, 宋体, sans-serif;font-size:14px;\"><div class=\"inner-con-wrap\"><p style=\"text-indent:25px;\">以银行监管资金，以券商监管交易，财融天下控制风险，并设置警戒线和平仓线，让客户及早的预知风险，严格按照警戒线和平仓线为客户做好风险管理。</p><h2 style=\"margin-top:24px;margin-bottom:24px;font-size:14px;font-weight:normal;\"><span class=\"title\" style=\"display:block;width:164px;height:41px;color:rgb(255, 255, 255);font-size:18px;font-weight:bold;text-align:center;padding-right:10px;background:url(http://hrcf168.com/Content/v1.0/img/help-img/title-bg.png) no-repeat;\">线上信息安全保障</span></h2><div class=\"con-wrap\" style=\"font-size:14px;\"><div class=\"inner-con-wrap\"><p style=\"text-indent:25px;\">强大的技术运营团队、独立研发的平台系统、科学严格的权限管理及银行级数据灾备系统保障用户线上的账户信息以及交易记录信息的绝对安全，为用户资金及个人信息提供360度无死角的信息安全保障。同时我方还拥有完善的安全监测系统，可以及时发现网站的异常并及时作出反应。 我方会严格遵守国家相关的法律法规，保护用户的隐私信息。未经您同意，我方不会向任何第三方公司、组织和个人披露您的个人信息、账户信息以及交易信息（法律法规另有规定的除外）。</p><p style=\"text-indent:25px;\">&nbsp;</p></div></div></div></div><p>&nbsp;</p><p>&nbsp;</p>','7','0','8','anquan','0','1428377107','0','article');/* DBReback Separation */ 
 /* 数据表结构 `lzh_article_category_area`*/ 
 DROP TABLE IF EXISTS `lzh_article_category_area`;/* DBReback Separation */ 
 CREATE TABLE `lzh_article_category_area` (
  `id` smallint(6) NOT NULL AUTO_INCREMENT,
  `type_name` varchar(40) NOT NULL,
  `type_url` varchar(200) NOT NULL,
  `type_keyword` varchar(200) NOT NULL,
  `type_info` varchar(400) NOT NULL,
  `type_content` text NOT NULL,
  `sort_order` int(11) NOT NULL,
  `type_set` tinyint(1) NOT NULL DEFAULT '0',
  `parent_id` smallint(6) NOT NULL,
  `type_nid` varchar(50) NOT NULL,
  `is_hiden` int(1) unsigned NOT NULL DEFAULT '0',
  `add_time` int(10) unsigned NOT NULL,
  `is_sys` tinyint(3) unsigned NOT NULL,
  `area_id` int(10) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=344 DEFAULT CHARSET=utf8;/* DBReback Separation */
 /* 插入数据 `lzh_article_category_area` */
 INSERT INTO `lzh_article_category_area` VALUES ('1','网站首页','/index.html','','','','0','2','0','indexs','0','0','0','0');/* DBReback Separation */
 /* 插入数据 `lzh_article_category_area` */
 INSERT INTO `lzh_article_category_area` VALUES ('2','我要投资','/invest/index.html','','','','0','2','0','invests','0','0','0','0');/* DBReback Separation */
 /* 插入数据 `lzh_article_category_area` */
 INSERT INTO `lzh_article_category_area` VALUES ('3','我要借款','/borrow/index.html','','','','0','2','0','borrows','0','0','0','0');/* DBReback Separation */
 /* 插入数据 `lzh_article_category_area` */
 INSERT INTO `lzh_article_category_area` VALUES ('4','我的账户','/member/index.html','','','','0','2','0','url4','0','0','0','0');/* DBReback Separation */
 /* 插入数据 `lzh_article_category_area` */
 INSERT INTO `lzh_article_category_area` VALUES ('5','项目投资','','','','','0','2','0','url5','0','0','0','0');/* DBReback Separation */
 /* 插入数据 `lzh_article_category_area` */
 INSERT INTO `lzh_article_category_area` VALUES ('6','会员联盟','','','','','0','2','0','url6','0','0','0','0');/* DBReback Separation */
 /* 插入数据 `lzh_article_category_area` */
 INSERT INTO `lzh_article_category_area` VALUES ('7','会员社区','','','','','0','2','0','url7','0','0','0','0');/* DBReback Separation */
 /* 插入数据 `lzh_article_category_area` */
 INSERT INTO `lzh_article_category_area` VALUES ('8','媒体宣传','','','','','0','2','0','url8','0','0','0','0');/* DBReback Separation */
 /* 插入数据 `lzh_article_category_area` */
 INSERT INTO `lzh_article_category_area` VALUES ('312','首页','/index.html','','','','0','2','1','url1','0','0','0','0');/* DBReback Separation */
 /* 插入数据 `lzh_article_category_area` */
 INSERT INTO `lzh_article_category_area` VALUES ('313','法律政策','','','','<p>sdfsdf</p>','0','0','1','zc','0','0','0','0');/* DBReback Separation */
 /* 插入数据 `lzh_article_category_area` */
 INSERT INTO `lzh_article_category_area` VALUES ('314','法律顾问','','','','','0','0','1','gw','0','0','0','0');/* DBReback Separation */
 /* 插入数据 `lzh_article_category_area` */
 INSERT INTO `lzh_article_category_area` VALUES ('315','媒体报道','','','','','0','0','1','bd','0','0','0','0');/* DBReback Separation */
 /* 插入数据 `lzh_article_category_area` */
 INSERT INTO `lzh_article_category_area` VALUES ('316','关于我们','','','','','0','0','1','about','0','0','0','0');/* DBReback Separation */
 /* 插入数据 `lzh_article_category_area` */
 INSERT INTO `lzh_article_category_area` VALUES ('317','与我们联系','','','','','0','0','1','contact','0','0','0','0');/* DBReback Separation */
 /* 插入数据 `lzh_article_category_area` */
 INSERT INTO `lzh_article_category_area` VALUES ('318','借贷工具','','','','','0','0','2','tool','0','1343744158','0','0');/* DBReback Separation */
 /* 插入数据 `lzh_article_category_area` */
 INSERT INTO `lzh_article_category_area` VALUES ('319','退出登陆','/member/common/actlogout/','','','','0','2','4','logout','0','1343912106','0','0');/* DBReback Separation */
 /* 插入数据 `lzh_article_category_area` */
 INSERT INTO `lzh_article_category_area` VALUES ('320','登陆帐户','/member/common/login/','','','','0','2','4','login','0','1343912279','0','500');/* DBReback Separation */
 /* 插入数据 `lzh_article_category_area` */
 INSERT INTO `lzh_article_category_area` VALUES ('321','testarea','','','','','0','0','0','area','0','1344078155','0','398');/* DBReback Separation */
 /* 插入数据 `lzh_article_category_area` */
 INSERT INTO `lzh_article_category_area` VALUES ('322','东城的分类','','','','','0','0','0','dcs','0','1344078193','0','500');/* DBReback Separation */
 /* 插入数据 `lzh_article_category_area` */
 INSERT INTO `lzh_article_category_area` VALUES ('323','sssfsdf','','','','','0','0','0','area','0','1344078290','0','500');/* DBReback Separation */
 /* 插入数据 `lzh_article_category_area` */
 INSERT INTO `lzh_article_category_area` VALUES ('324','长沙的','','','','<p>修改分类-\"<span style=\"color:red;\">长沙的</span>\"修改分类-\"<span style=\"color:red;\">长沙的</span>\"修改分类-\"<span style=\"color:red;\">长沙的</span>\"修改分类-\"<span style=\"color:red;\">长沙的</span>\"</p>','0','1','0','csnews','0','1344085904','0','197');/* DBReback Separation */
 /* 插入数据 `lzh_article_category_area` */
 INSERT INTO `lzh_article_category_area` VALUES ('325','北京新闻','','','','','0','0','0','csnews','0','1344087105','0','2');/* DBReback Separation */
 /* 插入数据 `lzh_article_category_area` */
 INSERT INTO `lzh_article_category_area` VALUES ('326','财经频道','','','','','0','1','0','test','0','1345123826','0','1');/* DBReback Separation */
 /* 插入数据 `lzh_article_category_area` */
 INSERT INTO `lzh_article_category_area` VALUES ('329','房产新闻','','','','','0','1','0','fangchan','0','1346053716','0','1');/* DBReback Separation */
 /* 插入数据 `lzh_article_category_area` */
 INSERT INTO `lzh_article_category_area` VALUES ('332','国际新闻','','','','','0','1','0','guoji','0','1346118554','0','1');/* DBReback Separation */
 /* 插入数据 `lzh_article_category_area` */
 INSERT INTO `lzh_article_category_area` VALUES ('336','社会新闻','','','','','0','1','0','heshui','0','1346199468','0','1');/* DBReback Separation */
 /* 插入数据 `lzh_article_category_area` */
 INSERT INTO `lzh_article_category_area` VALUES ('337','IT科技','','','','','0','1','0','IT','0','1346219957','0','1');/* DBReback Separation */
 /* 插入数据 `lzh_article_category_area` */
 INSERT INTO `lzh_article_category_area` VALUES ('338','体育新闻','','','','','0','1','0','tiyu','0','1346220003','0','1');/* DBReback Separation */
 /* 插入数据 `lzh_article_category_area` */
 INSERT INTO `lzh_article_category_area` VALUES ('339','教育新闻','','','','<h1>录取通知书满天飞 硕士竟被高职“抢录”</h1><p class=\"Introduction\">[<strong>导读</strong>]“通知：广东省南方技师学院录取你为《环境艺术设计》应届生”一则发自陌生号码的手机短信让唐先生哭笑不得。唐先生告诉记者，他硕士毕业都已经3年了。“难道还让我去读专科吗？”</p><div style=\"position: relative\" id=\"Cnt-Main-Article-QQ\" bosszone=\"content\"><p align=\"center\">&nbsp;</p><div style=\"width: 400px\" class=\"mbArticleSharePic     \" r=\"1\"><div class=\"mbArticleShareBtn\"><span>转播到腾讯微博</span></div><img alt=\"录取通知书满天飞 硕士竟被高职“抢录”\" src=\"http://img1.gtimg.com/edu/pics/hv1/253/177/1125/73198513.jpg\" /></div><p>&nbsp;</p><p class=\"pictext\" align=\"center\">报料人向记者出示他所收到的录取信息。 受访者供图</p><p style=\"text-indent: 2em\">南方日报讯 （记者/闫昆仑实习生/周晓敏）新学期即将开始，高校的招生工作已落下帷幕。然而近日，南方日报记者接到报料称，还有一些高职院校疑似乱发录取通知书。在广州上班的唐先生称，他莫名其妙地收到某大专院校的一则录取通知短信，当他致电校方询问，对方竟还说得头头是道。据了解，今年<!--keyword--><a class=\"a-tips-Article-QQ\" href=\"http://gaokao.qq.com/\"><!--/keyword-->高考<!--keyword--></a><span class=\"infoMblog\">(<a class=\"a-tips-Article-QQ\" href=\"http://t.qq.com/qqgaokao#pref=qqcom.keyword\" rel=\"qqgaokao\" target=\"_blank\" reltitle=\"腾讯高考\">微博</a>)</span><!--/keyword-->后，有不少考生也都接到类似的通知，有些人甚至上当受骗。</p><p style=\"text-indent: 2em\"><strong>录取信息真假难辨</strong></p><p style=\"text-indent: 2em\">“通知：广东省南方技师学院录取你为《环境艺术设计》应届生，请依时入学……”一则发自陌生号码的手机短信让唐先生哭笑不得。唐先生告诉记者，他硕士毕业都已经3年了。“难道还让我去读专科吗？”</p><p style=\"text-indent: 2em\">记者根据唐先生提供的短信，致电校方询问。谁知校方不仅没有跟记者核对身份，还说他们是从教育系统得到考生资料。“我们对考生分数没有限制，你感兴趣可以过来看看。”校方工作人员称。而当记者询问学校地址时，对方只让记者坐车到花都客运站再给他们电话，“校方有车辆接送”。</p><p style=\"text-indent: 2em\">记者随后登录了短信中提供的学校网址，发现这所名为“广东省南方技师学院花都校区”的技工学校自称是“创办于1983年”、“经国务院和中央军委批准成立的公办全日制国家级重点学院”，网站上不仅有学校要闻、专业课程推荐、就业资讯等信息，还有学生作品展示，但记者留意到，这些学生作品图大都有某<a class=\"a-tips-Article-QQ\" href=\"http://edu.qq.com/photo/ctsh.shtml\" target=\"_blank\">图片</a>素材网的水印标识。</p><p style=\"text-indent: 2em\">昨日下午，记者致电广东省南方技师学院韶关本部，该校负责人称，广东省南方技师学院目前除了韶关本部，还有广州、深圳、佛山和高州4个分校区，而广州校区位于广州科学城内，学校并无新设的花都校区。</p><p style=\"text-indent: 2em\"><strong>未报名已收到录取通知</strong></p><p style=\"text-indent: 2em\">南方日报记者通过网络搜索发现，很多网友在论坛上称收到过此类录取通知，有收到手机短信的，也有接到电话的，但一般以应届考生为主。这些同学大都表示自己并没有在相应的学校报名。“不知我们的信息怎么被泄露了。”一名姓王的同学说。</p><p style=\"text-indent: 2em\">据了解，网友提到的招生学校多为高职和技工院校。记者调查发现，其中不乏正规的民办学校，也有无证经营的“野鸡学校”。王同学告诉记者，像他这样成绩不够上本科的学生，选择高职院校是很正常的，去年高考前他就接到了自称“广州华夏职业学院招生办”的电话。“一个电话来了，先跟你谈人生、谈理想，说你不读大学，理想就远了。”</p><p style=\"text-indent: 2em\">王同学说，对方还以老乡身份博取信任，再通过各种入情入理的话吸引他到学校去参观。但由于听到华夏的某些负面新闻，王同学并没心动，还和对方提到自己感兴趣的南方技师学院。“于是该招生办老师口不择言，说那个学校以前死过人，让我不要去。”</p><p style=\"text-indent: 2em\">去年9月，王同学最终报读了广东南方技师学院广州校区。这所学校虽是正规的民办学院，仍令他大失所望。“和宣传的有很大落差。”王同学说，学校招生时说得天花乱坠，称校内有很多社团活动，而当他到学校后才发现只有零散的一两个协会，社团活动也很少，“大学生活真的很无聊。”</p><p style=\"text-indent: 2em\">其他高职院校的同学也普遍反映这学校不规范。目前就读于某创新技术学院的刘同学告诉记者，学校通过各种方式收费的现象很常见。“原来给我们的宣传资料上说学费是每学期四千多，结果加上学杂费、住宿费等其他费用竟要收九千多。”</p><p style=\"text-indent: 2em\">此外，还有某些高职院校被怀疑利用学生劳动力获取商业利益。去年曾有媒体报道，广州华夏职业学院以“实习”为由强迫学生到高尔夫球场割草，不割草就不给学分。记者向该校一名同学了解到，学校原来规定的实习时间是第三学期，“现在第二学期就让我们来割草了”。该同学直呼“当初是被骗进来的”，他们入学后多次想找招生办的的老师理论，却发现当初的“知心”老师或师兄师姐全都不见踪影，“打他们电话打了一星期都打不通。”</p><p style=\"text-indent: 2em\"><strong>知情人报料招生有提成</strong></p><p style=\"text-indent: 2em\">据了解，考生资料外泄的现象其实很普遍。记者通过网络搜索发现，每年均有不少考生收到高职或专科院校的录取短信和电话，有人收到不知名学校寄来的录取通知书。</p><p style=\"text-indent: 2em\">如此奇怪的录取方式为何能得到考生信任？一知情人称，他们一般都是利用了落榜考生的自卑心理。“很多学生求学心切，觉得有学校肯收我就不错了，管他什么学校。”该知情人称，学校会向有报名意向的学生收定金，称是“预留学位”的费用。例如某职业技术学院就要求学生报名时预付1000元定金，考生一旦反悔，定金很难要回来，“主要是退款手续太麻烦了。”该知情人还告诉记者，如果是交了全额学费的，一般只能拿回70%至80%。</p><p style=\"text-indent: 2em\">知情人还透露，像唐先生这样的情况还比较少，“这类学校一般下手很准，收到短信的多是应届考生。”高职院校一般会找些大学生或高中毕业生做“招生助理”，从“助理”手上买来他们学弟学妹的个人资料，这些资料就包括考生的出生日期、电话、准考证号、模拟考成绩等。“有时直接从高中老师那里拿考生资料。”</p><p style=\"text-indent: 2em\">一名不愿透露姓名的“招生助理”告诉记者，他不仅为某信息技术学院提供汕尾市一所高中的考生资料获取报酬，还负责联系“师弟师妹”劝说其报读该学校。“每招一个学生，我可以拿200元提成。”该同学承认，做“招生助理”每月平均能拿到一千多元，还有相应的车费、话费补贴，这对在校大学生来说是很吸引的。</p><p style=\"text-indent: 2em\"><strong>■省人保厅回应</strong></p><p style=\"text-indent: 2em\"><strong>会对此事调查清楚</strong></p><p style=\"text-indent: 2em\">随意发放录取通知的学校究竟有无办学资质？记者就此事采访了主管技工学校的广东省人力资源与社会保障厅，工作人员称直接归省厅管理的技工院校只有12所，唐先生反映的广东省南方技师学院花都校区不在这12所技校之列。记者随后向工作人员反映该校未经总部授权擅自招生并乱发录取短信的情况，工作人员表示：“只要将文字材料送到这边，我们一定调查清楚。”</p><p style=\"text-indent: 2em\"><strong>■律师说法</strong></p><p style=\"text-indent: 2em\"><strong>此类高职院校招生行为不合法</strong></p><p style=\"text-indent: 2em\">广东德比律师事务所律师金豪认为，高职院校需在教育或劳动主管部门批准后方可招生，分校还需得到学校总部的授权。广东南方技师学院花都校区并无得到韶关总部的授权，所以其招生行为是不合法的。</p><p style=\"text-indent: 2em\">无论是高职还是专科院校，其招生计划都受到教育部门的宏观调控，像唐先生反映的学校乱发录取通知，还有网友提到的入学后发现学校和招生说明大有出入的情况都涉嫌民事上的虚假宣传和欺诈。</p><p style=\"text-indent: 2em\">金豪建议，学生入学后如发现学校有不合理收费可提出异议，能提供证据证明学生要求退学被扣手续费的，可控告学校的欺诈行为。考生身份信息属个人隐私，泄露考生身份信息的行为侵犯了公民的隐私权，如果以营利为目的买卖考生身份信息，情节严重的可追究其法律责任。<a id=\"backqqcom\" title=\"点击进入腾讯首页\" href=\"http://www.qq.com/?pref=article\" target=\"_blank\" bosszone=\"backqqcom\" alt=\"点击进入腾讯首页\"><img src=\"http://www.qq.com/favicon.ico\" /></a></p><div style=\"z-index: 899; position: absolute; width: 59px; height: 22px; visibility: visible; top: 2933px; cursor: pointer; text-decoration: none; left: 544px\" id=\"tipsWBzf\"><span style=\"position: relative\"><a style=\"z-index: 900; position: absolute; width: 59px; display: block; background: url(http://mat1.gtimg.com/news/2011/logo.png) no-repeat; height: 22px; top: 0px; left: 0px\" title=\"转播至微博\" href=\"javascript:void(0)\">﻿</a></span></div></div>','0','1','0','jiaoyu','0','1346220057','0','1');/* DBReback Separation */
 /* 插入数据 `lzh_article_category_area` */
 INSERT INTO `lzh_article_category_area` VALUES ('343','安徽新闻','','','','','0','1','0','anhuixw','0','1348407480','0','3');/* DBReback Separation */ 
 /* 数据表结构 `lzh_auser_dologs`*/ 
 DROP TABLE IF EXISTS `lzh_auser_dologs`;/* DBReback Separation */ 
 CREATE TABLE `lzh_auser_dologs` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `type` varchar(16) NOT NULL COMMENT '日志操作类型',
  `tid` int(10) unsigned NOT NULL,
  `tstatus` tinyint(4) unsigned NOT NULL,
  `deal_ip` varchar(16) NOT NULL COMMENT '操作者IP',
  `deal_time` int(10) unsigned NOT NULL COMMENT '操作者时间',
  `deal_user` varchar(50) NOT NULL COMMENT '操作者用户名',
  `deal_info` varchar(200) NOT NULL COMMENT '操作备注',
  PRIMARY KEY (`id`),
  KEY `deal_user` (`deal_user`,`type`)
) ENGINE=MyISAM AUTO_INCREMENT=165 DEFAULT CHARSET=utf8;/* DBReback Separation */
 /* 插入数据 `lzh_auser_dologs` */
 INSERT INTO `lzh_auser_dologs` VALUES ('1','Payonline','0','1','124.205.215.55','1429777571','admin','执行了第三方支付接口参数的编辑操作！');/* DBReback Separation */
 /* 插入数据 `lzh_auser_dologs` */
 INSERT INTO `lzh_auser_dologs` VALUES ('2','Global','0','1','124.205.215.55','1429777575','admin','执行了所有缓存清除操作！');/* DBReback Separation */
 /* 插入数据 `lzh_auser_dologs` */
 INSERT INTO `lzh_auser_dologs` VALUES ('3','login','0','1','124.205.215.55','1429777616','admin','管理员登陆成功');/* DBReback Separation */
 /* 插入数据 `lzh_auser_dologs` */
 INSERT INTO `lzh_auser_dologs` VALUES ('4','Global','0','1','124.205.215.55','1429777621','admin','执行了所有缓存清除操作！');/* DBReback Separation */
 /* 插入数据 `lzh_auser_dologs` */
 INSERT INTO `lzh_auser_dologs` VALUES ('5','login','0','1','124.205.215.55','1429778012','admin','管理员登陆成功');/* DBReback Separation */
 /* 插入数据 `lzh_auser_dologs` */
 INSERT INTO `lzh_auser_dologs` VALUES ('6','login','0','1','124.205.215.55','1429779025','admin','管理员登陆成功');/* DBReback Separation */
 /* 插入数据 `lzh_auser_dologs` */
 INSERT INTO `lzh_auser_dologs` VALUES ('7','Memberid','1','1','124.205.215.55','1429779101','admin','成功执行了会员实名认证的操作！备注信息：');/* DBReback Separation */
 /* 插入数据 `lzh_auser_dologs` */
 INSERT INTO `lzh_auser_dologs` VALUES ('8','Global','0','1','124.205.215.55','1429781264','admin','执行了所有缓存清除操作！');/* DBReback Separation */
 /* 插入数据 `lzh_auser_dologs` */
 INSERT INTO `lzh_auser_dologs` VALUES ('9','Global','0','1','124.205.215.55','1429781265','admin','执行了所有缓存清除操作！');/* DBReback Separation */
 /* 插入数据 `lzh_auser_dologs` */
 INSERT INTO `lzh_auser_dologs` VALUES ('10','login','0','1','124.205.215.55','1429781559','admin','管理员登陆成功');/* DBReback Separation */
 /* 插入数据 `lzh_auser_dologs` */
 INSERT INTO `lzh_auser_dologs` VALUES ('11','Global','0','1','124.205.215.55','1429782001','admin','执行了所有缓存清除操作！');/* DBReback Separation */
 /* 插入数据 `lzh_auser_dologs` */
 INSERT INTO `lzh_auser_dologs` VALUES ('12','Global','0','1','124.205.215.55','1429782002','admin','执行了所有缓存清除操作！');/* DBReback Separation */
 /* 插入数据 `lzh_auser_dologs` */
 INSERT INTO `lzh_auser_dologs` VALUES ('13','AusersEdit','1','1','124.205.215.55','1429782241','admin','管理员修改成功！');/* DBReback Separation */
 /* 插入数据 `lzh_auser_dologs` */
 INSERT INTO `lzh_auser_dologs` VALUES ('14','logout','0','1','124.205.215.55','1429782244','admin','管理员退出');/* DBReback Separation */
 /* 插入数据 `lzh_auser_dologs` */
 INSERT INTO `lzh_auser_dologs` VALUES ('15','login','0','1','124.205.215.55','1429782259','admin','管理员登陆成功');/* DBReback Separation */
 /* 插入数据 `lzh_auser_dologs` */
 INSERT INTO `lzh_auser_dologs` VALUES ('16','AclDel','0','1','124.205.215.55','1429782331','admin','用户组权限删除成功！');/* DBReback Separation */
 /* 插入数据 `lzh_auser_dologs` */
 INSERT INTO `lzh_auser_dologs` VALUES ('17','AclDel','0','1','124.205.215.55','1429782334','admin','用户组权限删除成功！');/* DBReback Separation */
 /* 插入数据 `lzh_auser_dologs` */
 INSERT INTO `lzh_auser_dologs` VALUES ('18','AclDel','0','1','124.205.215.55','1429782338','admin','用户组权限删除成功！');/* DBReback Separation */
 /* 插入数据 `lzh_auser_dologs` */
 INSERT INTO `lzh_auser_dologs` VALUES ('19','AclDel','0','1','124.205.215.55','1429782341','admin','用户组权限删除成功！');/* DBReback Separation */
 /* 插入数据 `lzh_auser_dologs` */
 INSERT INTO `lzh_auser_dologs` VALUES ('20','AclDel','0','1','124.205.215.55','1429782345','admin','用户组权限删除成功！');/* DBReback Separation */
 /* 插入数据 `lzh_auser_dologs` */
 INSERT INTO `lzh_auser_dologs` VALUES ('21','AclDel','0','1','124.205.215.55','1429782348','admin','用户组权限删除成功！');/* DBReback Separation */
 /* 插入数据 `lzh_auser_dologs` */
 INSERT INTO `lzh_auser_dologs` VALUES ('22','Memberid','1','1','124.205.215.55','1429782394','admin','成功执行了会员实名认证的操作！备注信息：');/* DBReback Separation */
 /* 插入数据 `lzh_auser_dologs` */
 INSERT INTO `lzh_auser_dologs` VALUES ('23','Memberid','1','1','124.205.215.55','1429782400','admin','成功执行了会员实名认证的操作！备注信息：');/* DBReback Separation */
 /* 插入数据 `lzh_auser_dologs` */
 INSERT INTO `lzh_auser_dologs` VALUES ('24','Global','0','1','124.205.215.55','1429782449','admin','执行了所有缓存清除操作！');/* DBReback Separation */
 /* 插入数据 `lzh_auser_dologs` */
 INSERT INTO `lzh_auser_dologs` VALUES ('25','login','0','1','124.205.215.55','1429783657','admin','管理员登陆成功');/* DBReback Separation */
 /* 插入数据 `lzh_auser_dologs` */
 INSERT INTO `lzh_auser_dologs` VALUES ('26','Global','0','1','124.205.215.55','1429783660','admin','执行了所有缓存清除操作！');/* DBReback Separation */
 /* 插入数据 `lzh_auser_dologs` */
 INSERT INTO `lzh_auser_dologs` VALUES ('27','examiney','0','1','124.205.215.55','1429786902','admin','管理员执行了股票配资审核不通过操作成功！');/* DBReback Separation */
 /* 插入数据 `lzh_auser_dologs` */
 INSERT INTO `lzh_auser_dologs` VALUES ('28','login','0','1','124.205.215.51','1429838716','admin','管理员登陆成功');/* DBReback Separation */
 /* 插入数据 `lzh_auser_dologs` */
 INSERT INTO `lzh_auser_dologs` VALUES ('29','login','0','1','124.205.215.51','1429839926','admin','管理员登陆成功');/* DBReback Separation */
 /* 插入数据 `lzh_auser_dologs` */
 INSERT INTO `lzh_auser_dologs` VALUES ('30','Vipapply','0','1','124.205.215.51','1429839978','admin','VIP申请审核通过！');/* DBReback Separation */
 /* 插入数据 `lzh_auser_dologs` */
 INSERT INTO `lzh_auser_dologs` VALUES ('31','Global','0','1','124.205.215.51','1429840747','admin','执行了所有缓存清除操作！');/* DBReback Separation */
 /* 插入数据 `lzh_auser_dologs` */
 INSERT INTO `lzh_auser_dologs` VALUES ('32','Global','0','1','124.205.215.51','1429840764','admin','执行了所有缓存清除操作！');/* DBReback Separation */
 /* 插入数据 `lzh_auser_dologs` */
 INSERT INTO `lzh_auser_dologs` VALUES ('33','Global','0','1','124.205.215.51','1429840796','admin','执行了所有缓存清除操作！');/* DBReback Separation */
 /* 插入数据 `lzh_auser_dologs` */
 INSERT INTO `lzh_auser_dologs` VALUES ('34','examiney','0','1','124.205.215.51','1429841187','admin','管理员执行了股票配资并填写homs信息操作成功！');/* DBReback Separation */
 /* 插入数据 `lzh_auser_dologs` */
 INSERT INTO `lzh_auser_dologs` VALUES ('35','CapitalDetail','0','1','124.205.215.51','1429841346','admin','执行了会员资金明细列表导出操作！');/* DBReback Separation */
 /* 插入数据 `lzh_auser_dologs` */
 INSERT INTO `lzh_auser_dologs` VALUES ('36','CapitalDetail','0','1','124.205.215.51','1429841362','admin','执行了会员资金明细列表导出操作！');/* DBReback Separation */
 /* 插入数据 `lzh_auser_dologs` */
 INSERT INTO `lzh_auser_dologs` VALUES ('37','CapitalDetail','0','1','124.205.215.51','1429841366','admin','执行了会员资金明细列表导出操作！');/* DBReback Separation */
 /* 插入数据 `lzh_auser_dologs` */
 INSERT INTO `lzh_auser_dologs` VALUES ('38','CapitalDetail','0','1','124.205.215.51','1429841624','admin','执行了会员资金明细列表导出操作！');/* DBReback Separation */
 /* 插入数据 `lzh_auser_dologs` */
 INSERT INTO `lzh_auser_dologs` VALUES ('39','Smslog','0','1','124.205.215.51','1429841925','admin','对whttcy发送、短信、站内信成功');/* DBReback Separation */
 /* 插入数据 `lzh_auser_dologs` */
 INSERT INTO `lzh_auser_dologs` VALUES ('40','Members','0','1','124.205.215.51','1429842579','admin','成功执行了会员信息资料的修改操作！');/* DBReback Separation */
 /* 插入数据 `lzh_auser_dologs` */
 INSERT INTO `lzh_auser_dologs` VALUES ('41','Members','0','1','124.205.215.51','1429842628','admin','成功执行了会员信息资料的修改操作！');/* DBReback Separation */
 /* 插入数据 `lzh_auser_dologs` */
 INSERT INTO `lzh_auser_dologs` VALUES ('42','login','0','1','124.205.215.51','1429842913','admin','管理员登陆成功');/* DBReback Separation */
 /* 插入数据 `lzh_auser_dologs` */
 INSERT INTO `lzh_auser_dologs` VALUES ('43','Global','0','1','124.205.215.51','1429842916','admin','执行了所有缓存清除操作！');/* DBReback Separation */
 /* 插入数据 `lzh_auser_dologs` */
 INSERT INTO `lzh_auser_dologs` VALUES ('44','Global','0','1','124.205.215.51','1429843055','admin','执行了所有缓存清除操作！');/* DBReback Separation */
 /* 插入数据 `lzh_auser_dologs` */
 INSERT INTO `lzh_auser_dologs` VALUES ('45','doEditWait','1','1','124.205.215.51','1429843529','admin','初审操作成功！');/* DBReback Separation */
 /* 插入数据 `lzh_auser_dologs` */
 INSERT INTO `lzh_auser_dologs` VALUES ('46','Global','0','1','124.205.215.51','1429843531','admin','执行了所有缓存清除操作！');/* DBReback Separation */
 /* 插入数据 `lzh_auser_dologs` */
 INSERT INTO `lzh_auser_dologs` VALUES ('47','Members','0','1','124.205.215.51','1429844565','admin','成功执行了会员授信调整的操作！');/* DBReback Separation */
 /* 插入数据 `lzh_auser_dologs` */
 INSERT INTO `lzh_auser_dologs` VALUES ('48','Global','0','1','124.205.215.51','1429844745','admin','执行了所有缓存清除操作！');/* DBReback Separation */
 /* 插入数据 `lzh_auser_dologs` */
 INSERT INTO `lzh_auser_dologs` VALUES ('49','doedit','0','1','106.39.13.9','1429844855','admin','管理员执行了股票配资修改homs信息操作成功！');/* DBReback Separation */
 /* 插入数据 `lzh_auser_dologs` */
 INSERT INTO `lzh_auser_dologs` VALUES ('50','Vipapply','0','1','106.39.13.9','1429844861','admin','VIP申请审核通过！');/* DBReback Separation */
 /* 插入数据 `lzh_auser_dologs` */
 INSERT INTO `lzh_auser_dologs` VALUES ('51','Memberid','1','1','106.39.13.9','1429844904','admin','成功执行了会员实名认证的操作！备注信息：');/* DBReback Separation */
 /* 插入数据 `lzh_auser_dologs` */
 INSERT INTO `lzh_auser_dologs` VALUES ('52','doedit','0','1','106.39.13.9','1429844962','admin','管理员执行了股票配资重置homs信息操作成功！');/* DBReback Separation */
 /* 插入数据 `lzh_auser_dologs` */
 INSERT INTO `lzh_auser_dologs` VALUES ('53','doedit','0','1','106.39.13.9','1429844977','admin','管理员执行了股票配资重置homs信息操作成功！');/* DBReback Separation */
 /* 插入数据 `lzh_auser_dologs` */
 INSERT INTO `lzh_auser_dologs` VALUES ('54','doedit','0','1','106.39.13.9','1429844991','admin','管理员执行了股票配资修改homs信息操作成功！');/* DBReback Separation */
 /* 插入数据 `lzh_auser_dologs` */
 INSERT INTO `lzh_auser_dologs` VALUES ('55','doedit','0','1','106.39.13.9','1429845020','admin','管理员执行了股票配资重置homs信息操作成功！');/* DBReback Separation */
 /* 插入数据 `lzh_auser_dologs` */
 INSERT INTO `lzh_auser_dologs` VALUES ('56','doedit','0','1','106.39.13.9','1429845030','admin','管理员执行了股票配资修改homs信息操作成功！');/* DBReback Separation */
 /* 插入数据 `lzh_auser_dologs` */
 INSERT INTO `lzh_auser_dologs` VALUES ('57','doedit','0','1','106.39.13.9','1429845040','admin','管理员执行了股票配资修改homs信息操作成功！');/* DBReback Separation */
 /* 插入数据 `lzh_auser_dologs` */
 INSERT INTO `lzh_auser_dologs` VALUES ('58','doedit','0','1','106.39.13.9','1429845047','admin','管理员执行了股票配资修改homs信息操作成功！');/* DBReback Separation */
 /* 插入数据 `lzh_auser_dologs` */
 INSERT INTO `lzh_auser_dologs` VALUES ('59','doedit','0','1','106.39.13.9','1429845057','admin','管理员执行了股票配资修改homs信息操作成功！');/* DBReback Separation */
 /* 插入数据 `lzh_auser_dologs` */
 INSERT INTO `lzh_auser_dologs` VALUES ('60','doedit','0','1','106.39.13.9','1429845065','admin','管理员执行了股票配资修改homs信息操作成功！');/* DBReback Separation */
 /* 插入数据 `lzh_auser_dologs` */
 INSERT INTO `lzh_auser_dologs` VALUES ('61','doedit','0','1','106.39.13.9','1429845075','admin','管理员执行了股票配资修改homs信息操作成功！');/* DBReback Separation */
 /* 插入数据 `lzh_auser_dologs` */
 INSERT INTO `lzh_auser_dologs` VALUES ('62','doedit','0','1','106.39.13.9','1429845085','admin','管理员执行了股票配资修改homs信息操作成功！');/* DBReback Separation */
 /* 插入数据 `lzh_auser_dologs` */
 INSERT INTO `lzh_auser_dologs` VALUES ('63','doedit','0','1','106.39.13.9','1429845094','admin','管理员执行了股票配资修改homs信息操作成功！');/* DBReback Separation */
 /* 插入数据 `lzh_auser_dologs` */
 INSERT INTO `lzh_auser_dologs` VALUES ('64','doedit','0','1','106.39.13.9','1429845101','admin','管理员执行了股票配资修改homs信息操作成功！');/* DBReback Separation */
 /* 插入数据 `lzh_auser_dologs` */
 INSERT INTO `lzh_auser_dologs` VALUES ('65','doedit','0','1','106.39.13.9','1429845112','admin','管理员执行了股票配资修改homs信息操作成功！');/* DBReback Separation */
 /* 插入数据 `lzh_auser_dologs` */
 INSERT INTO `lzh_auser_dologs` VALUES ('66','doedit','0','1','106.39.13.9','1429845119','admin','管理员执行了股票配资修改homs信息操作成功！');/* DBReback Separation */
 /* 插入数据 `lzh_auser_dologs` */
 INSERT INTO `lzh_auser_dologs` VALUES ('67','doedit','0','1','106.39.13.9','1429845131','admin','管理员执行了股票配资修改homs信息操作成功！');/* DBReback Separation */
 /* 插入数据 `lzh_auser_dologs` */
 INSERT INTO `lzh_auser_dologs` VALUES ('68','doedit','0','1','106.39.13.9','1429845143','admin','管理员执行了股票配资修改homs信息操作成功！');/* DBReback Separation */
 /* 插入数据 `lzh_auser_dologs` */
 INSERT INTO `lzh_auser_dologs` VALUES ('69','doedit','0','1','106.39.13.9','1429845151','admin','管理员执行了股票配资修改homs信息操作成功！');/* DBReback Separation */
 /* 插入数据 `lzh_auser_dologs` */
 INSERT INTO `lzh_auser_dologs` VALUES ('70','doedit','0','1','106.39.13.9','1429845157','admin','管理员执行了股票配资修改homs信息操作成功！');/* DBReback Separation */
 /* 插入数据 `lzh_auser_dologs` */
 INSERT INTO `lzh_auser_dologs` VALUES ('71','doedit','0','1','106.39.13.9','1429845168','admin','管理员执行了股票配资修改homs信息操作成功！');/* DBReback Separation */
 /* 插入数据 `lzh_auser_dologs` */
 INSERT INTO `lzh_auser_dologs` VALUES ('72','doedit','0','1','106.39.13.9','1429845179','admin','管理员执行了股票配资修改homs信息操作成功！');/* DBReback Separation */
 /* 插入数据 `lzh_auser_dologs` */
 INSERT INTO `lzh_auser_dologs` VALUES ('73','doedit','0','1','106.39.13.9','1429845188','admin','管理员执行了股票配资修改homs信息操作成功！');/* DBReback Separation */
 /* 插入数据 `lzh_auser_dologs` */
 INSERT INTO `lzh_auser_dologs` VALUES ('74','doedit','0','1','106.39.13.9','1429845196','admin','管理员执行了股票配资修改homs信息操作成功！');/* DBReback Separation */
 /* 插入数据 `lzh_auser_dologs` */
 INSERT INTO `lzh_auser_dologs` VALUES ('75','Vipapply','0','1','106.39.13.9','1429845778','admin','VIP申请审核通过！');/* DBReback Separation */
 /* 插入数据 `lzh_auser_dologs` */
 INSERT INTO `lzh_auser_dologs` VALUES ('76','Vipapply','0','1','106.39.13.9','1429845784','admin','VIP申请审核通过！');/* DBReback Separation */
 /* 插入数据 `lzh_auser_dologs` */
 INSERT INTO `lzh_auser_dologs` VALUES ('77','Vipapply','0','1','106.39.13.9','1429845789','admin','VIP申请审核通过！');/* DBReback Separation */
 /* 插入数据 `lzh_auser_dologs` */
 INSERT INTO `lzh_auser_dologs` VALUES ('78','Vipapply','0','1','106.39.13.9','1429845795','admin','VIP申请审核通过！');/* DBReback Separation */
 /* 插入数据 `lzh_auser_dologs` */
 INSERT INTO `lzh_auser_dologs` VALUES ('79','Vipapply','0','1','106.39.13.9','1429845802','admin','VIP申请审核通过！');/* DBReback Separation */
 /* 插入数据 `lzh_auser_dologs` */
 INSERT INTO `lzh_auser_dologs` VALUES ('80','Vipapply','0','1','106.39.13.9','1429845811','admin','VIP申请审核通过！');/* DBReback Separation */
 /* 插入数据 `lzh_auser_dologs` */
 INSERT INTO `lzh_auser_dologs` VALUES ('81','Memberid','1','1','106.39.13.9','1429845820','admin','成功执行了会员实名认证的操作！备注信息：');/* DBReback Separation */
 /* 插入数据 `lzh_auser_dologs` */
 INSERT INTO `lzh_auser_dologs` VALUES ('82','Memberid','1','1','106.39.13.9','1429845824','admin','成功执行了会员实名认证的操作！备注信息：');/* DBReback Separation */
 /* 插入数据 `lzh_auser_dologs` */
 INSERT INTO `lzh_auser_dologs` VALUES ('83','Memberid','1','1','106.39.13.9','1429845829','admin','成功执行了会员实名认证的操作！备注信息：');/* DBReback Separation */
 /* 插入数据 `lzh_auser_dologs` */
 INSERT INTO `lzh_auser_dologs` VALUES ('84','Memberid','1','1','106.39.13.9','1429845853','admin','成功执行了会员实名认证的操作！备注信息：');/* DBReback Separation */
 /* 插入数据 `lzh_auser_dologs` */
 INSERT INTO `lzh_auser_dologs` VALUES ('85','Memberid','1','1','106.39.13.9','1429846035','admin','成功执行了会员实名认证的操作！备注信息：');/* DBReback Separation */
 /* 插入数据 `lzh_auser_dologs` */
 INSERT INTO `lzh_auser_dologs` VALUES ('86','Paylog','0','1','106.39.13.9','1429846352','admin','执行了管理员手动审核充值操作！');/* DBReback Separation */
 /* 插入数据 `lzh_auser_dologs` */
 INSERT INTO `lzh_auser_dologs` VALUES ('87','Paylog','0','1','106.39.13.9','1429846451','admin','执行了管理员手动审核充值操作！');/* DBReback Separation */
 /* 插入数据 `lzh_auser_dologs` */
 INSERT INTO `lzh_auser_dologs` VALUES ('88','examiney','0','1','106.39.13.9','1429846616','admin','管理员执行了股票配资并填写homs信息操作成功！');/* DBReback Separation */
 /* 插入数据 `lzh_auser_dologs` */
 INSERT INTO `lzh_auser_dologs` VALUES ('89','Memberid','1','1','106.39.13.9','1429846841','admin','成功执行了会员实名认证的操作！备注信息：');/* DBReback Separation */
 /* 插入数据 `lzh_auser_dologs` */
 INSERT INTO `lzh_auser_dologs` VALUES ('90','Global','0','1','106.39.13.9','1429846860','admin','执行了所有缓存清除操作！');/* DBReback Separation */
 /* 插入数据 `lzh_auser_dologs` */
 INSERT INTO `lzh_auser_dologs` VALUES ('91','Memberid','1','1','106.39.13.9','1429846860','admin','成功执行了会员实名认证的操作！备注信息：');/* DBReback Separation */
 /* 插入数据 `lzh_auser_dologs` */
 INSERT INTO `lzh_auser_dologs` VALUES ('92','examiney','0','1','106.39.13.9','1429846870','admin','管理员执行了股票配资并填写homs信息操作成功！');/* DBReback Separation */
 /* 插入数据 `lzh_auser_dologs` */
 INSERT INTO `lzh_auser_dologs` VALUES ('93','AclEdit','1','1','106.39.13.9','1429848197','admin','用户组权限修改成功！');/* DBReback Separation */
 /* 插入数据 `lzh_auser_dologs` */
 INSERT INTO `lzh_auser_dologs` VALUES ('94','AclAdd','26','1','106.39.13.9','1429848340','admin','用户组权限添加成功！');/* DBReback Separation */
 /* 插入数据 `lzh_auser_dologs` */
 INSERT INTO `lzh_auser_dologs` VALUES ('95','Paylog','0','1','106.39.13.9','1429848458','admin','执行了管理员手动审核充值操作！');/* DBReback Separation */
 /* 插入数据 `lzh_auser_dologs` */
 INSERT INTO `lzh_auser_dologs` VALUES ('96','login','0','1','106.39.13.19','1429850172','admin','管理员登陆成功');/* DBReback Separation */
 /* 插入数据 `lzh_auser_dologs` */
 INSERT INTO `lzh_auser_dologs` VALUES ('97','Global','0','1','106.39.13.19','1429850319','admin','执行了所有缓存清除操作！');/* DBReback Separation */
 /* 插入数据 `lzh_auser_dologs` */
 INSERT INTO `lzh_auser_dologs` VALUES ('98','login','0','1','106.39.13.9','1429850708','admin','管理员登陆成功');/* DBReback Separation */
 /* 插入数据 `lzh_auser_dologs` */
 INSERT INTO `lzh_auser_dologs` VALUES ('99','Vipapply','0','1','106.39.13.9','1429850760','admin','VIP申请审核通过！');/* DBReback Separation */
 /* 插入数据 `lzh_auser_dologs` */
 INSERT INTO `lzh_auser_dologs` VALUES ('100','Members','0','1','106.39.13.9','1429851008','admin','成功执行了会员信息资料的修改操作！');/* DBReback Separation */
 /* 插入数据 `lzh_auser_dologs` */
 INSERT INTO `lzh_auser_dologs` VALUES ('101','examiney','0','1','106.39.13.9','1429852004','admin','管理员执行了股票配资并填写homs信息操作成功！');/* DBReback Separation */
 /* 插入数据 `lzh_auser_dologs` */
 INSERT INTO `lzh_auser_dologs` VALUES ('102','examiney','0','1','106.39.13.9','1429852051','admin','管理员执行了股票配资并填写homs信息操作成功！');/* DBReback Separation */
 /* 插入数据 `lzh_auser_dologs` */
 INSERT INTO `lzh_auser_dologs` VALUES ('103','examiney','0','1','106.39.13.9','1429852060','admin','管理员执行了股票配资并填写homs信息操作成功！');/* DBReback Separation */
 /* 插入数据 `lzh_auser_dologs` */
 INSERT INTO `lzh_auser_dologs` VALUES ('104','examiney','0','1','106.39.13.9','1429852067','admin','管理员执行了股票配资并填写homs信息操作成功！');/* DBReback Separation */
 /* 插入数据 `lzh_auser_dologs` */
 INSERT INTO `lzh_auser_dologs` VALUES ('105','examiney','0','1','106.39.13.9','1429852098','admin','管理员执行了股票配资并填写homs信息操作成功！');/* DBReback Separation */
 /* 插入数据 `lzh_auser_dologs` */
 INSERT INTO `lzh_auser_dologs` VALUES ('106','examiney','0','1','106.39.13.9','1429852106','admin','管理员执行了股票配资并填写homs信息操作成功！');/* DBReback Separation */
 /* 插入数据 `lzh_auser_dologs` */
 INSERT INTO `lzh_auser_dologs` VALUES ('107','examiney','0','1','106.39.13.9','1429852171','admin','管理员执行了股票配资并填写homs信息操作成功！');/* DBReback Separation */
 /* 插入数据 `lzh_auser_dologs` */
 INSERT INTO `lzh_auser_dologs` VALUES ('108','examiney','0','1','106.39.13.9','1429852318','admin','管理员执行了股票配资并填写homs信息操作成功！');/* DBReback Separation */
 /* 插入数据 `lzh_auser_dologs` */
 INSERT INTO `lzh_auser_dologs` VALUES ('109','examiney','0','1','106.39.13.9','1429852351','admin','管理员执行了股票配资并填写homs信息操作成功！');/* DBReback Separation */
 /* 插入数据 `lzh_auser_dologs` */
 INSERT INTO `lzh_auser_dologs` VALUES ('110','examiney','0','1','106.39.13.9','1429852359','admin','管理员执行了股票配资并填写homs信息操作成功！');/* DBReback Separation */
 /* 插入数据 `lzh_auser_dologs` */
 INSERT INTO `lzh_auser_dologs` VALUES ('111','examiney','0','1','106.39.13.9','1429852438','admin','管理员执行了股票配资并填写homs信息操作成功！');/* DBReback Separation */
 /* 插入数据 `lzh_auser_dologs` */
 INSERT INTO `lzh_auser_dologs` VALUES ('112','examiney','0','1','106.39.13.9','1429853180','admin','管理员执行了股票配资并填写homs信息操作成功！');/* DBReback Separation */
 /* 插入数据 `lzh_auser_dologs` */
 INSERT INTO `lzh_auser_dologs` VALUES ('113','Memberid','1','1','106.39.13.9','1429853688','admin','成功执行了会员实名认证的操作！备注信息：');/* DBReback Separation */
 /* 插入数据 `lzh_auser_dologs` */
 INSERT INTO `lzh_auser_dologs` VALUES ('114','examiney','0','1','106.39.13.9','1429853986','admin','管理员执行了股票配资并填写homs信息操作成功！');/* DBReback Separation */
 /* 插入数据 `lzh_auser_dologs` */
 INSERT INTO `lzh_auser_dologs` VALUES ('115','examiney','0','1','106.39.13.9','1429854013','admin','管理员执行了股票配资并填写homs信息操作成功！');/* DBReback Separation */
 /* 插入数据 `lzh_auser_dologs` */
 INSERT INTO `lzh_auser_dologs` VALUES ('116','examiney','0','1','106.39.13.9','1429854018','admin','管理员执行了股票配资并填写homs信息操作成功！');/* DBReback Separation */
 /* 插入数据 `lzh_auser_dologs` */
 INSERT INTO `lzh_auser_dologs` VALUES ('117','examiney','0','1','106.39.13.9','1429854033','admin','管理员执行了股票配资并填写homs信息操作成功！');/* DBReback Separation */
 /* 插入数据 `lzh_auser_dologs` */
 INSERT INTO `lzh_auser_dologs` VALUES ('118','login','0','1','106.39.13.9','1429854114','admin','管理员登陆成功');/* DBReback Separation */
 /* 插入数据 `lzh_auser_dologs` */
 INSERT INTO `lzh_auser_dologs` VALUES ('119','Msgonline','0','1','106.39.13.9','1429854258','admin','成功执行了通知信息接口的编辑操作！');/* DBReback Separation */
 /* 插入数据 `lzh_auser_dologs` */
 INSERT INTO `lzh_auser_dologs` VALUES ('120','Global','0','1','106.39.13.9','1429854262','admin','执行了所有缓存清除操作！');/* DBReback Separation */
 /* 插入数据 `lzh_auser_dologs` */
 INSERT INTO `lzh_auser_dologs` VALUES ('121','Global','0','1','106.39.13.9','1429854268','admin','执行了所有缓存清除操作！');/* DBReback Separation */
 /* 插入数据 `lzh_auser_dologs` */
 INSERT INTO `lzh_auser_dologs` VALUES ('122','Global','0','1','106.39.13.9','1429854831','admin','执行了所有缓存清除操作！');/* DBReback Separation */
 /* 插入数据 `lzh_auser_dologs` */
 INSERT INTO `lzh_auser_dologs` VALUES ('123','Global','0','1','106.39.13.9','1429855594','admin','执行了所有缓存清除操作！');/* DBReback Separation */
 /* 插入数据 `lzh_auser_dologs` */
 INSERT INTO `lzh_auser_dologs` VALUES ('124','Global','0','1','106.39.13.9','1429855686','admin','执行了所有缓存清除操作！');/* DBReback Separation */
 /* 插入数据 `lzh_auser_dologs` */
 INSERT INTO `lzh_auser_dologs` VALUES ('125','Vipapply','0','1','106.39.13.9','1429855692','admin','VIP申请审核通过！');/* DBReback Separation */
 /* 插入数据 `lzh_auser_dologs` */
 INSERT INTO `lzh_auser_dologs` VALUES ('126','Global','0','1','106.39.13.9','1429855693','admin','执行了所有缓存清除操作！');/* DBReback Separation */
 /* 插入数据 `lzh_auser_dologs` */
 INSERT INTO `lzh_auser_dologs` VALUES ('127','Global','0','1','106.39.13.9','1429855693','admin','执行了所有缓存清除操作！');/* DBReback Separation */
 /* 插入数据 `lzh_auser_dologs` */
 INSERT INTO `lzh_auser_dologs` VALUES ('128','Global','0','1','106.39.13.9','1429855693','admin','执行了所有缓存清除操作！');/* DBReback Separation */
 /* 插入数据 `lzh_auser_dologs` */
 INSERT INTO `lzh_auser_dologs` VALUES ('129','Global','0','1','106.39.13.9','1429855694','admin','执行了所有缓存清除操作！');/* DBReback Separation */
 /* 插入数据 `lzh_auser_dologs` */
 INSERT INTO `lzh_auser_dologs` VALUES ('130','Vipapply','0','1','106.39.13.9','1429855700','admin','VIP申请审核通过！');/* DBReback Separation */
 /* 插入数据 `lzh_auser_dologs` */
 INSERT INTO `lzh_auser_dologs` VALUES ('131','login','0','1','106.39.13.9','1429855814','admin','管理员登陆成功');/* DBReback Separation */
 /* 插入数据 `lzh_auser_dologs` */
 INSERT INTO `lzh_auser_dologs` VALUES ('132','Memberid','1','1','106.39.13.9','1429856134','admin','成功执行了会员实名认证的操作！备注信息：');/* DBReback Separation */
 /* 插入数据 `lzh_auser_dologs` */
 INSERT INTO `lzh_auser_dologs` VALUES ('133','Global','0','1','106.39.13.9','1429856243','admin','执行了所有缓存清除操作！');/* DBReback Separation */
 /* 插入数据 `lzh_auser_dologs` */
 INSERT INTO `lzh_auser_dologs` VALUES ('134','Memberid','1','1','106.39.13.9','1429857003','admin','成功执行了会员实名认证的操作！备注信息：');/* DBReback Separation */
 /* 插入数据 `lzh_auser_dologs` */
 INSERT INTO `lzh_auser_dologs` VALUES ('135','Members','0','1','106.39.13.9','1429857106','admin','成功执行了会员信息资料的修改操作！');/* DBReback Separation */
 /* 插入数据 `lzh_auser_dologs` */
 INSERT INTO `lzh_auser_dologs` VALUES ('136','Members','0','1','106.39.13.9','1429857202','admin','成功执行了会员余额调整的操作！');/* DBReback Separation */
 /* 插入数据 `lzh_auser_dologs` */
 INSERT INTO `lzh_auser_dologs` VALUES ('137','Members','0','1','106.39.13.9','1429857217','admin','成功执行了会员授信调整的操作！');/* DBReback Separation */
 /* 插入数据 `lzh_auser_dologs` */
 INSERT INTO `lzh_auser_dologs` VALUES ('138','Paylog','0','1','106.39.13.9','1429857422','admin','执行了管理员手动审核充值操作！');/* DBReback Separation */
 /* 插入数据 `lzh_auser_dologs` */
 INSERT INTO `lzh_auser_dologs` VALUES ('139','examiney','0','1','106.39.13.9','1429857886','admin','管理员执行了股票配资并填写homs信息操作成功！');/* DBReback Separation */
 /* 插入数据 `lzh_auser_dologs` */
 INSERT INTO `lzh_auser_dologs` VALUES ('140','AclAdd','27','1','106.39.13.9','1429860350','admin','用户组权限添加成功！');/* DBReback Separation */
 /* 插入数据 `lzh_auser_dologs` */
 INSERT INTO `lzh_auser_dologs` VALUES ('141','AclEdit','1','1','106.39.13.9','1429860448','admin','用户组权限修改成功！');/* DBReback Separation */
 /* 插入数据 `lzh_auser_dologs` */
 INSERT INTO `lzh_auser_dologs` VALUES ('142','AusersAdd','123','1','106.39.13.9','1429860592','admin','管理员添加成功！');/* DBReback Separation */
 /* 插入数据 `lzh_auser_dologs` */
 INSERT INTO `lzh_auser_dologs` VALUES ('143','login','0','1','106.39.13.9','1429860774','caoshuai001','管理员登陆成功');/* DBReback Separation */
 /* 插入数据 `lzh_auser_dologs` */
 INSERT INTO `lzh_auser_dologs` VALUES ('144','logout','0','1','106.39.13.9','1429860975','caoshuai001','管理员退出');/* DBReback Separation */
 /* 插入数据 `lzh_auser_dologs` */
 INSERT INTO `lzh_auser_dologs` VALUES ('145','login','0','1','106.39.13.9','1429861086','caoshuai001','管理员登陆成功');/* DBReback Separation */
 /* 插入数据 `lzh_auser_dologs` */
 INSERT INTO `lzh_auser_dologs` VALUES ('146','login','0','1','106.39.13.9','1429861086','admin','管理员登陆成功');/* DBReback Separation */
 /* 插入数据 `lzh_auser_dologs` */
 INSERT INTO `lzh_auser_dologs` VALUES ('147','borrowApproved','1','1','106.39.13.9','1429861263','admin','复审操作成功！');/* DBReback Separation */
 /* 插入数据 `lzh_auser_dologs` */
 INSERT INTO `lzh_auser_dologs` VALUES ('148','Global','0','1','106.39.13.9','1429861584','admin','执行了所有缓存清除操作！');/* DBReback Separation */
 /* 插入数据 `lzh_auser_dologs` */
 INSERT INTO `lzh_auser_dologs` VALUES ('149','Global','0','1','106.39.13.9','1429861668','admin','执行了所有缓存清除操作！');/* DBReback Separation */
 /* 插入数据 `lzh_auser_dologs` */
 INSERT INTO `lzh_auser_dologs` VALUES ('150','Global','0','1','106.39.13.9','1429862022','admin','执行了所有缓存清除操作！');/* DBReback Separation */
 /* 插入数据 `lzh_auser_dologs` */
 INSERT INTO `lzh_auser_dologs` VALUES ('151','Memberid','1','1','106.39.13.9','1429863607','admin','成功执行了会员实名认证的操作！备注信息：');/* DBReback Separation */
 /* 插入数据 `lzh_auser_dologs` */
 INSERT INTO `lzh_auser_dologs` VALUES ('152','examiney','0','1','106.39.13.9','1429864379','admin','管理员执行了股票配资审核不通过操作成功！');/* DBReback Separation */
 /* 插入数据 `lzh_auser_dologs` */
 INSERT INTO `lzh_auser_dologs` VALUES ('153','examiney','0','1','106.39.13.9','1429864383','admin','管理员执行了股票配资审核不通过操作成功！');/* DBReback Separation */
 /* 插入数据 `lzh_auser_dologs` */
 INSERT INTO `lzh_auser_dologs` VALUES ('154','login','0','1','106.39.13.9','1429869748','admin','管理员登陆成功');/* DBReback Separation */
 /* 插入数据 `lzh_auser_dologs` */
 INSERT INTO `lzh_auser_dologs` VALUES ('155','Global','0','1','106.39.13.9','1429870398','admin','执行了所有缓存清除操作！');/* DBReback Separation */
 /* 插入数据 `lzh_auser_dologs` */
 INSERT INTO `lzh_auser_dologs` VALUES ('156','Global','0','1','106.39.13.9','1429870470','admin','执行了所有缓存清除操作！');/* DBReback Separation */
 /* 插入数据 `lzh_auser_dologs` */
 INSERT INTO `lzh_auser_dologs` VALUES ('157','login','0','1','106.39.13.15','1430099563','admin','管理员登陆成功');/* DBReback Separation */
 /* 插入数据 `lzh_auser_dologs` */
 INSERT INTO `lzh_auser_dologs` VALUES ('158','examiney','0','1','106.39.13.15','1430100164','admin','管理员执行了股票配资并填写homs信息操作成功！');/* DBReback Separation */
 /* 插入数据 `lzh_auser_dologs` */
 INSERT INTO `lzh_auser_dologs` VALUES ('159','login','0','1','106.39.13.15','1430102558','admin','管理员登陆成功');/* DBReback Separation */
 /* 插入数据 `lzh_auser_dologs` */
 INSERT INTO `lzh_auser_dologs` VALUES ('160','login','0','1','106.39.13.15','1430113585','admin','管理员登陆成功');/* DBReback Separation */
 /* 插入数据 `lzh_auser_dologs` */
 INSERT INTO `lzh_auser_dologs` VALUES ('161','examiney','0','1','106.39.13.15','1430113603','admin','管理员执行了股票配资并填写homs信息操作成功！');/* DBReback Separation */
 /* 插入数据 `lzh_auser_dologs` */
 INSERT INTO `lzh_auser_dologs` VALUES ('162','login','0','1','106.39.13.15','1430119625','admin','管理员登陆成功');/* DBReback Separation */
 /* 插入数据 `lzh_auser_dologs` */
 INSERT INTO `lzh_auser_dologs` VALUES ('163','login','0','1','106.39.13.15','1430121560','caoshuai001','管理员登陆成功');/* DBReback Separation */
 /* 插入数据 `lzh_auser_dologs` */
 INSERT INTO `lzh_auser_dologs` VALUES ('164','doedit','0','1','106.39.13.15','1430121649','caoshuai001','管理员执行了股票配资修改homs信息操作成功！');/* DBReback Separation */ 
 /* 数据表结构 `lzh_ausers`*/ 
 DROP TABLE IF EXISTS `lzh_ausers`;/* DBReback Separation */ 
 CREATE TABLE `lzh_ausers` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_name` varchar(50) NOT NULL,
  `user_pass` varchar(50) NOT NULL,
  `u_group_id` smallint(6) NOT NULL,
  `real_name` varchar(20) NOT NULL DEFAULT '匿名',
  `last_log_time` int(10) NOT NULL DEFAULT '0',
  `last_log_ip` varchar(30) NOT NULL DEFAULT '0',
  `is_ban` int(1) NOT NULL DEFAULT '0',
  `area_id` int(11) NOT NULL,
  `area_name` varchar(10) NOT NULL,
  `is_kf` int(10) unsigned NOT NULL DEFAULT '0',
  `qq` varchar(20) NOT NULL COMMENT '管理员qq',
  `phone` varchar(20) NOT NULL COMMENT '客服电话',
  `user_word` varchar(100) NOT NULL COMMENT '密码口令',
  `commission` decimal(15,2) DEFAULT NULL,
  `invitation_code` varchar(50) DEFAULT NULL,
  `is_stock` tinyint(2) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `is_kf` (`is_kf`,`area_id`)
) ENGINE=MyISAM AUTO_INCREMENT=124 DEFAULT CHARSET=utf8;/* DBReback Separation */
 /* 插入数据 `lzh_ausers` */
 INSERT INTO `lzh_ausers` VALUES ('123','caoshuai001','45e9f958e1b66852096897e136524a8e','27','曹帅','1430121560','106.39.13.15','0','0','中国','0','','','265423','','','0');/* DBReback Separation */
 /* 插入数据 `lzh_ausers` */
 INSERT INTO `lzh_ausers` VALUES ('113','admin','4ff5810197ed7bd6fd22c83cc91ff30f','5','张三','1430119625','106.39.13.15','0','1','中国','1','','','rtx20140303','','','0');/* DBReback Separation */
 /* 插入数据 `lzh_ausers` */
 INSERT INTO `lzh_ausers` VALUES ('122','内外测试专用','e10adc3949ba59abbe56e057f20f883e','25','内外测试专用','1429702274','116.226.228.46','0','0','中国','0','','','123456','','abc','0');/* DBReback Separation */ 
 /* 数据表结构 `lzh_auto_borrow`*/ 
 DROP TABLE IF EXISTS `lzh_auto_borrow`;/* DBReback Separation */ 
 CREATE TABLE `lzh_auto_borrow` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `uid` int(10) unsigned NOT NULL,
  `interest_rate` decimal(5,2) NOT NULL,
  `duration_from` tinyint(3) unsigned NOT NULL,
  `duration_to` tinyint(3) unsigned NOT NULL,
  `account_money` decimal(15,2) NOT NULL,
  `end_time` int(10) unsigned NOT NULL,
  `add_time` int(10) unsigned NOT NULL,
  `add_ip` varchar(16) NOT NULL,
  `is_auto_full` int(11) NOT NULL,
  `invest_money` decimal(15,2) NOT NULL,
  `is_use` tinyint(4) NOT NULL DEFAULT '1',
  `borrow_type` tinyint(4) NOT NULL,
  `min_invest` decimal(15,2) NOT NULL COMMENT '最小投资金额',
  `invest_time` int(10) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `is_use` (`is_use`,`borrow_type`,`end_time`,`id`)
) ENGINE=MyISAM AUTO_INCREMENT=2 DEFAULT CHARSET=utf8;/* DBReback Separation */
 /* 插入数据 `lzh_auto_borrow` */
 INSERT INTO `lzh_auto_borrow` VALUES ('1','9','15.00','1','2','100.00','1431100800','1429853276','106.39.13.9','0','200.00','1','1','50.00','1429853276');/* DBReback Separation */ 
 /* 数据表结构 `lzh_borrow_info`*/ 
 DROP TABLE IF EXISTS `lzh_borrow_info`;/* DBReback Separation */ 
 CREATE TABLE `lzh_borrow_info` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `borrow_name` varchar(50) NOT NULL,
  `borrow_uid` int(11) NOT NULL,
  `borrow_duration` tinyint(3) unsigned NOT NULL,
  `borrow_money` decimal(15,2) NOT NULL,
  `borrow_interest` decimal(15,2) NOT NULL,
  `borrow_interest_rate` decimal(5,2) NOT NULL,
  `borrow_fee` decimal(15,2) NOT NULL,
  `has_borrow` decimal(15,2) unsigned NOT NULL,
  `borrow_times` smallint(5) unsigned NOT NULL DEFAULT '0',
  `repayment_money` decimal(15,2) NOT NULL,
  `repayment_interest` decimal(15,2) NOT NULL,
  `expired_money` decimal(15,2) NOT NULL,
  `repayment_type` tinyint(3) unsigned NOT NULL,
  `borrow_type` tinyint(3) unsigned NOT NULL,
  `borrow_status` tinyint(3) unsigned NOT NULL,
  `borrow_use` tinyint(3) unsigned NOT NULL,
  `add_time` int(10) NOT NULL,
  `collect_day` tinyint(3) unsigned NOT NULL,
  `collect_time` int(10) unsigned NOT NULL,
  `full_time` int(10) unsigned NOT NULL DEFAULT '0',
  `deadline` int(10) unsigned NOT NULL,
  `first_verify_time` int(10) unsigned NOT NULL,
  `second_verify_time` int(10) unsigned NOT NULL,
  `add_ip` varchar(16) NOT NULL,
  `borrow_info` varchar(500) NOT NULL,
  `total` tinyint(4) NOT NULL,
  `has_pay` tinyint(4) NOT NULL,
  `substitute_money` decimal(15,2) NOT NULL,
  `reward_vouch_rate` float(5,2) NOT NULL,
  `reward_vouch_money` decimal(15,2) unsigned NOT NULL,
  `reward_type` tinyint(3) unsigned NOT NULL DEFAULT '0',
  `reward_num` decimal(10,2) unsigned NOT NULL,
  `reward_money` decimal(15,2) unsigned NOT NULL,
  `borrow_min` mediumint(8) unsigned NOT NULL,
  `borrow_max` mediumint(8) unsigned NOT NULL,
  `province` int(10) unsigned NOT NULL,
  `city` int(10) unsigned NOT NULL,
  `area` int(10) unsigned NOT NULL,
  `vouch_member` varchar(100) NOT NULL,
  `has_vouch` decimal(15,2) NOT NULL,
  `password` char(32) NOT NULL,
  `is_tuijian` tinyint(2) unsigned NOT NULL COMMENT '是否推荐0：不推荐；1：推荐',
  `can_auto` tinyint(3) unsigned NOT NULL DEFAULT '1',
  `is_huinong` tinyint(3) unsigned NOT NULL DEFAULT '0' COMMENT '是否是惠农标 1：是；0：否',
  `updata` varchar(3000) DEFAULT NULL,
  `danbao` int(11) NOT NULL COMMENT '担保公司id',
  `vouch_money` decimal(15,2) NOT NULL COMMENT '担保金额',
  `money_collect` decimal(15,2) NOT NULL DEFAULT '0.00' COMMENT '投标待收限制金额，默认为0，即无待收限制',
  `risk_control` varchar(2000) NOT NULL,
  `huilv` float DEFAULT '0',
  `money_invest_place` int(10) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `borrow_status` (`borrow_status`,`collect_time`,`borrow_interest_rate`,`borrow_money`,`borrow_duration`,`id`),
  KEY `borrow_uid` (`borrow_uid`,`borrow_status`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8 ROW_FORMAT=DYNAMIC;/* DBReback Separation */
 /* 插入数据 `lzh_borrow_info` */
 INSERT INTO `lzh_borrow_info` VALUES ('1','股票账户500000元做保证/借款100000元','1','1','100000.00','1066.67','12.80','1000.00','100000.00','24','0.00','0.00','0.00','4','5','6','7','1429842915','5','1430275529','1429860956','1432483199','1429843529','1429861263','124.205.215.51','股票抵押以增加流动资金。保证按时还款。且提前支付利息。','1','0','0.00','0.00','0.00','0','0.00','0.00','100','0','0','0','0','','0.00','','0','1','0','N;','0','0.00','0.00','','0','0');/* DBReback Separation */ 
 /* 数据表结构 `lzh_borrow_info_lock`*/ 
 DROP TABLE IF EXISTS `lzh_borrow_info_lock`;/* DBReback Separation */ 
 CREATE TABLE `lzh_borrow_info_lock` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `suo` int(10) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8 ROW_FORMAT=DYNAMIC;/* DBReback Separation */
 /* 插入数据 `lzh_borrow_info_lock` */
 INSERT INTO `lzh_borrow_info_lock` VALUES ('1','0');/* DBReback Separation */ 
 /* 数据表结构 `lzh_borrow_investor`*/ 
 DROP TABLE IF EXISTS `lzh_borrow_investor`;/* DBReback Separation */ 
 CREATE TABLE `lzh_borrow_investor` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `status` tinyint(3) unsigned NOT NULL DEFAULT '0',
  `borrow_id` int(10) unsigned NOT NULL,
  `investor_uid` int(10) unsigned NOT NULL,
  `borrow_uid` int(11) NOT NULL,
  `investor_capital` decimal(15,2) NOT NULL COMMENT '充值资金池的投资金额',
  `investor_interest` decimal(15,2) NOT NULL,
  `receive_capital` decimal(15,2) NOT NULL COMMENT '回款资金存放池的投资金额',
  `receive_interest` decimal(15,2) NOT NULL,
  `substitute_money` decimal(15,2) NOT NULL,
  `expired_money` decimal(15,2) NOT NULL,
  `invest_fee` decimal(15,2) NOT NULL,
  `paid_fee` decimal(15,2) NOT NULL,
  `add_time` int(10) unsigned NOT NULL,
  `deadline` int(10) unsigned NOT NULL,
  `is_auto` tinyint(3) unsigned NOT NULL DEFAULT '0',
  `reward_money` decimal(15,2) NOT NULL,
  `debt_status` tinyint(3) NOT NULL DEFAULT '0' COMMENT '债权转让状态',
  `debt_uid` int(11) NOT NULL COMMENT '债权转让人ID',
  PRIMARY KEY (`id`),
  KEY `investor_uid` (`investor_uid`,`status`),
  KEY `borrow_id` (`borrow_id`,`investor_uid`,`status`)
) ENGINE=InnoDB AUTO_INCREMENT=25 DEFAULT CHARSET=utf8;/* DBReback Separation */
 /* 插入数据 `lzh_borrow_investor` */
 INSERT INTO `lzh_borrow_investor` VALUES ('1','4','1','13','1','1000.00','10.67','0.00','0.00','0.00','0.00','0.00','0.00','1429846282','1432483199','0','0.00','0','0');/* DBReback Separation */
 /* 插入数据 `lzh_borrow_investor` */
 INSERT INTO `lzh_borrow_investor` VALUES ('2','4','1','22','1','5000.00','53.33','0.00','0.00','0.00','0.00','0.00','0.00','1429847833','1432483199','0','0.00','0','0');/* DBReback Separation */
 /* 插入数据 `lzh_borrow_investor` */
 INSERT INTO `lzh_borrow_investor` VALUES ('3','4','1','15','1','1000.00','10.67','0.00','0.00','0.00','0.00','0.00','0.00','1429850894','1432483199','0','0.00','0','0');/* DBReback Separation */
 /* 插入数据 `lzh_borrow_investor` */
 INSERT INTO `lzh_borrow_investor` VALUES ('4','4','1','3','1','10000.00','106.67','0.00','0.00','0.00','0.00','0.00','0.00','1429851268','1432483199','0','0.00','0','0');/* DBReback Separation */
 /* 插入数据 `lzh_borrow_investor` */
 INSERT INTO `lzh_borrow_investor` VALUES ('5','4','1','9','1','200.00','2.13','0.00','0.00','0.00','0.00','0.00','0.00','1429851767','1432483199','0','0.00','0','0');/* DBReback Separation */
 /* 插入数据 `lzh_borrow_investor` */
 INSERT INTO `lzh_borrow_investor` VALUES ('6','4','1','16','1','4000.00','42.67','0.00','0.00','0.00','0.00','0.00','0.00','1429853721','1432483199','0','0.00','0','0');/* DBReback Separation */
 /* 插入数据 `lzh_borrow_investor` */
 INSERT INTO `lzh_borrow_investor` VALUES ('7','4','1','26','1','5000.00','53.33','0.00','0.00','0.00','0.00','0.00','0.00','1429856109','1432483199','0','0.00','0','0');/* DBReback Separation */
 /* 插入数据 `lzh_borrow_investor` */
 INSERT INTO `lzh_borrow_investor` VALUES ('8','4','1','26','1','1500.00','16.00','0.00','0.00','0.00','0.00','0.00','0.00','1429856116','1432483199','0','0.00','0','0');/* DBReback Separation */
 /* 插入数据 `lzh_borrow_investor` */
 INSERT INTO `lzh_borrow_investor` VALUES ('9','4','1','24','1','100.00','1.07','0.00','0.00','0.00','0.00','0.00','0.00','1429856225','1432483199','0','0.00','0','0');/* DBReback Separation */
 /* 插入数据 `lzh_borrow_investor` */
 INSERT INTO `lzh_borrow_investor` VALUES ('10','4','1','6','1','40000.00','426.67','0.00','0.00','0.00','0.00','0.00','0.00','1429857382','1432483199','0','0.00','0','0');/* DBReback Separation */
 /* 插入数据 `lzh_borrow_investor` */
 INSERT INTO `lzh_borrow_investor` VALUES ('11','4','1','19','1','100.00','1.07','0.00','0.00','0.00','0.00','0.00','0.00','1429857469','1432483199','0','0.00','0','0');/* DBReback Separation */
 /* 插入数据 `lzh_borrow_investor` */
 INSERT INTO `lzh_borrow_investor` VALUES ('12','4','1','14','1','5000.00','53.33','0.00','0.00','0.00','0.00','0.00','0.00','1429857549','1432483199','0','0.00','0','0');/* DBReback Separation */
 /* 插入数据 `lzh_borrow_investor` */
 INSERT INTO `lzh_borrow_investor` VALUES ('13','4','1','31','1','1000.00','10.67','0.00','0.00','0.00','0.00','0.00','0.00','1429857692','1432483199','0','0.00','0','0');/* DBReback Separation */
 /* 插入数据 `lzh_borrow_investor` */
 INSERT INTO `lzh_borrow_investor` VALUES ('14','4','1','7','1','500.00','5.33','0.00','0.00','0.00','0.00','0.00','0.00','1429857896','1432483199','0','0.00','0','0');/* DBReback Separation */
 /* 插入数据 `lzh_borrow_investor` */
 INSERT INTO `lzh_borrow_investor` VALUES ('15','4','1','7','1','500.00','5.33','0.00','0.00','0.00','0.00','0.00','0.00','1429858006','1432483199','0','0.00','0','0');/* DBReback Separation */
 /* 插入数据 `lzh_borrow_investor` */
 INSERT INTO `lzh_borrow_investor` VALUES ('16','4','1','24','1','400.00','4.27','0.00','0.00','0.00','0.00','0.00','0.00','1429858082','1432483199','0','0.00','0','0');/* DBReback Separation */
 /* 插入数据 `lzh_borrow_investor` */
 INSERT INTO `lzh_borrow_investor` VALUES ('17','4','1','32','1','1000.00','10.67','0.00','0.00','0.00','0.00','0.00','0.00','1429858427','1432483199','0','0.00','0','0');/* DBReback Separation */
 /* 插入数据 `lzh_borrow_investor` */
 INSERT INTO `lzh_borrow_investor` VALUES ('18','4','1','6','1','10000.00','106.67','0.00','0.00','0.00','0.00','0.00','0.00','1429858568','1432483199','0','0.00','0','0');/* DBReback Separation */
 /* 插入数据 `lzh_borrow_investor` */
 INSERT INTO `lzh_borrow_investor` VALUES ('19','4','1','12','1','100.00','1.07','0.00','0.00','0.00','0.00','0.00','0.00','1429858752','1432483199','0','0.00','0','0');/* DBReback Separation */
 /* 插入数据 `lzh_borrow_investor` */
 INSERT INTO `lzh_borrow_investor` VALUES ('20','4','1','15','1','1000.00','10.67','0.00','0.00','0.00','0.00','0.00','0.00','1429858877','1432483199','0','0.00','0','0');/* DBReback Separation */
 /* 插入数据 `lzh_borrow_investor` */
 INSERT INTO `lzh_borrow_investor` VALUES ('21','4','1','19','1','400.00','4.27','0.00','0.00','0.00','0.00','0.00','0.00','1429859594','1432483199','0','0.00','0','0');/* DBReback Separation */
 /* 插入数据 `lzh_borrow_investor` */
 INSERT INTO `lzh_borrow_investor` VALUES ('22','4','1','8','1','1000.00','10.67','0.00','0.00','0.00','0.00','0.00','0.00','1429859705','1432483199','0','0.00','0','0');/* DBReback Separation */
 /* 插入数据 `lzh_borrow_investor` */
 INSERT INTO `lzh_borrow_investor` VALUES ('23','4','1','34','1','1000.00','10.67','0.00','0.00','0.00','0.00','0.00','0.00','1429860032','1432483199','0','0.00','0','0');/* DBReback Separation */
 /* 插入数据 `lzh_borrow_investor` */
 INSERT INTO `lzh_borrow_investor` VALUES ('24','4','1','6','1','10200.00','108.80','0.00','0.00','0.00','0.00','0.00','0.00','1429860956','1432483199','0','0.00','0','0');/* DBReback Separation */ 
 /* 数据表结构 `lzh_borrow_tip`*/ 
 DROP TABLE IF EXISTS `lzh_borrow_tip`;/* DBReback Separation */ 
 CREATE TABLE `lzh_borrow_tip` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `uid` int(10) unsigned NOT NULL,
  `interest_rate` decimal(5,2) NOT NULL,
  `borrow_type` tinyint(3) unsigned NOT NULL,
  `duration_from` tinyint(3) unsigned NOT NULL,
  `duration_to` tinyint(3) unsigned NOT NULL,
  `account_money` decimal(15,2) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `borrow_type` (`borrow_type`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;/* DBReback Separation */ 
 /* 数据表结构 `lzh_borrow_verify`*/ 
 DROP TABLE IF EXISTS `lzh_borrow_verify`;/* DBReback Separation */ 
 CREATE TABLE `lzh_borrow_verify` (
  `borrow_id` int(11) unsigned NOT NULL,
  `deal_user` mediumint(10) unsigned NOT NULL,
  `deal_time` int(10) unsigned NOT NULL,
  `deal_info` varchar(50) NOT NULL,
  `deal_time_2` int(10) unsigned NOT NULL,
  `deal_user_2` mediumint(10) unsigned NOT NULL,
  `deal_info_2` varchar(50) NOT NULL,
  `deal_status` tinyint(3) unsigned NOT NULL,
  `deal_status_2` tinyint(3) unsigned NOT NULL,
  PRIMARY KEY (`borrow_id`),
  KEY `borrow_id` (`borrow_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;/* DBReback Separation */
 /* 插入数据 `lzh_borrow_verify` */
 INSERT INTO `lzh_borrow_verify` VALUES ('1','113','1429843529','测试','1429861263','113','财融第一标，庆祝！','2','6');/* DBReback Separation */ 
 /* 数据表结构 `lzh_borrow_vouch`*/ 
 DROP TABLE IF EXISTS `lzh_borrow_vouch`;/* DBReback Separation */ 
 CREATE TABLE `lzh_borrow_vouch` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `borrow_id` int(10) unsigned NOT NULL,
  `uid` int(10) unsigned NOT NULL,
  `uname` varchar(20) NOT NULL,
  `vouch_money` decimal(15,2) NOT NULL,
  `vouch_reward_rate` decimal(4,2) NOT NULL,
  `vouch_reward_money` decimal(15,2) NOT NULL,
  `add_ip` varchar(16) NOT NULL,
  `vouch_time` int(11) NOT NULL,
  `status` tinyint(3) unsigned NOT NULL DEFAULT '0',
  `substitute_money` decimal(15,2) NOT NULL,
  `get_back` decimal(15,2) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `borrow_id` (`borrow_id`),
  KEY `uid` (`uid`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;/* DBReback Separation */ 
 /* 数据表结构 `lzh_comment`*/ 
 DROP TABLE IF EXISTS `lzh_comment`;/* DBReback Separation */ 
 CREATE TABLE `lzh_comment` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `uid` int(10) unsigned NOT NULL,
  `uname` varchar(20) NOT NULL,
  `tid` int(10) unsigned NOT NULL,
  `type` tinyint(4) NOT NULL,
  `comment` varchar(500) NOT NULL,
  `add_time` int(10) unsigned NOT NULL,
  `deal_time` int(10) unsigned NOT NULL,
  `deal_info` varchar(500) NOT NULL,
  `name` varchar(50) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `type` (`type`,`tid`,`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;/* DBReback Separation */ 
 /* 数据表结构 `lzh_current_info`*/ 
 DROP TABLE IF EXISTS `lzh_current_info`;/* DBReback Separation */ 
 CREATE TABLE `lzh_current_info` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `current_name` varchar(50) DEFAULT NULL,
  `interest_rate` decimal(15,2) NOT NULL DEFAULT '0.00',
  `current_money` decimal(15,2) NOT NULL DEFAULT '0.00',
  `one_money` decimal(15,2) NOT NULL DEFAULT '0.00',
  `have_money` decimal(15,2) NOT NULL DEFAULT '0.00',
  `status` tinyint(4) NOT NULL DEFAULT '0',
  `add_time` int(11) DEFAULT NULL,
  `total_interest` decimal(15,2) DEFAULT NULL,
  `max_money` decimal(15,2) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=10 DEFAULT CHARSET=utf8;/* DBReback Separation */
 /* 插入数据 `lzh_current_info` */
 INSERT INTO `lzh_current_info` VALUES ('3','第一期活期理财','10.00','100000.00','100.00','0.00','0','0','0.00','3000.00');/* DBReback Separation */
 /* 插入数据 `lzh_current_info` */
 INSERT INTO `lzh_current_info` VALUES ('4','第二期活期理财','10.00','100000.00','100.00','0.00','1','1428404563','0.00','3000.00');/* DBReback Separation */
 /* 插入数据 `lzh_current_info` */
 INSERT INTO `lzh_current_info` VALUES ('5','借钱买灰机','5.00','10000.00','100.00','10000.00','2','1428544416','0.00','1000.00');/* DBReback Separation */
 /* 插入数据 `lzh_current_info` */
 INSERT INTO `lzh_current_info` VALUES ('6','活期标的标题','2.00','1000.00','100.00','0.00','1','1429513295','','500.00');/* DBReback Separation */
 /* 插入数据 `lzh_current_info` */
 INSERT INTO `lzh_current_info` VALUES ('7','活期标1的标','2.00','1000000.00','100.00','0.00','1','1429513542','','500.00');/* DBReback Separation */
 /* 插入数据 `lzh_current_info` */
 INSERT INTO `lzh_current_info` VALUES ('8','活旗标的标','2.00','1000000.00','100.00','0.00','1','1429513654','','0.00');/* DBReback Separation */
 /* 插入数据 `lzh_current_info` */
 INSERT INTO `lzh_current_info` VALUES ('9','胚子的标','2.00','100000.00','100.00','0.00','1','1429513763','','100000.00');/* DBReback Separation */ 
 /* 数据表结构 `lzh_current_investor`*/ 
 DROP TABLE IF EXISTS `lzh_current_investor`;/* DBReback Separation */ 
 CREATE TABLE `lzh_current_investor` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `invest_uid` int(11) NOT NULL DEFAULT '0',
  `buy_money` decimal(15,2) NOT NULL DEFAULT '0.00',
  `status` tinyint(4) NOT NULL DEFAULT '0',
  `current_id` int(11) NOT NULL DEFAULT '0',
  `add_time` int(11) DEFAULT NULL,
  `interest_rate` decimal(15,2) NOT NULL DEFAULT '0.00',
  `order` varchar(50) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=33 DEFAULT CHARSET=utf8;/* DBReback Separation */
 /* 插入数据 `lzh_current_investor` */
 INSERT INTO `lzh_current_investor` VALUES ('23','7','1000.00','1','5','1428642772','5.00','LCI9601428642772');/* DBReback Separation */
 /* 插入数据 `lzh_current_investor` */
 INSERT INTO `lzh_current_investor` VALUES ('24','7','1000.00','1','5','1428642794','5.00','LCI8621428642794');/* DBReback Separation */
 /* 插入数据 `lzh_current_investor` */
 INSERT INTO `lzh_current_investor` VALUES ('25','16','1000.00','1','5','1428907372','5.00','LCI2101428907372');/* DBReback Separation */
 /* 插入数据 `lzh_current_investor` */
 INSERT INTO `lzh_current_investor` VALUES ('26','11','1000.00','1','5','1429151822','5.00','LCI3171429151822');/* DBReback Separation */
 /* 插入数据 `lzh_current_investor` */
 INSERT INTO `lzh_current_investor` VALUES ('27','11','1000.00','1','5','1429151840','5.00','LCI6821429151840');/* DBReback Separation */
 /* 插入数据 `lzh_current_investor` */
 INSERT INTO `lzh_current_investor` VALUES ('28','11','1000.00','1','5','1429151845','5.00','LCI7981429151845');/* DBReback Separation */
 /* 插入数据 `lzh_current_investor` */
 INSERT INTO `lzh_current_investor` VALUES ('29','11','1000.00','1','5','1429151850','5.00','LCI2941429151850');/* DBReback Separation */
 /* 插入数据 `lzh_current_investor` */
 INSERT INTO `lzh_current_investor` VALUES ('30','11','1000.00','1','5','1429151854','5.00','LCI6291429151854');/* DBReback Separation */
 /* 插入数据 `lzh_current_investor` */
 INSERT INTO `lzh_current_investor` VALUES ('31','11','1000.00','1','5','1429151859','5.00','LCI5001429151859');/* DBReback Separation */
 /* 插入数据 `lzh_current_investor` */
 INSERT INTO `lzh_current_investor` VALUES ('32','11','1000.00','1','5','1429151864','5.00','LCI3161429151864');/* DBReback Separation */ 
 /* 数据表结构 `lzh_donate`*/ 
 DROP TABLE IF EXISTS `lzh_donate`;/* DBReback Separation */ 
 CREATE TABLE `lzh_donate` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `age` tinyint(3) unsigned NOT NULL,
  `area_id` tinyint(4) NOT NULL,
  `donate_name` varchar(50) NOT NULL,
  `need_money` int(11) NOT NULL,
  `bank_num` varchar(30) NOT NULL,
  `use` varchar(20) NOT NULL,
  `contact` varchar(50) NOT NULL,
  `address` varchar(150) NOT NULL,
  `bank_address` varchar(150) NOT NULL,
  `idcard` varchar(30) NOT NULL,
  `education` varchar(20) NOT NULL,
  `sex` varchar(5) NOT NULL,
  `zhiwei` varchar(20) NOT NULL,
  `danwei` varchar(60) NOT NULL,
  `qq` varchar(30) NOT NULL,
  `info` text NOT NULL,
  `thumb` varchar(100) NOT NULL,
  `title` varchar(40) NOT NULL,
  `resource` varchar(30) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `use` (`use`,`area_id`,`age`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;/* DBReback Separation */ 
 /* 数据表结构 `lzh_enterprise`*/ 
 DROP TABLE IF EXISTS `lzh_enterprise`;/* DBReback Separation */ 
 CREATE TABLE `lzh_enterprise` (
  `e_id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(50) CHARACTER SET utf8 NOT NULL,
  `intro` varchar(255) CHARACTER SET utf8 NOT NULL,
  `type` int(11) NOT NULL,
  `methods` int(11) NOT NULL,
  `brandname` varchar(50) CHARACTER SET utf8 NOT NULL,
  `money` int(11) NOT NULL,
  `money_max` int(11) NOT NULL,
  `money_min` int(11) NOT NULL,
  `deadline` tinyint(3) NOT NULL,
  `deadline_max` int(11) NOT NULL,
  `deadline_min` int(11) NOT NULL,
  `monthly` int(11) NOT NULL,
  `repayment_type` int(11) NOT NULL,
  `total_cost` float(11,0) NOT NULL,
  `loan_time` int(11) NOT NULL,
  `state` int(11) NOT NULL DEFAULT '0',
  `details` text CHARACTER SET utf8 NOT NULL,
  `success` int(11) NOT NULL,
  `logo` varchar(255) CHARACTER SET utf8 NOT NULL,
  `shuoming` varchar(255) CHARACTER SET ucs2 NOT NULL,
  `add_time` int(11) NOT NULL,
  `identity` int(11) NOT NULL,
  `house` int(11) NOT NULL,
  `vehicle` int(11) NOT NULL,
  `credit` int(11) NOT NULL,
  `is_show` int(1) NOT NULL DEFAULT '1',
  `strength` varchar(100) CHARACTER SET utf8 NOT NULL,
  `yuefei` float NOT NULL,
  `chenggong` int(11) NOT NULL DEFAULT '80',
  `sl` varchar(255) CHARACTER SET utf8 NOT NULL,
  PRIMARY KEY (`e_id`)
) ENGINE=MyISAM AUTO_INCREMENT=78 DEFAULT CHARSET=latin1;/* DBReback Separation */
 /* 插入数据 `lzh_enterprise` */
 INSERT INTO `lzh_enterprise` VALUES ('64','法国恢复供货','速度','2','0','发生的方式','50000','50000','20000','12','12','12','5000','3','6000','12','0','<p>现在存在瑕疵</p>','1','./UF/Uploads/Enterprise/m_Hydrangeas.jpg','问问','1403507484','1','3','4','4','1','我的的萨斯','12','80','./UF/Uploads/Enterprise/n_Hydrangeas.jpg');/* DBReback Separation */
 /* 插入数据 `lzh_enterprise` */
 INSERT INTO `lzh_enterprise` VALUES ('65','asdasd','231','3','0','xcvxc','50000','50000','50000','12','12','12','12','2','21','3213','0','<p>xczxczx</p>','1','./UF/Uploads/Enterprise/m_Chrysanthemum.jpg','213','1403510174','3','2','3','2','1','sdas','0.55','0','./UF/Uploads/Enterprise/n_Chrysanthemum.jpg');/* DBReback Separation */
 /* 插入数据 `lzh_enterprise` */
 INSERT INTO `lzh_enterprise` VALUES ('73','下次vxcv','321321','4','0','斯蒂芬森','211321','321321','321321','127','32132','321','231321','3','2121','321321','0','<p>下次vxcvxv&nbsp;</p>','1','./UF/Uploads/Enterprise/m_Desert.jpg','321321','1403511989','3','3','3','2','1','阿斯达斯','12','12','./UF/Uploads/Enterprise/n_Desert.jpg');/* DBReback Separation */
 /* 插入数据 `lzh_enterprise` */
 INSERT INTO `lzh_enterprise` VALUES ('72','jkljklj','dfsdfsf','1','0','xzczxc','45546540','32232','2323','127','5','5','5000','2','23454554','233','0','<p>zxczxczxczxczxc</p>','1','./UF/Uploads/Enterprise/m_Koala.jpg','454','1403510256','2','5','3','2','1','sdasd','12','12','./UF/Uploads/Enterprise/n_Koala.jpg');/* DBReback Separation */
 /* 插入数据 `lzh_enterprise` */
 INSERT INTO `lzh_enterprise` VALUES ('75','信贷银行','没什么要求','3','0','没什么','500000','500000','100000','12','12','12','5000','5','5000','3','0','<h2 style=\"list-style-position:initial;list-style-image:initial;margin-top:20px;font-size:14px;font-weight:normal;height:30px;text-indent:10px;color:rgb(51, 51, 51);font-family:Microsoft YaHei, Helvetica, sans-serif, simsun;\">申请条件</h2><p style=\"list-style-position:initial;list-style-image:initial;height:30px;text-indent:10px;color:rgb(51, 51, 51);font-family:Microsoft YaHei, Helvetica, sans-serif, simsun;\">公司法人代表、经营2年以上、有抵押物</p><ol style=\"list-style-position:initial;list-style-image:initial;padding-left:0px;margin:0px 0px 0px 10px;color:rgb(51, 51, 51);font-family:Microsoft YaHei, Helvetica, sans-serif, simsun;\"><li style=\"list-style-type:none;list-style-position:initial;text-align:left;font-size:14px;\">1、申请人条件：申请人应为公司法人代表、持股10%以上的股东、实际控制人或个人工商户</li><li style=\"list-style-type:none;list-style-position:initial;text-align:left;font-size:14px;\">2、申请人条件：申请人应为公司法人代表、持股10%以上的股东、实际控制人或个人工商户</li><li style=\"list-style-type:none;list-style-position:initial;text-align:left;font-size:14px;\">3、申请人条件：申请人应为公司法人代表、持股10%以上的股东、实际控制人或个人工商户</li><li style=\"list-style-type:none;list-style-position:initial;text-align:left;font-size:14px;\">4、申请人条件：申请人应为公司法人代表、持股10%以上的股东、实际控制人或个人工商户</li><li style=\"list-style-type:none;list-style-position:initial;text-align:left;font-size:14px;\">5、申请人条件：申请人应为公司法人代表、持股10%以上的股东、实际控制人或个人工商户</li><li style=\"list-style-type:none;list-style-position:initial;text-align:left;font-size:14px;\">6、申请人条件：申请人应为公司法人代表、持股10%以上的股东、实际控制人或个人工商户</li><li style=\"list-style-type:none;list-style-position:initial;text-align:left;font-size:14px;\">7、申请人条件：申请人应为公司法人代表、持股10%以上的股东、实际控制人或个人工商户</li></ol><p style=\"list-style-position:initial;list-style-image:initial;height:30px;text-indent:10px;color:rgb(51, 51, 51);font-family:Microsoft YaHei, Helvetica, sans-serif, simsun;\"><span style=\"list-style-position:initial;list-style-image:initial;color:rgb(255, 96, 0);font-size:14px;font-weight:bold;\">温馨提示：经营2年以上、有抵押物方可申请</span></p><h2 style=\"list-style-position:initial;list-style-image:initial;margin-top:20px;font-size:14px;font-weight:normal;height:30px;text-indent:10px;color:rgb(51, 51, 51);font-family:Microsoft YaHei, Helvetica, sans-serif, simsun;\">所需材料</h2><ol style=\"list-style-position:initial;list-style-image:initial;padding-left:0px;margin:0px 0px 0px 10px;color:rgb(51, 51, 51);font-family:Microsoft YaHei, Helvetica, sans-serif, simsun;\"><li style=\"list-style-type:none;list-style-position:initial;text-align:left;font-size:14px;\">1、申请人条件：申请人应为公司法人代表、持股10%以上的股东、实际控制人或个人工商户</li><li style=\"list-style-type:none;list-style-position:initial;text-align:left;font-size:14px;\">2、申请人条件：申请人应为公司法人代表、持股10%以上的股东、实际控制人或个人工商户</li><li style=\"list-style-type:none;list-style-position:initial;text-align:left;font-size:14px;\">3、申请人条件：申请人应为公司法人代表、持股10%以上的股东、实际控制人或个人工商户</li><li style=\"list-style-type:none;list-style-position:initial;text-align:left;font-size:14px;\">4、申请人条件：申请人应为公司法人代表、持股10%以上的股东、实际控制人或个人工商户</li><li style=\"list-style-type:none;list-style-position:initial;text-align:left;font-size:14px;\">5、申请人条件：申请人应为公司法人代表、持股10%以上的股东、实际控制人或个人工商户</li></ol><h2 style=\"list-style-position:initial;list-style-image:initial;margin-top:20px;font-size:14px;font-weight:normal;height:30px;text-indent:10px;color:rgb(51, 51, 51);font-family:Microsoft YaHei, Helvetica, sans-serif, simsun;\">详细说明</h2><p style=\"list-style-position:initial;list-style-image:initial;height:30px;text-indent:10px;color:rgb(51, 51, 51);font-family:Microsoft YaHei, Helvetica, sans-serif, simsun;\">个人经营贷款个人经营贷款个人经营贷款个人经营贷款个人经营贷款个人经营贷款个人经营贷款个人经营贷款个人经营贷款个人经营贷款个人经营贷款个人经营贷款个人经营贷款个人经营贷款个人经营贷款</p>','1','./UF/Uploads/Enterprise/m_Tulips.jpg','必须有钱','1403854498','1','2','2','2','1','没有什么优势','0.99','90','./UF/Uploads/Enterprise/n_Tulips.jpg');/* DBReback Separation */ 
 /* 数据表结构 `lzh_face_apply`*/ 
 DROP TABLE IF EXISTS `lzh_face_apply`;/* DBReback Separation */ 
 CREATE TABLE `lzh_face_apply` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `uid` int(10) unsigned NOT NULL,
  `add_time` int(10) unsigned NOT NULL,
  `add_ip` varchar(16) NOT NULL,
  `apply_status` tinyint(3) unsigned NOT NULL DEFAULT '0',
  `credits` int(11) NOT NULL DEFAULT '0',
  `deal_user` int(10) unsigned NOT NULL,
  `deal_time` int(10) unsigned NOT NULL,
  `deal_info` varchar(50) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `uid` (`uid`,`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;/* DBReback Separation */ 
 /* 数据表结构 `lzh_feedback`*/ 
 DROP TABLE IF EXISTS `lzh_feedback`;/* DBReback Separation */ 
 CREATE TABLE `lzh_feedback` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `type` tinyint(3) unsigned NOT NULL,
  `name` varchar(30) NOT NULL,
  `contact` varchar(50) NOT NULL,
  `msg` varchar(500) NOT NULL,
  `ip` varchar(16) NOT NULL,
  `add_time` int(10) unsigned NOT NULL,
  `status` tinyint(3) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;/* DBReback Separation */ 
 /* 数据表结构 `lzh_friend`*/ 
 DROP TABLE IF EXISTS `lzh_friend`;/* DBReback Separation */ 
 CREATE TABLE `lzh_friend` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `link_txt` varchar(50) NOT NULL,
  `link_href` varchar(500) NOT NULL,
  `link_img` varchar(100) NOT NULL DEFAULT ' ',
  `link_order` int(1) NOT NULL DEFAULT '0',
  `link_type` int(1) NOT NULL DEFAULT '0',
  `is_show` int(1) NOT NULL DEFAULT '1',
  `game_id` int(11) NOT NULL DEFAULT '0',
  `game_name` char(50) NOT NULL DEFAULT '',
  PRIMARY KEY (`id`),
  KEY `game_id` (`game_id`)
) ENGINE=MyISAM AUTO_INCREMENT=53 DEFAULT CHARSET=utf8;/* DBReback Separation */
 /* 插入数据 `lzh_friend` */
 INSERT INTO `lzh_friend` VALUES ('38','www.rongtianxia.com','http://www.rongtianxia.com','UF/Uploads/Friends/20150421151523446.png','0','1','1','0','');/* DBReback Separation */
 /* 插入数据 `lzh_friend` */
 INSERT INTO `lzh_friend` VALUES ('36','汇付天下','http://www.chinapnr.com/','UF/Uploads/Friends/20150421152405833.png','0','1','1','0','');/* DBReback Separation */
 /* 插入数据 `lzh_friend` */
 INSERT INTO `lzh_friend` VALUES ('37','阿里云','http://www.aliyun.com/','UF/Uploads/Friends/20150421152517698.png','0','1','1','0','');/* DBReback Separation */
 /* 插入数据 `lzh_friend` */
 INSERT INTO `lzh_friend` VALUES ('46','国付宝','https://www.gopay.com.cn/','UF/Uploads/Friends/20150421152713467.png','0','1','1','0','');/* DBReback Separation */
 /* 插入数据 `lzh_friend` */
 INSERT INTO `lzh_friend` VALUES ('47','汇潮支付','http://www.ecpss.cn/new/index.htm','UF/Uploads/Friends/20150421152755617.png','0','1','1','0','');/* DBReback Separation */
 /* 插入数据 `lzh_friend` */
 INSERT INTO `lzh_friend` VALUES ('48','环讯支付','http://www.ips.com.cn/','UF/Uploads/Friends/20150421152843740.png','0','1','1','0','');/* DBReback Separation */ 
 /* 数据表结构 `lzh_global`*/ 
 DROP TABLE IF EXISTS `lzh_global`;/* DBReback Separation */ 
 CREATE TABLE `lzh_global` (
  `id` smallint(6) NOT NULL AUTO_INCREMENT,
  `type` varchar(10) NOT NULL,
  `text` text NOT NULL,
  `name` varchar(50) NOT NULL DEFAULT ' ',
  `tip` varchar(200) NOT NULL DEFAULT ' ',
  `order_sn` int(11) NOT NULL DEFAULT '0',
  `code` varchar(20) NOT NULL DEFAULT ' ',
  `is_sys` tinyint(3) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=119 DEFAULT CHARSET=utf8;/* DBReback Separation */
 /* 插入数据 `lzh_global` */
 INSERT INTO `lzh_global` VALUES ('20','textarea','财融天下股票配资,股票配资,股票投资,投资理财','网站关键词','在首页的keywords中显示','118','web_keywords','1');/* DBReback Separation */
 /* 插入数据 `lzh_global` */
 INSERT INTO `lzh_global` VALUES ('21','textarea','财融天下股票配资平台，低门槛高收益高，资金最高可放大到10倍,安全快捷的配资流程，强大的技术运营团队、独立研发的平台系统、科学严格的权限管理及银行级数据灾备系统保障用户线上的账户信息以及交易记录信息的绝对安全，为用户资金及个人信息提供360度无死角的信息安全保障。
','网站描述','在网站首页的描述中显示','117','web_descript','1');/* DBReback Separation */
 /* 插入数据 `lzh_global` */
 INSERT INTO `lzh_global` VALUES ('103','input','0',' 是否开启手动手机验证',' 0代表不开启，则由系统自动向会员发送手机验证码；1代表开启，表示由管理员在后台手动审核会员的手机验证','0','is_manual','1');/* DBReback Separation */
 /* 插入数据 `lzh_global` */
 INSERT INTO `lzh_global` VALUES ('102','input','23:59:59',' 流转标自动还款时钟设置','23:59:59 表示该流转标将会在还款当天的23:59:59由系统自动执行还款操作，填写请遵循hh:mm:ss格式','0','auto_back_time ','1');/* DBReback Separation */
 /* 插入数据 `lzh_global` */
 INSERT INTO `lzh_global` VALUES ('19','input','财融天下股票配资','网站名称','出现在每个页面的title后面','120','web_name','1');/* DBReback Separation */
 /* 插入数据 `lzh_global` */
 INSERT INTO `lzh_global` VALUES ('27','input','财融天下股票配资平台--自由理财,高杠杆高收益,快速配资,放大资金,安全快捷 ','首页title','首页标题','119','index_title','1');/* DBReback Separation */
 /* 插入数据 `lzh_global` */
 INSERT INTO `lzh_global` VALUES ('115','input','20','免费体验名额','免费配资体验每日名额','0','free_num','0');/* DBReback Separation */
 /* 插入数据 `lzh_global` */
 INSERT INTO `lzh_global` VALUES ('56','textarea','财融天下','网站底部','网站底部的版权和联系信息','116','bottom','1');/* DBReback Separation */
 /* 插入数据 `lzh_global` */
 INSERT INTO `lzh_global` VALUES ('114','input','','sdsad','dsad','0','sadsa','0');/* DBReback Separation */
 /* 插入数据 `lzh_global` */
 INSERT INTO `lzh_global` VALUES ('71','input','0','VIP费用','VIP费用(每年)','0','fee_vip','1');/* DBReback Separation */
 /* 插入数据 `lzh_global` */
 INSERT INTO `lzh_global` VALUES ('72','input','1|8.8','逾期罚息','逾期后罚息的计算,(3|8)表示逾期3天开始算罚息,每天千分之8','110','fee_expired','1');/* DBReback Separation */
 /* 插入数据 `lzh_global` */
 INSERT INTO `lzh_global` VALUES ('73','input','10|10','催收费','逾期以后的催收费,(30|2)表示逾期30天以后开始算每天千分之2的催收费','111','fee_call','1');/* DBReback Separation */
 /* 插入数据 `lzh_global` */
 INSERT INTO `lzh_global` VALUES ('95','input','5000-20000|1|20001-50000|1.2|50001|1.5',' 线下充值奖励',' 填入5000-10000|1|10001-30000|1.5|30001|2 表示，线下充值金额在5000至10000以内的奖励千分之1，在10000至30000以内的奖励千分之1.5，大于30000时奖励千分之2','0','offline_reward','1');/* DBReback Separation */
 /* 插入数据 `lzh_global` */
 INSERT INTO `lzh_global` VALUES ('64','input','5-10000|0-0|5-30','提现手续费','以10-50|0-0|3-30的形式填入，数字从左到右依次表示超出回款资金总额的每笔收取总额的千分之10作为手续费,最大手续费上限50元;提现在回款总金额内的每笔收费千分之0元，手续费上限0元;单日单笔提现上限3万,单日提现资金上限30万','10','fee_tqtx','1');/* DBReback Separation */
 /* 插入数据 `lzh_global` */
 INSERT INTO `lzh_global` VALUES ('66','input','0.05|24','发标时的年化利率','以10|24的形式填入，表示年化利率最小10%,最大24%','1','rate_lixi','1');/* DBReback Separation */
 /* 插入数据 `lzh_global` */
 INSERT INTO `lzh_global` VALUES ('69','input','0','投资者成交管理费','10表示收取投资者所赚利息的10%','113','fee_invest_manage','1');/* DBReback Separation */
 /* 插入数据 `lzh_global` */
 INSERT INTO `lzh_global` VALUES ('70','input','1|30','借款期限(按天)','以1|24的形式填入，以天为单位，表示按天借款时最少借款时间为1天，最多24天','1','borrow_duration_day','1');/* DBReback Separation */
 /* 插入数据 `lzh_global` */
 INSERT INTO `lzh_global` VALUES ('67','input','1|12','借款期限','以1|24的形式填入，以月为单位，表示最小借款时间为1个月，最大24个月','1','borrow_duration','1');/* DBReback Separation */
 /* 插入数据 `lzh_global` */
 INSERT INTO `lzh_global` VALUES ('74','input','0','借款保证金','借款者借款成功后冻结的保证金,填10表示借款总金额的10%','114','money_deposit','1');/* DBReback Separation */
 /* 插入数据 `lzh_global` */
 INSERT INTO `lzh_global` VALUES ('75','input','0','视频认证费用','','0','fee_video','1');/* DBReback Separation */
 /* 插入数据 `lzh_global` */
 INSERT INTO `lzh_global` VALUES ('76','input','0','现场认证费用','','0','fee_face','1');/* DBReback Separation */
 /* 插入数据 `lzh_global` */
 INSERT INTO `lzh_global` VALUES ('77','input','0','实名认证费用','','0','fee_idcard','1');/* DBReback Separation */
 /* 插入数据 `lzh_global` */
 INSERT INTO `lzh_global` VALUES ('78','input','0','VIP默认额度','','0','limit_vip','1');/* DBReback Separation */
 /* 插入数据 `lzh_global` */
 INSERT INTO `lzh_global` VALUES ('79','input','0.1|1|0.2|4','借款者管理费','以0.1|1|0.2|4的形式填入，表示按天时每天收取借款总额0.1%的管理费，按月时在借款期限小于等于4个月时收取借款总额1%的管理费，借款期限大于4个月时(收获取借款总额1%的管理费+超过4个月的时间里每月收取借款总额0.2%的管理费)','115','fee_borrow_manage','1');/* DBReback Separation */
 /* 插入数据 `lzh_global` */
 INSERT INTO `lzh_global` VALUES ('90','input','0','客服提成','客服提成比例,填2表示千分之二','0','customer_rate','1');/* DBReback Separation */
 /* 插入数据 `lzh_global` */
 INSERT INTO `lzh_global` VALUES ('91','input','-3|-10|100','非正常还款积分规则','填入-3|-10|100表示,迟还|逾期还款|比率  公式：扣减信用积分=需还金额/比率*（迟还|逾期）例如：借款1000元，迟还了10天，即1000/100*(-3)= -30分，表示扣减了30分信用积分','0','credit_borrow','1');/* DBReback Separation */
 /* 插入数据 `lzh_global` */
 INSERT INTO `lzh_global` VALUES ('92','input','1','给投资人的积分','表示每1000元借出1天加1个投资积分，投标积分计算公式为：投资金额*天数/1000=投资积分，例如：投资天标1万，积分10000*1/1000=10分，一月标2万，积分20000*30/1000=600分。','0','invest_integral','1');/* DBReback Separation */
 /* 插入数据 `lzh_global` */
 INSERT INTO `lzh_global` VALUES ('93','input','1','邀请下线奖励','填入整数，如2表示千分之二,即你所邀请的下线每投标成功一次，您可获得千分之二的奖励','2','award_invest','1');/* DBReback Separation */
 /* 插入数据 `lzh_global` */
 INSERT INTO `lzh_global` VALUES ('96','input','23:59:59',' 到期还款时钟设置',' 23:59:59 表示借款人必须在还款到期当天的23:59:59之前进行还款，否则该标变为逾期。填写请遵照hh:mm:ss格式','0','back_time','1');/* DBReback Separation */
 /* 插入数据 `lzh_global` */
 INSERT INTO `lzh_global` VALUES ('97','input','0',' 银行卡修改开关',' 1表示可以修改，0表示不可以修改','0','edit_bank','1');/* DBReback Separation */
 /* 插入数据 `lzh_global` */
 INSERT INTO `lzh_global` VALUES ('98','input','1|1.5|2',' 回款投标自动奖励',' 以1|1.5|2的形式填入，表示回款续投一月标奖励1‰回款续投二月标奖励1.5‰ 回款续投三月标及以上奖励2‰，如果投标金额大于回款资金池金额，有效续投奖励以回款金额资金池总额为标准，否则以投标金额为准','0','today_reward','1');/* DBReback Separation */
 /* 插入数据 `lzh_global` */
 INSERT INTO `lzh_global` VALUES ('100','input','admin888',' 后台登陆路径',' 可修改后台登陆路径,格式为任意字母组合。例如：如填写admin，访问路径即为：【http://www.您的域名.com/rongtianxia/admin 】                      ','0','admin_url','1');/* DBReback Separation */
 /* 插入数据 `lzh_global` */
 INSERT INTO `lzh_global` VALUES ('104','input','1','债权转让手续费','转让价格的百分比，比如15（15%），不能为负数。0表示不收取手续费','0','debt_fee','1');/* DBReback Separation */
 /* 插入数据 `lzh_global` */
 INSERT INTO `lzh_global` VALUES ('105','input','1','债权转让是否审核','是否开启后台审核 1审核；0不审核','0','debt_audit','1');/* DBReback Separation */
 /* 插入数据 `lzh_global` */
 INSERT INTO `lzh_global` VALUES ('106','input','30',' 抽奖消耗积分','每抽奖一次所要消耗的积分','0','lottery_cost','1');/* DBReback Separation */
 /* 插入数据 `lzh_global` */
 INSERT INTO `lzh_global` VALUES ('112','input','0','投非秒标奖励','以元为单位，输入30就是30元人民币','0','nomb_reward','0');/* DBReback Separation */
 /* 插入数据 `lzh_global` */
 INSERT INTO `lzh_global` VALUES ('113','input','1','是否开启注册奖励','0表示不开始，1表示开启。','0','is_reward','0');/* DBReback Separation */
 /* 插入数据 `lzh_global` */
 INSERT INTO `lzh_global` VALUES ('116','input','【财融天下】','短信落款配置','短信落款配置项','0','system_signature','0');/* DBReback Separation */
 /* 插入数据 `lzh_global` */
 INSERT INTO `lzh_global` VALUES ('118','input','5','配资专员佣金比例','表示配资专员拿到的佣金百分比','0','commision_ratio','0');/* DBReback Separation */ 
 /* 数据表结构 `lzh_handler`*/ 
 DROP TABLE IF EXISTS `lzh_handler`;/* DBReback Separation */ 
 CREATE TABLE `lzh_handler` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) CHARACTER SET utf8 NOT NULL,
  `phone` char(11) NOT NULL,
  `company` varchar(100) CHARACTER SET utf8 NOT NULL,
  `add_time` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=31 DEFAULT CHARSET=latin1;/* DBReback Separation */
 /* 插入数据 `lzh_handler` */
 INSERT INTO `lzh_handler` VALUES ('2','张吉庆','18515157554','吉庆','1403231880');/* DBReback Separation */
 /* 插入数据 `lzh_handler` */
 INSERT INTO `lzh_handler` VALUES ('3','张吉庆','15110271848','撒旦','1403231892');/* DBReback Separation */
 /* 插入数据 `lzh_handler` */
 INSERT INTO `lzh_handler` VALUES ('4','张吉庆','13089856121','error','1403231908');/* DBReback Separation */
 /* 插入数据 `lzh_handler` */
 INSERT INTO `lzh_handler` VALUES ('5','张吉庆','15110271848','789','1403231938');/* DBReback Separation */
 /* 插入数据 `lzh_handler` */
 INSERT INTO `lzh_handler` VALUES ('6','张吉庆','15110271848','1212','1403231954');/* DBReback Separation */
 /* 插入数据 `lzh_handler` */
 INSERT INTO `lzh_handler` VALUES ('7','张吉庆','15110271848','1111111','1403231969');/* DBReback Separation */
 /* 插入数据 `lzh_handler` */
 INSERT INTO `lzh_handler` VALUES ('8','张吉庆','18515157554','zhang','1403434324');/* DBReback Separation */
 /* 插入数据 `lzh_handler` */
 INSERT INTO `lzh_handler` VALUES ('9','张吉庆','18515157554','zhang','1403434361');/* DBReback Separation */
 /* 插入数据 `lzh_handler` */
 INSERT INTO `lzh_handler` VALUES ('29','张吉庆','18515157554','阿斯达','1403500069');/* DBReback Separation */
 /* 插入数据 `lzh_handler` */
 INSERT INTO `lzh_handler` VALUES ('30','豆','18311050886','河南','1403855088');/* DBReback Separation */ 
 /* 数据表结构 `lzh_hetong`*/ 
 DROP TABLE IF EXISTS `lzh_hetong`;/* DBReback Separation */ 
 CREATE TABLE `lzh_hetong` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `hetong_img` varchar(500) NOT NULL,
  `thumb_hetong_img` varchar(500) NOT NULL,
  `add_time` int(11) NOT NULL,
  `deal_user` varchar(100) NOT NULL COMMENT '操作人',
  `name` varchar(100) NOT NULL COMMENT '公司名称',
  `dizhi` varchar(200) NOT NULL COMMENT '公司地址',
  `tel` varchar(50) NOT NULL COMMENT '公司电话',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;/* DBReback Separation */ 
 /* 数据表结构 `lzh_homsuser`*/ 
 DROP TABLE IF EXISTS `lzh_homsuser`;/* DBReback Separation */ 
 CREATE TABLE `lzh_homsuser` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `homsuser` varchar(50) NOT NULL,
  `homspass` varchar(50) NOT NULL,
  `status` tinyint(2) NOT NULL DEFAULT '0',
  `uid` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=51 DEFAULT CHARSET=utf8;/* DBReback Separation */
 /* 插入数据 `lzh_homsuser` */
 INSERT INTO `lzh_homsuser` VALUES ('1','25036001','123456','1','31');/* DBReback Separation */
 /* 插入数据 `lzh_homsuser` */
 INSERT INTO `lzh_homsuser` VALUES ('2','25036002','123456','1','10');/* DBReback Separation */
 /* 插入数据 `lzh_homsuser` */
 INSERT INTO `lzh_homsuser` VALUES ('3','25036003','123456','1','24');/* DBReback Separation */
 /* 插入数据 `lzh_homsuser` */
 INSERT INTO `lzh_homsuser` VALUES ('4','25036004','123456','1','9');/* DBReback Separation */
 /* 插入数据 `lzh_homsuser` */
 INSERT INTO `lzh_homsuser` VALUES ('5','25036005','123456','1','22');/* DBReback Separation */
 /* 插入数据 `lzh_homsuser` */
 INSERT INTO `lzh_homsuser` VALUES ('6','25036006','123456','1','14');/* DBReback Separation */
 /* 插入数据 `lzh_homsuser` */
 INSERT INTO `lzh_homsuser` VALUES ('7','25036007','123456','1','5');/* DBReback Separation */
 /* 插入数据 `lzh_homsuser` */
 INSERT INTO `lzh_homsuser` VALUES ('8','25036008','123456','1','4');/* DBReback Separation */
 /* 插入数据 `lzh_homsuser` */
 INSERT INTO `lzh_homsuser` VALUES ('9','25036009','123456','1','16');/* DBReback Separation */
 /* 插入数据 `lzh_homsuser` */
 INSERT INTO `lzh_homsuser` VALUES ('10','25036010','123456','1','28');/* DBReback Separation */
 /* 插入数据 `lzh_homsuser` */
 INSERT INTO `lzh_homsuser` VALUES ('11','25036011','123456','1','15');/* DBReback Separation */
 /* 插入数据 `lzh_homsuser` */
 INSERT INTO `lzh_homsuser` VALUES ('12','25036012','123456','1','13');/* DBReback Separation */
 /* 插入数据 `lzh_homsuser` */
 INSERT INTO `lzh_homsuser` VALUES ('13','25036013','123456','1','18');/* DBReback Separation */
 /* 插入数据 `lzh_homsuser` */
 INSERT INTO `lzh_homsuser` VALUES ('14','25036014','123456','1','12');/* DBReback Separation */
 /* 插入数据 `lzh_homsuser` */
 INSERT INTO `lzh_homsuser` VALUES ('15','25036015','123456','1','26');/* DBReback Separation */
 /* 插入数据 `lzh_homsuser` */
 INSERT INTO `lzh_homsuser` VALUES ('16','25036016','123456','1','21');/* DBReback Separation */
 /* 插入数据 `lzh_homsuser` */
 INSERT INTO `lzh_homsuser` VALUES ('17','25036017','123456','1','3');/* DBReback Separation */
 /* 插入数据 `lzh_homsuser` */
 INSERT INTO `lzh_homsuser` VALUES ('18','25036018','123456','1','2');/* DBReback Separation */
 /* 插入数据 `lzh_homsuser` */
 INSERT INTO `lzh_homsuser` VALUES ('19','25036019','123456','1','11');/* DBReback Separation */
 /* 插入数据 `lzh_homsuser` */
 INSERT INTO `lzh_homsuser` VALUES ('20','25036020','123456','1','1');/* DBReback Separation */
 /* 插入数据 `lzh_homsuser` */
 INSERT INTO `lzh_homsuser` VALUES ('21','25036021','123456','0','0');/* DBReback Separation */
 /* 插入数据 `lzh_homsuser` */
 INSERT INTO `lzh_homsuser` VALUES ('22','25036022','123456','0','0');/* DBReback Separation */
 /* 插入数据 `lzh_homsuser` */
 INSERT INTO `lzh_homsuser` VALUES ('23','25036023','123456','0','0');/* DBReback Separation */
 /* 插入数据 `lzh_homsuser` */
 INSERT INTO `lzh_homsuser` VALUES ('24','25036024','123456','0','0');/* DBReback Separation */
 /* 插入数据 `lzh_homsuser` */
 INSERT INTO `lzh_homsuser` VALUES ('25','25036025','123456','0','0');/* DBReback Separation */
 /* 插入数据 `lzh_homsuser` */
 INSERT INTO `lzh_homsuser` VALUES ('26','25036026','123456','0','0');/* DBReback Separation */
 /* 插入数据 `lzh_homsuser` */
 INSERT INTO `lzh_homsuser` VALUES ('27','25036027','123456','0','0');/* DBReback Separation */
 /* 插入数据 `lzh_homsuser` */
 INSERT INTO `lzh_homsuser` VALUES ('28','25036028','123456','0','0');/* DBReback Separation */
 /* 插入数据 `lzh_homsuser` */
 INSERT INTO `lzh_homsuser` VALUES ('29','25036029','123456','1','27');/* DBReback Separation */
 /* 插入数据 `lzh_homsuser` */
 INSERT INTO `lzh_homsuser` VALUES ('30','25036030','123456','1','39');/* DBReback Separation */
 /* 插入数据 `lzh_homsuser` */
 INSERT INTO `lzh_homsuser` VALUES ('31','25036031','123456','0','0');/* DBReback Separation */
 /* 插入数据 `lzh_homsuser` */
 INSERT INTO `lzh_homsuser` VALUES ('32','25036032','123456','0','0');/* DBReback Separation */
 /* 插入数据 `lzh_homsuser` */
 INSERT INTO `lzh_homsuser` VALUES ('33','25036033','123456','0','0');/* DBReback Separation */
 /* 插入数据 `lzh_homsuser` */
 INSERT INTO `lzh_homsuser` VALUES ('34','25036034','123456','0','0');/* DBReback Separation */
 /* 插入数据 `lzh_homsuser` */
 INSERT INTO `lzh_homsuser` VALUES ('35','25036035','123456','0','0');/* DBReback Separation */
 /* 插入数据 `lzh_homsuser` */
 INSERT INTO `lzh_homsuser` VALUES ('36','25036036','123456','0','0');/* DBReback Separation */
 /* 插入数据 `lzh_homsuser` */
 INSERT INTO `lzh_homsuser` VALUES ('37','25036037','123456','0','0');/* DBReback Separation */
 /* 插入数据 `lzh_homsuser` */
 INSERT INTO `lzh_homsuser` VALUES ('38','25036038','123456','0','0');/* DBReback Separation */
 /* 插入数据 `lzh_homsuser` */
 INSERT INTO `lzh_homsuser` VALUES ('39','25036039','123456','0','0');/* DBReback Separation */
 /* 插入数据 `lzh_homsuser` */
 INSERT INTO `lzh_homsuser` VALUES ('40','25036040','123456','0','0');/* DBReback Separation */
 /* 插入数据 `lzh_homsuser` */
 INSERT INTO `lzh_homsuser` VALUES ('41','25036041','123456','0','0');/* DBReback Separation */
 /* 插入数据 `lzh_homsuser` */
 INSERT INTO `lzh_homsuser` VALUES ('42','25036042','123456','0','0');/* DBReback Separation */
 /* 插入数据 `lzh_homsuser` */
 INSERT INTO `lzh_homsuser` VALUES ('43','25036043','123456','0','0');/* DBReback Separation */
 /* 插入数据 `lzh_homsuser` */
 INSERT INTO `lzh_homsuser` VALUES ('44','25036044','123456','0','0');/* DBReback Separation */
 /* 插入数据 `lzh_homsuser` */
 INSERT INTO `lzh_homsuser` VALUES ('45','25036045','123456','0','0');/* DBReback Separation */
 /* 插入数据 `lzh_homsuser` */
 INSERT INTO `lzh_homsuser` VALUES ('46','25036046','123456','0','0');/* DBReback Separation */
 /* 插入数据 `lzh_homsuser` */
 INSERT INTO `lzh_homsuser` VALUES ('47','25036047','123456','0','0');/* DBReback Separation */
 /* 插入数据 `lzh_homsuser` */
 INSERT INTO `lzh_homsuser` VALUES ('48','25036048','123456','0','0');/* DBReback Separation */
 /* 插入数据 `lzh_homsuser` */
 INSERT INTO `lzh_homsuser` VALUES ('49','25036049','123456','0','0');/* DBReback Separation */
 /* 插入数据 `lzh_homsuser` */
 INSERT INTO `lzh_homsuser` VALUES ('50','25036050','123456','0','0');/* DBReback Separation */ 
 /* 数据表结构 `lzh_inner_msg`*/ 
 DROP TABLE IF EXISTS `lzh_inner_msg`;/* DBReback Separation */ 
 CREATE TABLE `lzh_inner_msg` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `uid` int(10) unsigned NOT NULL,
  `title` varchar(50) NOT NULL,
  `msg` text NOT NULL,
  `send_time` int(10) unsigned NOT NULL,
  `status` tinyint(4) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `uid` (`uid`,`id`,`status`)
) ENGINE=MyISAM AUTO_INCREMENT=47 DEFAULT CHARSET=utf8;/* DBReback Separation */
 /* 插入数据 `lzh_inner_msg` */
 INSERT INTO `lzh_inner_msg` VALUES ('1','4','您的VIP申请审核已通过','您的VIP申请审核已通过','1429839977','0');/* DBReback Separation */
 /* 插入数据 `lzh_inner_msg` */
 INSERT INTO `lzh_inner_msg` VALUES ('2','1','你好，测试下','你好，测试下','1429841925','0');/* DBReback Separation */
 /* 插入数据 `lzh_inner_msg` */
 INSERT INTO `lzh_inner_msg` VALUES ('3','1','刚刚您的借款标初审通过','您发布的第1号借款标刚刚初审通过','1429843529','0');/* DBReback Separation */
 /* 插入数据 `lzh_inner_msg` */
 INSERT INTO `lzh_inner_msg` VALUES ('4','17','您的VIP申请审核已通过','您的VIP申请审核已通过','1429844861','0');/* DBReback Separation */
 /* 插入数据 `lzh_inner_msg` */
 INSERT INTO `lzh_inner_msg` VALUES ('5','14','您的VIP申请审核已通过','您的VIP申请审核已通过','1429845778','0');/* DBReback Separation */
 /* 插入数据 `lzh_inner_msg` */
 INSERT INTO `lzh_inner_msg` VALUES ('6','15','您的VIP申请审核已通过','您的VIP申请审核已通过','1429845783','1');/* DBReback Separation */
 /* 插入数据 `lzh_inner_msg` */
 INSERT INTO `lzh_inner_msg` VALUES ('7','13','您的VIP申请审核已通过','您的VIP申请审核已通过','1429845789','1');/* DBReback Separation */
 /* 插入数据 `lzh_inner_msg` */
 INSERT INTO `lzh_inner_msg` VALUES ('8','22','您的VIP申请审核已通过','您的VIP申请审核已通过','1429845794','0');/* DBReback Separation */
 /* 插入数据 `lzh_inner_msg` */
 INSERT INTO `lzh_inner_msg` VALUES ('9','20','您的VIP申请审核已通过','您的VIP申请审核已通过','1429845802','0');/* DBReback Separation */
 /* 插入数据 `lzh_inner_msg` */
 INSERT INTO `lzh_inner_msg` VALUES ('10','10','您的VIP申请审核已通过','您的VIP申请审核已通过','1429845810','0');/* DBReback Separation */
 /* 插入数据 `lzh_inner_msg` */
 INSERT INTO `lzh_inner_msg` VALUES ('11','22','您刚刚修改了登陆密码','您刚刚修改了登陆密码,如不是自己操作,请尽快联系客服','1429846135','0');/* DBReback Separation */
 /* 插入数据 `lzh_inner_msg` */
 INSERT INTO `lzh_inner_msg` VALUES ('12','22','您刚刚修改了提现的银行帐户','您刚刚修改了提现的银行帐户,如不是自己操作,请尽快联系客服','1429846782','0');/* DBReback Separation */
 /* 插入数据 `lzh_inner_msg` */
 INSERT INTO `lzh_inner_msg` VALUES ('13','15','您刚刚修改了提现的银行帐户','您刚刚修改了提现的银行帐户,如不是自己操作,请尽快联系客服','1429847286','1');/* DBReback Separation */
 /* 插入数据 `lzh_inner_msg` */
 INSERT INTO `lzh_inner_msg` VALUES ('14','3','您刚刚修改了提现的银行帐户','您刚刚修改了提现的银行帐户,如不是自己操作,请尽快联系客服','1429850248','0');/* DBReback Separation */
 /* 插入数据 `lzh_inner_msg` */
 INSERT INTO `lzh_inner_msg` VALUES ('15','3','您的VIP申请审核已通过','您的VIP申请审核已通过','1429850760','0');/* DBReback Separation */
 /* 插入数据 `lzh_inner_msg` */
 INSERT INTO `lzh_inner_msg` VALUES ('16','16','您刚刚修改了登陆密码','您刚刚修改了登陆密码,如不是自己操作,请尽快联系客服','1429854208','0');/* DBReback Separation */
 /* 插入数据 `lzh_inner_msg` */
 INSERT INTO `lzh_inner_msg` VALUES ('17','16','您的VIP申请审核已通过','您的VIP申请审核已通过','1429855692','0');/* DBReback Separation */
 /* 插入数据 `lzh_inner_msg` */
 INSERT INTO `lzh_inner_msg` VALUES ('18','9','您的VIP申请审核已通过','您的VIP申请审核已通过','1429855700','0');/* DBReback Separation */
 /* 插入数据 `lzh_inner_msg` */
 INSERT INTO `lzh_inner_msg` VALUES ('19','19','您刚刚修改了提现的银行帐户','您刚刚修改了提现的银行帐户,如不是自己操作,请尽快联系客服','1429856486','0');/* DBReback Separation */
 /* 插入数据 `lzh_inner_msg` */
 INSERT INTO `lzh_inner_msg` VALUES ('20','8','您刚刚修改了登陆密码','您刚刚修改了登陆密码,如不是自己操作,请尽快联系客服','1429859229','0');/* DBReback Separation */
 /* 插入数据 `lzh_inner_msg` */
 INSERT INTO `lzh_inner_msg` VALUES ('21','13','您投标的第1号借款借款成功','您投标的借款成功了','1429861262','1');/* DBReback Separation */
 /* 插入数据 `lzh_inner_msg` */
 INSERT INTO `lzh_inner_msg` VALUES ('22','22','您投标的第1号借款借款成功','您投标的借款成功了','1429861262','0');/* DBReback Separation */
 /* 插入数据 `lzh_inner_msg` */
 INSERT INTO `lzh_inner_msg` VALUES ('23','15','您投标的第1号借款借款成功','您投标的借款成功了','1429861262','0');/* DBReback Separation */
 /* 插入数据 `lzh_inner_msg` */
 INSERT INTO `lzh_inner_msg` VALUES ('24','3','您投标的第1号借款借款成功','您投标的借款成功了','1429861262','0');/* DBReback Separation */
 /* 插入数据 `lzh_inner_msg` */
 INSERT INTO `lzh_inner_msg` VALUES ('25','9','您投标的第1号借款借款成功','您投标的借款成功了','1429861262','0');/* DBReback Separation */
 /* 插入数据 `lzh_inner_msg` */
 INSERT INTO `lzh_inner_msg` VALUES ('26','16','您投标的第1号借款借款成功','您投标的借款成功了','1429861262','0');/* DBReback Separation */
 /* 插入数据 `lzh_inner_msg` */
 INSERT INTO `lzh_inner_msg` VALUES ('29','24','您投标的第1号借款借款成功','您投标的借款成功了','1429861262','0');/* DBReback Separation */
 /* 插入数据 `lzh_inner_msg` */
 INSERT INTO `lzh_inner_msg` VALUES ('30','6','您投标的第1号借款借款成功','您投标的借款成功了','1429861262','0');/* DBReback Separation */
 /* 插入数据 `lzh_inner_msg` */
 INSERT INTO `lzh_inner_msg` VALUES ('31','19','您投标的第1号借款借款成功','您投标的借款成功了','1429861262','0');/* DBReback Separation */
 /* 插入数据 `lzh_inner_msg` */
 INSERT INTO `lzh_inner_msg` VALUES ('32','14','您投标的第1号借款借款成功','您投标的借款成功了','1429861262','0');/* DBReback Separation */
 /* 插入数据 `lzh_inner_msg` */
 INSERT INTO `lzh_inner_msg` VALUES ('33','31','您投标的第1号借款借款成功','您投标的借款成功了','1429861262','0');/* DBReback Separation */
 /* 插入数据 `lzh_inner_msg` */
 INSERT INTO `lzh_inner_msg` VALUES ('34','7','您投标的第1号借款借款成功','您投标的借款成功了','1429861262','0');/* DBReback Separation */
 /* 插入数据 `lzh_inner_msg` */
 INSERT INTO `lzh_inner_msg` VALUES ('35','7','您投标的第1号借款借款成功','您投标的借款成功了','1429861262','0');/* DBReback Separation */
 /* 插入数据 `lzh_inner_msg` */
 INSERT INTO `lzh_inner_msg` VALUES ('36','24','您投标的第1号借款借款成功','您投标的借款成功了','1429861262','0');/* DBReback Separation */
 /* 插入数据 `lzh_inner_msg` */
 INSERT INTO `lzh_inner_msg` VALUES ('37','32','您投标的第1号借款借款成功','您投标的借款成功了','1429861262','0');/* DBReback Separation */
 /* 插入数据 `lzh_inner_msg` */
 INSERT INTO `lzh_inner_msg` VALUES ('38','6','您投标的第1号借款借款成功','您投标的借款成功了','1429861262','0');/* DBReback Separation */
 /* 插入数据 `lzh_inner_msg` */
 INSERT INTO `lzh_inner_msg` VALUES ('39','12','您投标的第1号借款借款成功','您投标的借款成功了','1429861262','0');/* DBReback Separation */
 /* 插入数据 `lzh_inner_msg` */
 INSERT INTO `lzh_inner_msg` VALUES ('40','15','您投标的第1号借款借款成功','您投标的借款成功了','1429861262','0');/* DBReback Separation */
 /* 插入数据 `lzh_inner_msg` */
 INSERT INTO `lzh_inner_msg` VALUES ('41','19','您投标的第1号借款借款成功','您投标的借款成功了','1429861262','0');/* DBReback Separation */
 /* 插入数据 `lzh_inner_msg` */
 INSERT INTO `lzh_inner_msg` VALUES ('42','8','您投标的第1号借款借款成功','您投标的借款成功了','1429861262','0');/* DBReback Separation */
 /* 插入数据 `lzh_inner_msg` */
 INSERT INTO `lzh_inner_msg` VALUES ('43','34','您投标的第1号借款借款成功','您投标的借款成功了','1429861262','0');/* DBReback Separation */
 /* 插入数据 `lzh_inner_msg` */
 INSERT INTO `lzh_inner_msg` VALUES ('44','6','您投标的第1号借款借款成功','您投标的借款成功了','1429861262','0');/* DBReback Separation */
 /* 插入数据 `lzh_inner_msg` */
 INSERT INTO `lzh_inner_msg` VALUES ('45','1','刚刚您的借款标复审通过','您发布的第1号借款标刚刚复审通过','1429861263','0');/* DBReback Separation */
 /* 插入数据 `lzh_inner_msg` */
 INSERT INTO `lzh_inner_msg` VALUES ('46','24','您刚刚修改了提现的银行帐户','您刚刚修改了提现的银行帐户,如不是自己操作,请尽快联系客服','1429861274','0');/* DBReback Separation */ 
 /* 数据表结构 `lzh_invest_credit`*/ 
 DROP TABLE IF EXISTS `lzh_invest_credit`;/* DBReback Separation */ 
 CREATE TABLE `lzh_invest_credit` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `uid` int(10) unsigned NOT NULL,
  `borrow_id` int(10) unsigned NOT NULL,
  `invest_money` decimal(15,2) unsigned NOT NULL,
  `invest_type` tinyint(3) unsigned NOT NULL,
  `duration` tinyint(3) unsigned NOT NULL,
  `get_credit` float(15,2) unsigned NOT NULL,
  `add_time` int(10) unsigned NOT NULL,
  `add_ip` varchar(16) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;/* DBReback Separation */ 
 /* 数据表结构 `lzh_invest_detb`*/ 
 DROP TABLE IF EXISTS `lzh_invest_detb`;/* DBReback Separation */ 
 CREATE TABLE `lzh_invest_detb` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `invest_id` int(10) unsigned NOT NULL DEFAULT '0',
  `status` tinyint(1) unsigned NOT NULL DEFAULT '99',
  `sell_uid` int(10) unsigned NOT NULL,
  `transfer_price` decimal(15,2) unsigned NOT NULL DEFAULT '0.00',
  `money` decimal(15,2) unsigned NOT NULL DEFAULT '0.00',
  `period` tinyint(5) unsigned NOT NULL DEFAULT '0',
  `total_period` tinyint(5) unsigned NOT NULL DEFAULT '0',
  `valid` int(10) unsigned NOT NULL DEFAULT '0',
  `remark` text NOT NULL,
  `serialid` varchar(15) NOT NULL,
  `cancel_time` int(10) unsigned NOT NULL,
  `cancel_times` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `buy_uid` int(10) unsigned NOT NULL DEFAULT '0',
  `buy_time` int(10) unsigned NOT NULL DEFAULT '0',
  `addtime` int(10) unsigned NOT NULL DEFAULT '0',
  `ip` char(19) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;/* DBReback Separation */ 
 /* 数据表结构 `lzh_investor_detail`*/ 
 DROP TABLE IF EXISTS `lzh_investor_detail`;/* DBReback Separation */ 
 CREATE TABLE `lzh_investor_detail` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `repayment_time` int(10) unsigned NOT NULL DEFAULT '0',
  `borrow_id` int(10) unsigned NOT NULL,
  `invest_id` int(10) unsigned NOT NULL,
  `investor_uid` int(10) unsigned NOT NULL,
  `borrow_uid` int(10) unsigned NOT NULL,
  `capital` decimal(15,2) NOT NULL,
  `interest` decimal(15,2) NOT NULL,
  `interest_fee` decimal(15,2) NOT NULL,
  `status` tinyint(3) unsigned NOT NULL,
  `receive_interest` decimal(15,2) NOT NULL,
  `receive_capital` decimal(15,2) NOT NULL,
  `sort_order` tinyint(3) unsigned NOT NULL,
  `total` tinyint(3) unsigned NOT NULL,
  `deadline` int(10) unsigned NOT NULL,
  `expired_money` decimal(15,2) NOT NULL,
  `expired_days` tinyint(3) unsigned NOT NULL DEFAULT '0',
  `call_fee` decimal(5,2) NOT NULL,
  `substitute_money` decimal(15,2) NOT NULL,
  `substitute_time` int(10) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `invest_id` (`invest_id`,`status`,`deadline`),
  KEY `borrow_id` (`borrow_id`,`sort_order`,`investor_uid`)
) ENGINE=InnoDB AUTO_INCREMENT=25 DEFAULT CHARSET=utf8;/* DBReback Separation */
 /* 插入数据 `lzh_investor_detail` */
 INSERT INTO `lzh_investor_detail` VALUES ('1','0','1','1','13','1','1000.00','10.67','0.00','7','0.00','0.00','1','1','1432483199','0.00','0','0.00','0.00','0');/* DBReback Separation */
 /* 插入数据 `lzh_investor_detail` */
 INSERT INTO `lzh_investor_detail` VALUES ('2','0','1','2','22','1','5000.00','53.33','0.00','7','0.00','0.00','1','1','1432483199','0.00','0','0.00','0.00','0');/* DBReback Separation */
 /* 插入数据 `lzh_investor_detail` */
 INSERT INTO `lzh_investor_detail` VALUES ('3','0','1','3','15','1','1000.00','10.67','0.00','7','0.00','0.00','1','1','1432483199','0.00','0','0.00','0.00','0');/* DBReback Separation */
 /* 插入数据 `lzh_investor_detail` */
 INSERT INTO `lzh_investor_detail` VALUES ('4','0','1','4','3','1','10000.00','106.67','0.00','7','0.00','0.00','1','1','1432483199','0.00','0','0.00','0.00','0');/* DBReback Separation */
 /* 插入数据 `lzh_investor_detail` */
 INSERT INTO `lzh_investor_detail` VALUES ('5','0','1','5','9','1','200.00','2.13','0.00','7','0.00','0.00','1','1','1432483199','0.00','0','0.00','0.00','0');/* DBReback Separation */
 /* 插入数据 `lzh_investor_detail` */
 INSERT INTO `lzh_investor_detail` VALUES ('6','0','1','6','16','1','4000.00','42.67','0.00','7','0.00','0.00','1','1','1432483199','0.00','0','0.00','0.00','0');/* DBReback Separation */
 /* 插入数据 `lzh_investor_detail` */
 INSERT INTO `lzh_investor_detail` VALUES ('7','0','1','7','26','1','5000.00','53.33','0.00','7','0.00','0.00','1','1','1432483199','0.00','0','0.00','0.00','0');/* DBReback Separation */
 /* 插入数据 `lzh_investor_detail` */
 INSERT INTO `lzh_investor_detail` VALUES ('8','0','1','8','26','1','1500.00','16.00','0.00','7','0.00','0.00','1','1','1432483199','0.00','0','0.00','0.00','0');/* DBReback Separation */
 /* 插入数据 `lzh_investor_detail` */
 INSERT INTO `lzh_investor_detail` VALUES ('9','0','1','9','24','1','100.00','1.07','0.00','7','0.00','0.00','1','1','1432483199','0.00','0','0.00','0.00','0');/* DBReback Separation */
 /* 插入数据 `lzh_investor_detail` */
 INSERT INTO `lzh_investor_detail` VALUES ('10','0','1','10','6','1','40000.00','426.67','0.00','7','0.00','0.00','1','1','1432483199','0.00','0','0.00','0.00','0');/* DBReback Separation */
 /* 插入数据 `lzh_investor_detail` */
 INSERT INTO `lzh_investor_detail` VALUES ('11','0','1','11','19','1','100.00','1.07','0.00','7','0.00','0.00','1','1','1432483199','0.00','0','0.00','0.00','0');/* DBReback Separation */
 /* 插入数据 `lzh_investor_detail` */
 INSERT INTO `lzh_investor_detail` VALUES ('12','0','1','12','14','1','5000.00','53.33','0.00','7','0.00','0.00','1','1','1432483199','0.00','0','0.00','0.00','0');/* DBReback Separation */
 /* 插入数据 `lzh_investor_detail` */
 INSERT INTO `lzh_investor_detail` VALUES ('13','0','1','13','31','1','1000.00','10.67','0.00','7','0.00','0.00','1','1','1432483199','0.00','0','0.00','0.00','0');/* DBReback Separation */
 /* 插入数据 `lzh_investor_detail` */
 INSERT INTO `lzh_investor_detail` VALUES ('14','0','1','14','7','1','500.00','5.33','0.00','7','0.00','0.00','1','1','1432483199','0.00','0','0.00','0.00','0');/* DBReback Separation */
 /* 插入数据 `lzh_investor_detail` */
 INSERT INTO `lzh_investor_detail` VALUES ('15','0','1','15','7','1','500.00','5.33','0.00','7','0.00','0.00','1','1','1432483199','0.00','0','0.00','0.00','0');/* DBReback Separation */
 /* 插入数据 `lzh_investor_detail` */
 INSERT INTO `lzh_investor_detail` VALUES ('16','0','1','16','24','1','400.00','4.27','0.00','7','0.00','0.00','1','1','1432483199','0.00','0','0.00','0.00','0');/* DBReback Separation */
 /* 插入数据 `lzh_investor_detail` */
 INSERT INTO `lzh_investor_detail` VALUES ('17','0','1','17','32','1','1000.00','10.67','0.00','7','0.00','0.00','1','1','1432483199','0.00','0','0.00','0.00','0');/* DBReback Separation */
 /* 插入数据 `lzh_investor_detail` */
 INSERT INTO `lzh_investor_detail` VALUES ('18','0','1','18','6','1','10000.00','106.67','0.00','7','0.00','0.00','1','1','1432483199','0.00','0','0.00','0.00','0');/* DBReback Separation */
 /* 插入数据 `lzh_investor_detail` */
 INSERT INTO `lzh_investor_detail` VALUES ('19','0','1','19','12','1','100.00','1.07','0.00','7','0.00','0.00','1','1','1432483199','0.00','0','0.00','0.00','0');/* DBReback Separation */
 /* 插入数据 `lzh_investor_detail` */
 INSERT INTO `lzh_investor_detail` VALUES ('20','0','1','20','15','1','1000.00','10.67','0.00','7','0.00','0.00','1','1','1432483199','0.00','0','0.00','0.00','0');/* DBReback Separation */
 /* 插入数据 `lzh_investor_detail` */
 INSERT INTO `lzh_investor_detail` VALUES ('21','0','1','21','19','1','400.00','4.27','0.00','7','0.00','0.00','1','1','1432483199','0.00','0','0.00','0.00','0');/* DBReback Separation */
 /* 插入数据 `lzh_investor_detail` */
 INSERT INTO `lzh_investor_detail` VALUES ('22','0','1','22','8','1','1000.00','10.67','0.00','7','0.00','0.00','1','1','1432483199','0.00','0','0.00','0.00','0');/* DBReback Separation */
 /* 插入数据 `lzh_investor_detail` */
 INSERT INTO `lzh_investor_detail` VALUES ('23','0','1','23','34','1','1000.00','10.67','0.00','7','0.00','0.00','1','1','1432483199','0.00','0','0.00','0.00','0');/* DBReback Separation */
 /* 插入数据 `lzh_investor_detail` */
 INSERT INTO `lzh_investor_detail` VALUES ('24','0','1','24','6','1','10200.00','108.80','0.00','7','0.00','0.00','1','1','1432483199','0.00','0','0.00','0.00','0');/* DBReback Separation */ 
 /* 数据表结构 `lzh_jifen_choujiang`*/ 
 DROP TABLE IF EXISTS `lzh_jifen_choujiang`;/* DBReback Separation */ 
 CREATE TABLE `lzh_jifen_choujiang` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `uid` int(11) NOT NULL COMMENT '用户ID',
  `jp_id` int(11) DEFAULT '0' COMMENT '奖品ID',
  `jp_title` varchar(100) DEFAULT '' COMMENT '奖品名称',
  `process` int(10) DEFAULT '0' COMMENT '0未处理1已处理2测试不用处理',
  `userip` varchar(100) DEFAULT NULL COMMENT '用户IP',
  `addtime` int(11) DEFAULT '0' COMMENT '抽奖时间',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;/* DBReback Separation */ 
 /* 数据表结构 `lzh_jubao`*/ 
 DROP TABLE IF EXISTS `lzh_jubao`;/* DBReback Separation */ 
 CREATE TABLE `lzh_jubao` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `uid` int(11) NOT NULL,
  `uemail` varchar(60) NOT NULL,
  `b_uid` int(11) NOT NULL,
  `b_uname` varchar(50) NOT NULL,
  `reason` varchar(100) NOT NULL,
  `text` varchar(500) NOT NULL,
  `add_time` int(10) unsigned NOT NULL,
  `add_ip` varchar(16) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;/* DBReback Separation */ 
 /* 数据表结构 `lzh_k_invest`*/ 
 DROP TABLE IF EXISTS `lzh_k_invest`;/* DBReback Separation */ 
 CREATE TABLE `lzh_k_invest` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(100) CHARACTER SET utf8 NOT NULL,
  `phone` char(11) NOT NULL,
  `money` int(11) NOT NULL,
  `add_time` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=10 DEFAULT CHARSET=latin1;/* DBReback Separation */
 /* 插入数据 `lzh_k_invest` */
 INSERT INTO `lzh_k_invest` VALUES ('4','张吉庆','15110271848','100000','1403686048');/* DBReback Separation */
 /* 插入数据 `lzh_k_invest` */
 INSERT INTO `lzh_k_invest` VALUES ('3','张吉庆','15110271848','100000','1403677155');/* DBReback Separation */
 /* 插入数据 `lzh_k_invest` */
 INSERT INTO `lzh_k_invest` VALUES ('6','张吉庆','15110271848','10000000','1405905215');/* DBReback Separation */ 
 /* 数据表结构 `lzh_k_loan`*/ 
 DROP TABLE IF EXISTS `lzh_k_loan`;/* DBReback Separation */ 
 CREATE TABLE `lzh_k_loan` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(50) CHARACTER SET utf8 NOT NULL,
  `phone` char(11) CHARACTER SET utf8 NOT NULL,
  `money` int(11) NOT NULL,
  `add_time` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=30 DEFAULT CHARSET=latin1;/* DBReback Separation */
 /* 插入数据 `lzh_k_loan` */
 INSERT INTO `lzh_k_loan` VALUES ('20','郝婷','13401190416','50000','1403766876');/* DBReback Separation */
 /* 插入数据 `lzh_k_loan` */
 INSERT INTO `lzh_k_loan` VALUES ('21','范明雪','18800128335','200000','1405060410');/* DBReback Separation */
 /* 插入数据 `lzh_k_loan` */
 INSERT INTO `lzh_k_loan` VALUES ('22','柳柳','13811209826','100000','1405302543');/* DBReback Separation */ 
 /* 数据表结构 `lzh_kvtable`*/ 
 DROP TABLE IF EXISTS `lzh_kvtable`;/* DBReback Separation */ 
 CREATE TABLE `lzh_kvtable` (
  `id` smallint(5) unsigned NOT NULL AUTO_INCREMENT,
  `value` varchar(50) NOT NULL,
  `nid` varchar(10) NOT NULL,
  `sort_order` int(11) NOT NULL,
  `son_count` int(10) unsigned NOT NULL,
  `field_1` int(10) unsigned NOT NULL,
  `field_2` int(10) unsigned NOT NULL,
  `field_3` int(10) unsigned NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `nid` (`nid`,`value`,`sort_order`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;/* DBReback Separation */ 
 /* 数据表结构 `lzh_loan`*/ 
 DROP TABLE IF EXISTS `lzh_loan`;/* DBReback Separation */ 
 CREATE TABLE `lzh_loan` (
  `l_id` int(11) NOT NULL AUTO_INCREMENT,
  `e_id` int(11) NOT NULL,
  `person_money` int(11) NOT NULL,
  `person_name` varchar(100) CHARACTER SET utf8 NOT NULL,
  `person_phone` varchar(11) CHARACTER SET utf8 NOT NULL,
  `person_email` varchar(100) CHARACTER SET utf8 NOT NULL,
  `loan_time` int(11) NOT NULL,
  `term` int(11) NOT NULL,
  `person_identity` int(11) NOT NULL,
  `person_house` int(11) NOT NULL,
  `countdition` text CHARACTER SET utf8 NOT NULL,
  PRIMARY KEY (`l_id`)
) ENGINE=MyISAM AUTO_INCREMENT=20 DEFAULT CHARSET=latin1;/* DBReback Separation */
 /* 插入数据 `lzh_loan` */
 INSERT INTO `lzh_loan` VALUES ('15','73','1000100','王先生','18310312295','','1403659205','4','3','0','参考以上范例填写您的详细信息');/* DBReback Separation */ 
 /* 数据表结构 `lzh_market_address`*/ 
 DROP TABLE IF EXISTS `lzh_market_address`;/* DBReback Separation */ 
 CREATE TABLE `lzh_market_address` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `uid` int(11) NOT NULL COMMENT '收货人ID',
  `proid` int(11) NOT NULL COMMENT '产品ID',
  `province` varchar(100) CHARACTER SET utf8 NOT NULL COMMENT '省',
  `city` varchar(100) CHARACTER SET utf8 NOT NULL COMMENT '市',
  `area` varchar(100) CHARACTER SET utf8 NOT NULL COMMENT '区/街道',
  `address` varchar(300) CHARACTER SET utf8 NOT NULL COMMENT '收货详细地址',
  `remark` text CHARACTER SET utf8 NOT NULL COMMENT '备注',
  `add_ip` varchar(16) CHARACTER SET utf8 NOT NULL COMMENT '添加者IP',
  `add_time` int(11) NOT NULL COMMENT '添加时间',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;/* DBReback Separation */ 
 /* 数据表结构 `lzh_market_goods`*/ 
 DROP TABLE IF EXISTS `lzh_market_goods`;/* DBReback Separation */ 
 CREATE TABLE `lzh_market_goods` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(50) NOT NULL,
  `description` varchar(200) NOT NULL,
  `style` varchar(200) NOT NULL,
  `img` varchar(50) CHARACTER SET latin1 COLLATE latin1_danish_ci NOT NULL,
  `small_img` varchar(100) NOT NULL COMMENT '小缩略图地址',
  `middle_img` varchar(100) NOT NULL COMMENT '中图',
  `big_img` varchar(100) CHARACTER SET latin1 COLLATE latin1_danish_ci NOT NULL COMMENT '商品大图',
  `price` int(10) NOT NULL,
  `cost` int(8) NOT NULL,
  `order_sn` int(8) NOT NULL DEFAULT '0',
  `add_time` int(12) unsigned NOT NULL,
  `is_sys` tinyint(3) unsigned NOT NULL DEFAULT '1',
  `jianjie` text NOT NULL,
  `canshu` text NOT NULL,
  `number` int(10) NOT NULL COMMENT '物品数量',
  `category` tinyint(4) NOT NULL DEFAULT '1' COMMENT '物品类别 1：实物；2：虚拟物品',
  `amount` int(10) NOT NULL COMMENT '限购数量',
  `convert` int(10) NOT NULL COMMENT '已兑换数量',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;/* DBReback Separation */ 
 /* 数据表结构 `lzh_market_jifenlist`*/ 
 DROP TABLE IF EXISTS `lzh_market_jifenlist`;/* DBReback Separation */ 
 CREATE TABLE `lzh_market_jifenlist` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `category` int(10) NOT NULL DEFAULT '2' COMMENT '物品类别 1：金钱；2：积分',
  `title` varchar(100) DEFAULT NULL COMMENT '奖品名称',
  `num` int(10) DEFAULT '0' COMMENT '奖品数量',
  `last_num` int(10) NOT NULL COMMENT '剩余数量',
  `hits` int(10) DEFAULT '0' COMMENT '已中奖次',
  `rate` int(10) DEFAULT '0' COMMENT '中奖机率',
  `value` int(10) NOT NULL COMMENT '可兑换价值',
  `order_sn` int(10) NOT NULL COMMENT '排序',
  `is_sys` tinyint(3) NOT NULL DEFAULT '1' COMMENT '是否上线 0：下线；1：上线',
  `add_ip` varchar(16) NOT NULL COMMENT '添加者IP',
  `add_time` int(11) NOT NULL COMMENT '添加时间',
  `b_img` varchar(200) NOT NULL COMMENT '奖品图片',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;/* DBReback Separation */ 
 /* 数据表结构 `lzh_market_log`*/ 
 DROP TABLE IF EXISTS `lzh_market_log`;/* DBReback Separation */ 
 CREATE TABLE `lzh_market_log` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `uid` int(10) unsigned NOT NULL,
  `type` tinyint(4) NOT NULL,
  `status` tinyint(4) NOT NULL,
  `way` int(11) NOT NULL COMMENT '领取方式',
  `gid` int(10) unsigned NOT NULL,
  `name` varchar(200) NOT NULL,
  `price` int(10) unsigned NOT NULL,
  `cost` int(10) unsigned NOT NULL,
  `num` tinyint(4) NOT NULL,
  `style` varchar(50) NOT NULL,
  `info` varchar(200) NOT NULL,
  `add_ip` varchar(16) NOT NULL,
  `add_time` int(10) unsigned NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;/* DBReback Separation */ 
 /* 数据表结构 `lzh_member_address`*/ 
 DROP TABLE IF EXISTS `lzh_member_address`;/* DBReback Separation */ 
 CREATE TABLE `lzh_member_address` (
  `id` mediumint(9) unsigned NOT NULL AUTO_INCREMENT,
  `uid` int(10) unsigned NOT NULL,
  `name` varchar(10) NOT NULL,
  `main_phone` varchar(20) NOT NULL,
  `secondary_phone` varchar(20) NOT NULL,
  `address` varchar(100) NOT NULL,
  `post_code` varchar(10) NOT NULL,
  `address_type` tinyint(4) NOT NULL DEFAULT '0',
  `province` smallint(5) unsigned NOT NULL,
  `city` smallint(5) unsigned NOT NULL,
  `district` smallint(5) unsigned NOT NULL,
  PRIMARY KEY (`id`),
  KEY `uid` (`uid`,`address_type`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;/* DBReback Separation */ 
 /* 数据表结构 `lzh_member_alipay`*/ 
 DROP TABLE IF EXISTS `lzh_member_alipay`;/* DBReback Separation */ 
 CREATE TABLE `lzh_member_alipay` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `uid` int(11) NOT NULL COMMENT '用户id',
  `money` decimal(10,0) NOT NULL COMMENT '充值金额',
  `ali_name` varchar(50) NOT NULL COMMENT '支付宝用户名',
  `add_time` int(11) NOT NULL COMMENT '添加时间',
  `status` tinyint(1) NOT NULL COMMENT '状态 1未处理 2充值成功 3充值失败',
  `u_name` varchar(50) DEFAULT NULL COMMENT '用户名',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=70 DEFAULT CHARSET=utf8;/* DBReback Separation */
 /* 插入数据 `lzh_member_alipay` */
 INSERT INTO `lzh_member_alipay` VALUES ('41','3','16000','13693650065','1429851050','2','lize');/* DBReback Separation */
 /* 插入数据 `lzh_member_alipay` */
 INSERT INTO `lzh_member_alipay` VALUES ('40','27','1','415419597@qq.com','1429850387','2','cs415419597');/* DBReback Separation */
 /* 插入数据 `lzh_member_alipay` */
 INSERT INTO `lzh_member_alipay` VALUES ('39','21','1','770155210@qq.com','1429850143','2','chaoyong');/* DBReback Separation */
 /* 插入数据 `lzh_member_alipay` */
 INSERT INTO `lzh_member_alipay` VALUES ('38','26','1','15201618692','1429846964','2','1029131145');/* DBReback Separation */
 /* 插入数据 `lzh_member_alipay` */
 INSERT INTO `lzh_member_alipay` VALUES ('37','12','101','孟庆敏','1429846902','2','mengqingmin');/* DBReback Separation */
 /* 插入数据 `lzh_member_alipay` */
 INSERT INTO `lzh_member_alipay` VALUES ('36','18','1','简大治','1429846893','2','jdz_ios');/* DBReback Separation */
 /* 插入数据 `lzh_member_alipay` */
 INSERT INTO `lzh_member_alipay` VALUES ('35','13','1','chenguser','1429846820','2','chenguser');/* DBReback Separation */
 /* 插入数据 `lzh_member_alipay` */
 INSERT INTO `lzh_member_alipay` VALUES ('34','23','0','18515157554','1429845956','3','root');/* DBReback Separation */
 /* 插入数据 `lzh_member_alipay` */
 INSERT INTO `lzh_member_alipay` VALUES ('33','11','1','许博','1429845952','3','dzsfo');/* DBReback Separation */
 /* 插入数据 `lzh_member_alipay` */
 INSERT INTO `lzh_member_alipay` VALUES ('32','16','50','周静红','1429845935','2','shouzhishouzhi');/* DBReback Separation */
 /* 插入数据 `lzh_member_alipay` */
 INSERT INTO `lzh_member_alipay` VALUES ('31','13','1000','chenguser','1429845785','2','chenguser');/* DBReback Separation */
 /* 插入数据 `lzh_member_alipay` */
 INSERT INTO `lzh_member_alipay` VALUES ('24','2','1','13693650065','1429774356','2','lize650065');/* DBReback Separation */
 /* 插入数据 `lzh_member_alipay` */
 INSERT INTO `lzh_member_alipay` VALUES ('25','1','10000','whttcy','1429776414','1','whttcy');/* DBReback Separation */
 /* 插入数据 `lzh_member_alipay` */
 INSERT INTO `lzh_member_alipay` VALUES ('26','5','1','13717798492@163.com','1429782878','2','yanmin');/* DBReback Separation */
 /* 插入数据 `lzh_member_alipay` */
 INSERT INTO `lzh_member_alipay` VALUES ('27','4','1','王洋洋','1429784087','2','wangyang');/* DBReback Separation */
 /* 插入数据 `lzh_member_alipay` */
 INSERT INTO `lzh_member_alipay` VALUES ('28','4','2','李小飞','1429784108','1','wangyang');/* DBReback Separation */
 /* 插入数据 `lzh_member_alipay` */
 INSERT INTO `lzh_member_alipay` VALUES ('29','4','0','黄喜明','1429784124','1','wangyang');/* DBReback Separation */
 /* 插入数据 `lzh_member_alipay` */
 INSERT INTO `lzh_member_alipay` VALUES ('30','16','50','周静红','1429845607','2','shouzhishouzhi');/* DBReback Separation */
 /* 插入数据 `lzh_member_alipay` */
 INSERT INTO `lzh_member_alipay` VALUES ('42','9','200','田晓玉','1429851379','2','田晓玉');/* DBReback Separation */
 /* 插入数据 `lzh_member_alipay` */
 INSERT INTO `lzh_member_alipay` VALUES ('43','28','1','13269501238','1429852046','2','请低下头');/* DBReback Separation */
 /* 插入数据 `lzh_member_alipay` */
 INSERT INTO `lzh_member_alipay` VALUES ('44','22','1','朱世翔','1429852501','2','swm0415');/* DBReback Separation */
 /* 插入数据 `lzh_member_alipay` */
 INSERT INTO `lzh_member_alipay` VALUES ('45','14','1','17710242027','1429852688','2','songyu');/* DBReback Separation */
 /* 插入数据 `lzh_member_alipay` */
 INSERT INTO `lzh_member_alipay` VALUES ('46','9','1','田晓玉','1429852699','2','田晓玉');/* DBReback Separation */
 /* 插入数据 `lzh_member_alipay` */
 INSERT INTO `lzh_member_alipay` VALUES ('47','24','1','18500278044','1429853140','2','tiantian');/* DBReback Separation */
 /* 插入数据 `lzh_member_alipay` */
 INSERT INTO `lzh_member_alipay` VALUES ('48','14','5000','17710242027','1429853174','2','songyu');/* DBReback Separation */
 /* 插入数据 `lzh_member_alipay` */
 INSERT INTO `lzh_member_alipay` VALUES ('49','16','4000','周静红','1429853456','2','shouzhishouzhi');/* DBReback Separation */
 /* 插入数据 `lzh_member_alipay` */
 INSERT INTO `lzh_member_alipay` VALUES ('50','10','1','赵海洋','1429853459','2','小屌丝');/* DBReback Separation */
 /* 插入数据 `lzh_member_alipay` */
 INSERT INTO `lzh_member_alipay` VALUES ('51','30','50','yuanhonglei','1429853959','3','yhl123');/* DBReback Separation */
 /* 插入数据 `lzh_member_alipay` */
 INSERT INTO `lzh_member_alipay` VALUES ('52','26','6500','15201618692','1429856005','2','1029131145');/* DBReback Separation */
 /* 插入数据 `lzh_member_alipay` */
 INSERT INTO `lzh_member_alipay` VALUES ('53','24','100','18500278044','1429856112','2','tiantian');/* DBReback Separation */
 /* 插入数据 `lzh_member_alipay` */
 INSERT INTO `lzh_member_alipay` VALUES ('54','15','1000','15901250626','1429856118','2','彭红');/* DBReback Separation */
 /* 插入数据 `lzh_member_alipay` */
 INSERT INTO `lzh_member_alipay` VALUES ('55','31','1000','wanglincha','1429856960','2','wanglincha');/* DBReback Separation */
 /* 插入数据 `lzh_member_alipay` */
 INSERT INTO `lzh_member_alipay` VALUES ('56','31','1000','13317341134','1429857139','3','wanglincha');/* DBReback Separation */
 /* 插入数据 `lzh_member_alipay` */
 INSERT INTO `lzh_member_alipay` VALUES ('57','7','1000','15801156647','1429857216','2','zsh123');/* DBReback Separation */
 /* 插入数据 `lzh_member_alipay` */
 INSERT INTO `lzh_member_alipay` VALUES ('58','33','1','党玉乾','1429857785','2','咩咩');/* DBReback Separation */
 /* 插入数据 `lzh_member_alipay` */
 INSERT INTO `lzh_member_alipay` VALUES ('59','24','400','18500278044','1429857932','2','tiantian');/* DBReback Separation */
 /* 插入数据 `lzh_member_alipay` */
 INSERT INTO `lzh_member_alipay` VALUES ('60','32','1000','18713510646','1429858077','2','648195165');/* DBReback Separation */
 /* 插入数据 `lzh_member_alipay` */
 INSERT INTO `lzh_member_alipay` VALUES ('61','32','1','18713510646','1429858814','2','648195165');/* DBReback Separation */
 /* 插入数据 `lzh_member_alipay` */
 INSERT INTO `lzh_member_alipay` VALUES ('62','8','1000','豆厘杰','1429859440','2','shubiao');/* DBReback Separation */
 /* 插入数据 `lzh_member_alipay` */
 INSERT INTO `lzh_member_alipay` VALUES ('63','19','400','15300066405','1429859511','2','zhengyu');/* DBReback Separation */
 /* 插入数据 `lzh_member_alipay` */
 INSERT INTO `lzh_member_alipay` VALUES ('64','35','1','15618509300@163.com','1429861928','2','xiedong123x');/* DBReback Separation */
 /* 插入数据 `lzh_member_alipay` */
 INSERT INTO `lzh_member_alipay` VALUES ('65','39','1','崔永锋01','1430098600','2','崔永锋');/* DBReback Separation */
 /* 插入数据 `lzh_member_alipay` */
 INSERT INTO `lzh_member_alipay` VALUES ('66','39','1','崔永锋01','1430098684','2','崔永锋');/* DBReback Separation */
 /* 插入数据 `lzh_member_alipay` */
 INSERT INTO `lzh_member_alipay` VALUES ('67','39','1','崔永锋','1430099040','2','崔永锋');/* DBReback Separation */
 /* 插入数据 `lzh_member_alipay` */
 INSERT INTO `lzh_member_alipay` VALUES ('68','39','1','13611134321','1430099307','1','崔永锋');/* DBReback Separation */
 /* 插入数据 `lzh_member_alipay` */
 INSERT INTO `lzh_member_alipay` VALUES ('69','39','1','崔永锋2012','1430099349','1','崔永锋');/* DBReback Separation */ 
 /* 数据表结构 `lzh_member_apply`*/ 
 DROP TABLE IF EXISTS `lzh_member_apply`;/* DBReback Separation */ 
 CREATE TABLE `lzh_member_apply` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `uid` int(10) unsigned NOT NULL,
  `add_time` int(10) unsigned NOT NULL,
  `add_ip` varchar(16) NOT NULL,
  `apply_status` tinyint(3) unsigned NOT NULL DEFAULT '0',
  `credit_money` decimal(15,2) NOT NULL,
  `deal_user` int(10) unsigned NOT NULL,
  `deal_time` int(10) unsigned NOT NULL,
  `deal_info` varchar(50) NOT NULL,
  `apply_type` tinyint(3) unsigned NOT NULL,
  `apply_money` decimal(15,2) NOT NULL,
  `apply_info` varchar(200) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `uid` (`uid`,`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;/* DBReback Separation */ 
 /* 数据表结构 `lzh_member_banks`*/ 
 DROP TABLE IF EXISTS `lzh_member_banks`;/* DBReback Separation */ 
 CREATE TABLE `lzh_member_banks` (
  `uid` int(10) unsigned NOT NULL,
  `bank_num` varchar(50) NOT NULL,
  `bank_province` varchar(20) NOT NULL,
  `bank_city` varchar(20) NOT NULL,
  `bank_address` varchar(100) NOT NULL,
  `bank_name` varchar(50) NOT NULL,
  `add_time` int(10) unsigned NOT NULL,
  `add_ip` varchar(16) NOT NULL,
  PRIMARY KEY (`uid`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;/* DBReback Separation */
 /* 插入数据 `lzh_member_banks` */
 INSERT INTO `lzh_member_banks` VALUES ('1','','','','','','1429842628','124.205.215.51');/* DBReback Separation */
 /* 插入数据 `lzh_member_banks` */
 INSERT INTO `lzh_member_banks` VALUES ('8','','','','','','1429842579','124.205.215.51');/* DBReback Separation */
 /* 插入数据 `lzh_member_banks` */
 INSERT INTO `lzh_member_banks` VALUES ('14','','','','','','0','');/* DBReback Separation */
 /* 插入数据 `lzh_member_banks` */
 INSERT INTO `lzh_member_banks` VALUES ('11','','','','','','0','');/* DBReback Separation */
 /* 插入数据 `lzh_member_banks` */
 INSERT INTO `lzh_member_banks` VALUES ('22','6217001370022722151','江苏','南京','珠江路支行','中国建设银行','1429846782','117.62.134.55');/* DBReback Separation */
 /* 插入数据 `lzh_member_banks` */
 INSERT INTO `lzh_member_banks` VALUES ('2','','','','','','0','');/* DBReback Separation */
 /* 插入数据 `lzh_member_banks` */
 INSERT INTO `lzh_member_banks` VALUES ('15','6222620910003718644','北京','北京','朝阳区大望路支行','交通银行','1429847286','117.62.134.55');/* DBReback Separation */
 /* 插入数据 `lzh_member_banks` */
 INSERT INTO `lzh_member_banks` VALUES ('3','6227000013130248061','北京','北京','清华大学支行','中国建设银行','1429850248','106.39.13.19');/* DBReback Separation */
 /* 插入数据 `lzh_member_banks` */
 INSERT INTO `lzh_member_banks` VALUES ('6','','','','','','1429857106','106.39.13.9');/* DBReback Separation */
 /* 插入数据 `lzh_member_banks` */
 INSERT INTO `lzh_member_banks` VALUES ('19','6217000010049078499','北京','北京','中国建设银行','中国建设银行','1429856486','106.39.13.19');/* DBReback Separation */
 /* 插入数据 `lzh_member_banks` */
 INSERT INTO `lzh_member_banks` VALUES ('24','6215590200002267508','北京','北京','回龙观支行','中国工商银行','1429861274','106.39.13.19');/* DBReback Separation */ 
 /* 数据表结构 `lzh_member_borrow_show`*/ 
 DROP TABLE IF EXISTS `lzh_member_borrow_show`;/* DBReback Separation */ 
 CREATE TABLE `lzh_member_borrow_show` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `uid` int(10) unsigned NOT NULL,
  `data_url` varchar(100) NOT NULL,
  `data_name` varchar(50) NOT NULL,
  `sort` int(8) unsigned NOT NULL,
  `deal_user` varchar(50) NOT NULL,
  `deal_time` int(10) unsigned NOT NULL,
  PRIMARY KEY (`id`),
  KEY `uid` (`uid`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;/* DBReback Separation */ 
 /* 数据表结构 `lzh_member_contact_info`*/ 
 DROP TABLE IF EXISTS `lzh_member_contact_info`;/* DBReback Separation */ 
 CREATE TABLE `lzh_member_contact_info` (
  `uid` int(10) unsigned NOT NULL,
  `address` varchar(200) NOT NULL,
  `tel` varchar(20) NOT NULL,
  `contact1` varchar(50) NOT NULL,
  `contact1_re` varchar(20) NOT NULL,
  `contact1_tel` varchar(50) NOT NULL,
  `contact2` varchar(50) NOT NULL,
  `contact2_re` varchar(20) NOT NULL,
  `contact2_tel` varchar(20) NOT NULL,
  `contact1_other` varchar(100) NOT NULL,
  `contact2_other` varchar(100) NOT NULL,
  `contact3` varchar(40) DEFAULT NULL,
  `contact3_re` varchar(20) DEFAULT NULL,
  `contact3_tel` varchar(100) DEFAULT NULL,
  `contact3_other` varchar(100) DEFAULT NULL,
  PRIMARY KEY (`uid`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;/* DBReback Separation */ 
 /* 数据表结构 `lzh_member_creditslog`*/ 
 DROP TABLE IF EXISTS `lzh_member_creditslog`;/* DBReback Separation */ 
 CREATE TABLE `lzh_member_creditslog` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `uid` int(10) unsigned NOT NULL,
  `type` tinyint(3) unsigned NOT NULL,
  `affect_credits` mediumint(9) NOT NULL,
  `account_credits` mediumint(9) NOT NULL,
  `info` varchar(50) NOT NULL,
  `add_time` int(10) unsigned NOT NULL,
  `add_ip` varchar(16) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `uid` (`uid`,`type`,`id`)
) ENGINE=InnoDB AUTO_INCREMENT=67 DEFAULT CHARSET=utf8;/* DBReback Separation */
 /* 插入数据 `lzh_member_creditslog` */
 INSERT INTO `lzh_member_creditslog` VALUES ('1','2','10','10','10','手机认证通过,奖励积分10','1429778210','124.205.215.55');/* DBReback Separation */
 /* 插入数据 `lzh_member_creditslog` */
 INSERT INTO `lzh_member_creditslog` VALUES ('2','3','10','10','10','手机认证通过,奖励积分10','1429778358','124.205.215.55');/* DBReback Separation */
 /* 插入数据 `lzh_member_creditslog` */
 INSERT INTO `lzh_member_creditslog` VALUES ('3','3','2','10','20','实名认证通过,奖励积分10','1429779101','124.205.215.55');/* DBReback Separation */
 /* 插入数据 `lzh_member_creditslog` */
 INSERT INTO `lzh_member_creditslog` VALUES ('4','4','10','10','10','手机认证通过,奖励积分10','1429780401','124.205.215.55');/* DBReback Separation */
 /* 插入数据 `lzh_member_creditslog` */
 INSERT INTO `lzh_member_creditslog` VALUES ('5','5','10','10','10','手机认证通过,奖励积分10','1429781890','124.205.215.55');/* DBReback Separation */
 /* 插入数据 `lzh_member_creditslog` */
 INSERT INTO `lzh_member_creditslog` VALUES ('6','6','10','10','10','手机认证通过,奖励积分10','1429781897','124.205.215.55');/* DBReback Separation */
 /* 插入数据 `lzh_member_creditslog` */
 INSERT INTO `lzh_member_creditslog` VALUES ('7','4','2','10','20','实名认证通过,奖励积分10','1429782394','124.205.215.55');/* DBReback Separation */
 /* 插入数据 `lzh_member_creditslog` */
 INSERT INTO `lzh_member_creditslog` VALUES ('8','5','2','10','20','实名认证通过,奖励积分10','1429782400','124.205.215.55');/* DBReback Separation */
 /* 插入数据 `lzh_member_creditslog` */
 INSERT INTO `lzh_member_creditslog` VALUES ('9','7','10','10','10','手机认证通过,奖励积分10','1429784022','124.205.215.55');/* DBReback Separation */
 /* 插入数据 `lzh_member_creditslog` */
 INSERT INTO `lzh_member_creditslog` VALUES ('10','8','10','10','10','手机认证通过,奖励积分10','1429785886','124.205.215.55');/* DBReback Separation */
 /* 插入数据 `lzh_member_creditslog` */
 INSERT INTO `lzh_member_creditslog` VALUES ('11','4','13','10','30','vip认证通过,奖励积分10','1429839977','124.205.215.51');/* DBReback Separation */
 /* 插入数据 `lzh_member_creditslog` */
 INSERT INTO `lzh_member_creditslog` VALUES ('12','1','10','10','10','手机认证通过,奖励积分10','1429840063','124.205.215.51');/* DBReback Separation */
 /* 插入数据 `lzh_member_creditslog` */
 INSERT INTO `lzh_member_creditslog` VALUES ('13','9','10','10','10','手机认证通过,奖励积分10','1429844109','124.205.215.51');/* DBReback Separation */
 /* 插入数据 `lzh_member_creditslog` */
 INSERT INTO `lzh_member_creditslog` VALUES ('14','10','10','10','10','手机认证通过,奖励积分10','1429844112','124.205.215.48');/* DBReback Separation */
 /* 插入数据 `lzh_member_creditslog` */
 INSERT INTO `lzh_member_creditslog` VALUES ('15','11','10','10','10','手机认证通过,奖励积分10','1429844444','124.205.215.51');/* DBReback Separation */
 /* 插入数据 `lzh_member_creditslog` */
 INSERT INTO `lzh_member_creditslog` VALUES ('16','12','10','10','10','手机认证通过,奖励积分10','1429844463','124.205.215.51');/* DBReback Separation */
 /* 插入数据 `lzh_member_creditslog` */
 INSERT INTO `lzh_member_creditslog` VALUES ('17','13','10','10','10','手机认证通过,奖励积分10','1429844471','124.205.215.51');/* DBReback Separation */
 /* 插入数据 `lzh_member_creditslog` */
 INSERT INTO `lzh_member_creditslog` VALUES ('18','14','10','10','10','手机认证通过,奖励积分10','1429844541','124.205.215.48');/* DBReback Separation */
 /* 插入数据 `lzh_member_creditslog` */
 INSERT INTO `lzh_member_creditslog` VALUES ('19','16','10','10','10','手机认证通过,奖励积分10','1429844609','124.205.215.51');/* DBReback Separation */
 /* 插入数据 `lzh_member_creditslog` */
 INSERT INTO `lzh_member_creditslog` VALUES ('20','17','10','10','10','手机认证通过,奖励积分10','1429844642','124.205.215.48');/* DBReback Separation */
 /* 插入数据 `lzh_member_creditslog` */
 INSERT INTO `lzh_member_creditslog` VALUES ('21','14','9','10','20','邮箱认证通过,奖励积分10','1429844781','124.205.215.48');/* DBReback Separation */
 /* 插入数据 `lzh_member_creditslog` */
 INSERT INTO `lzh_member_creditslog` VALUES ('22','17','13','10','20','vip认证通过,奖励积分10','1429844861','106.39.13.9');/* DBReback Separation */
 /* 插入数据 `lzh_member_creditslog` */
 INSERT INTO `lzh_member_creditslog` VALUES ('23','10','9','10','20','邮箱认证通过,奖励积分10','1429844940','106.39.13.19');/* DBReback Separation */
 /* 插入数据 `lzh_member_creditslog` */
 INSERT INTO `lzh_member_creditslog` VALUES ('24','19','9','10','10','邮箱认证通过,奖励积分10','1429845001','106.39.13.19');/* DBReback Separation */
 /* 插入数据 `lzh_member_creditslog` */
 INSERT INTO `lzh_member_creditslog` VALUES ('25','19','10','10','20','手机认证通过,奖励积分10','1429845043','106.39.13.19');/* DBReback Separation */
 /* 插入数据 `lzh_member_creditslog` */
 INSERT INTO `lzh_member_creditslog` VALUES ('26','13','9','10','20','邮箱认证通过,奖励积分10','1429845126','106.39.13.9');/* DBReback Separation */
 /* 插入数据 `lzh_member_creditslog` */
 INSERT INTO `lzh_member_creditslog` VALUES ('27','21','10','10','10','手机认证通过,奖励积分10','1429845339','106.39.13.9');/* DBReback Separation */
 /* 插入数据 `lzh_member_creditslog` */
 INSERT INTO `lzh_member_creditslog` VALUES ('28','22','10','10','10','手机认证通过,奖励积分10','1429845351','117.62.134.55');/* DBReback Separation */
 /* 插入数据 `lzh_member_creditslog` */
 INSERT INTO `lzh_member_creditslog` VALUES ('29','15','10','10','10','手机认证通过,奖励积分10','1429845406','117.62.134.55');/* DBReback Separation */
 /* 插入数据 `lzh_member_creditslog` */
 INSERT INTO `lzh_member_creditslog` VALUES ('30','15','9','10','20','邮箱认证通过,奖励积分10','1429845420','117.62.134.55');/* DBReback Separation */
 /* 插入数据 `lzh_member_creditslog` */
 INSERT INTO `lzh_member_creditslog` VALUES ('31','22','9','10','20','邮箱认证通过,奖励积分10','1429845427','117.62.134.55');/* DBReback Separation */
 /* 插入数据 `lzh_member_creditslog` */
 INSERT INTO `lzh_member_creditslog` VALUES ('32','14','13','10','30','vip认证通过,奖励积分10','1429845778','106.39.13.9');/* DBReback Separation */
 /* 插入数据 `lzh_member_creditslog` */
 INSERT INTO `lzh_member_creditslog` VALUES ('33','15','13','10','30','vip认证通过,奖励积分10','1429845783','106.39.13.9');/* DBReback Separation */
 /* 插入数据 `lzh_member_creditslog` */
 INSERT INTO `lzh_member_creditslog` VALUES ('34','13','13','10','30','vip认证通过,奖励积分10','1429845789','106.39.13.9');/* DBReback Separation */
 /* 插入数据 `lzh_member_creditslog` */
 INSERT INTO `lzh_member_creditslog` VALUES ('35','22','13','10','30','vip认证通过,奖励积分10','1429845794','106.39.13.9');/* DBReback Separation */
 /* 插入数据 `lzh_member_creditslog` */
 INSERT INTO `lzh_member_creditslog` VALUES ('36','9','9','10','20','邮箱认证通过,奖励积分10','1429845797','106.39.13.9');/* DBReback Separation */
 /* 插入数据 `lzh_member_creditslog` */
 INSERT INTO `lzh_member_creditslog` VALUES ('37','20','13','10','10','vip认证通过,奖励积分10','1429845802','106.39.13.9');/* DBReback Separation */
 /* 插入数据 `lzh_member_creditslog` */
 INSERT INTO `lzh_member_creditslog` VALUES ('38','10','13','10','30','vip认证通过,奖励积分10','1429845810','106.39.13.9');/* DBReback Separation */
 /* 插入数据 `lzh_member_creditslog` */
 INSERT INTO `lzh_member_creditslog` VALUES ('39','22','2','10','40','实名认证通过,奖励积分10','1429845820','106.39.13.9');/* DBReback Separation */
 /* 插入数据 `lzh_member_creditslog` */
 INSERT INTO `lzh_member_creditslog` VALUES ('40','15','2','10','40','实名认证通过,奖励积分10','1429845824','106.39.13.9');/* DBReback Separation */
 /* 插入数据 `lzh_member_creditslog` */
 INSERT INTO `lzh_member_creditslog` VALUES ('41','13','2','10','40','实名认证通过,奖励积分10','1429845829','106.39.13.9');/* DBReback Separation */
 /* 插入数据 `lzh_member_creditslog` */
 INSERT INTO `lzh_member_creditslog` VALUES ('42','23','10','10','10','手机认证通过,奖励积分10','1429845895','106.39.13.9');/* DBReback Separation */
 /* 插入数据 `lzh_member_creditslog` */
 INSERT INTO `lzh_member_creditslog` VALUES ('43','24','10','10','10','手机认证通过,奖励积分10','1429846016','106.39.13.19');/* DBReback Separation */
 /* 插入数据 `lzh_member_creditslog` */
 INSERT INTO `lzh_member_creditslog` VALUES ('44','14','2','10','40','实名认证通过,奖励积分10','1429846035','106.39.13.9');/* DBReback Separation */
 /* 插入数据 `lzh_member_creditslog` */
 INSERT INTO `lzh_member_creditslog` VALUES ('45','25','10','10','10','手机认证通过,奖励积分10','1429846128','106.39.13.19');/* DBReback Separation */
 /* 插入数据 `lzh_member_creditslog` */
 INSERT INTO `lzh_member_creditslog` VALUES ('46','26','10','10','10','手机认证通过,奖励积分10','1429846510','106.39.13.9');/* DBReback Separation */
 /* 插入数据 `lzh_member_creditslog` */
 INSERT INTO `lzh_member_creditslog` VALUES ('47','12','9','10','20','邮箱认证通过,奖励积分10','1429846561','106.39.13.9');/* DBReback Separation */
 /* 插入数据 `lzh_member_creditslog` */
 INSERT INTO `lzh_member_creditslog` VALUES ('48','24','2','10','20','实名认证通过,奖励积分10','1429846841','106.39.13.9');/* DBReback Separation */
 /* 插入数据 `lzh_member_creditslog` */
 INSERT INTO `lzh_member_creditslog` VALUES ('49','10','2','10','40','实名认证通过,奖励积分10','1429846860','106.39.13.9');/* DBReback Separation */
 /* 插入数据 `lzh_member_creditslog` */
 INSERT INTO `lzh_member_creditslog` VALUES ('50','3','9','10','30','邮箱认证通过,奖励积分10','1429849776','106.39.13.19');/* DBReback Separation */
 /* 插入数据 `lzh_member_creditslog` */
 INSERT INTO `lzh_member_creditslog` VALUES ('51','26','9','10','20','邮箱认证通过,奖励积分10','1429849995','106.39.13.9');/* DBReback Separation */
 /* 插入数据 `lzh_member_creditslog` */
 INSERT INTO `lzh_member_creditslog` VALUES ('52','3','13','10','40','vip认证通过,奖励积分10','1429850760','106.39.13.9');/* DBReback Separation */
 /* 插入数据 `lzh_member_creditslog` */
 INSERT INTO `lzh_member_creditslog` VALUES ('53','29','10','10','10','手机认证通过,奖励积分10','1429851917','106.39.13.19');/* DBReback Separation */
 /* 插入数据 `lzh_member_creditslog` */
 INSERT INTO `lzh_member_creditslog` VALUES ('54','9','2','10','30','实名认证通过,奖励积分10','1429853688','106.39.13.9');/* DBReback Separation */
 /* 插入数据 `lzh_member_creditslog` */
 INSERT INTO `lzh_member_creditslog` VALUES ('55','16','13','10','20','vip认证通过,奖励积分10','1429855692','106.39.13.9');/* DBReback Separation */
 /* 插入数据 `lzh_member_creditslog` */
 INSERT INTO `lzh_member_creditslog` VALUES ('56','9','13','10','40','vip认证通过,奖励积分10','1429855700','106.39.13.9');/* DBReback Separation */
 /* 插入数据 `lzh_member_creditslog` */
 INSERT INTO `lzh_member_creditslog` VALUES ('57','19','2','10','30','实名认证通过,奖励积分10','1429856134','106.39.13.9');/* DBReback Separation */
 /* 插入数据 `lzh_member_creditslog` */
 INSERT INTO `lzh_member_creditslog` VALUES ('58','31','10','10','10','手机认证通过,奖励积分10','1429856643','106.39.13.9');/* DBReback Separation */
 /* 插入数据 `lzh_member_creditslog` */
 INSERT INTO `lzh_member_creditslog` VALUES ('59','31','2','10','20','实名认证通过,奖励积分10','1429857003','106.39.13.9');/* DBReback Separation */
 /* 插入数据 `lzh_member_creditslog` */
 INSERT INTO `lzh_member_creditslog` VALUES ('60','32','10','10','10','手机认证通过,奖励积分10','1429857400','106.39.13.9');/* DBReback Separation */
 /* 插入数据 `lzh_member_creditslog` */
 INSERT INTO `lzh_member_creditslog` VALUES ('61','33','10','10','10','手机认证通过,奖励积分10','1429857556','106.39.13.9');/* DBReback Separation */
 /* 插入数据 `lzh_member_creditslog` */
 INSERT INTO `lzh_member_creditslog` VALUES ('62','34','10','10','10','手机认证通过,奖励积分10','1429859367','106.39.13.19');/* DBReback Separation */
 /* 插入数据 `lzh_member_creditslog` */
 INSERT INTO `lzh_member_creditslog` VALUES ('63','34','2','10','20','实名认证通过,奖励积分10','1429863607','106.39.13.9');/* DBReback Separation */
 /* 插入数据 `lzh_member_creditslog` */
 INSERT INTO `lzh_member_creditslog` VALUES ('64','37','10','10','10','手机认证通过,奖励积分10','1429975566','183.158.92.110');/* DBReback Separation */
 /* 插入数据 `lzh_member_creditslog` */
 INSERT INTO `lzh_member_creditslog` VALUES ('65','38','10','10','10','手机认证通过,奖励积分10','1430029214','182.38.128.146');/* DBReback Separation */
 /* 插入数据 `lzh_member_creditslog` */
 INSERT INTO `lzh_member_creditslog` VALUES ('66','39','10','10','10','手机认证通过,奖励积分10','1430098347','106.39.13.15');/* DBReback Separation */ 
 /* 数据表结构 `lzh_member_data_info`*/ 
 DROP TABLE IF EXISTS `lzh_member_data_info`;/* DBReback Separation */ 
 CREATE TABLE `lzh_member_data_info` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `uid` int(10) unsigned NOT NULL,
  `data_url` varchar(100) NOT NULL,
  `type` smallint(5) unsigned NOT NULL,
  `status` tinyint(3) unsigned NOT NULL,
  `add_time` int(10) unsigned NOT NULL,
  `data_name` varchar(50) NOT NULL,
  `size` int(10) unsigned NOT NULL,
  `ext` varchar(10) NOT NULL,
  `deal_info` varchar(40) NOT NULL,
  `deal_credits` smallint(5) unsigned NOT NULL,
  `deal_user` int(11) NOT NULL,
  `deal_time` int(10) unsigned NOT NULL,
  PRIMARY KEY (`id`),
  KEY `uid` (`uid`,`type`,`status`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;/* DBReback Separation */ 
 /* 数据表结构 `lzh_member_department_info`*/ 
 DROP TABLE IF EXISTS `lzh_member_department_info`;/* DBReback Separation */ 
 CREATE TABLE `lzh_member_department_info` (
  `uid` int(11) NOT NULL,
  `department_name` varchar(50) NOT NULL,
  `department_tel` varchar(20) NOT NULL,
  `department_address` varchar(200) NOT NULL,
  `department_year` varchar(20) NOT NULL,
  `voucher_name` varchar(20) NOT NULL,
  `voucher_tel` varchar(20) NOT NULL,
  PRIMARY KEY (`uid`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;/* DBReback Separation */ 
 /* 数据表结构 `lzh_member_ensure_info`*/ 
 DROP TABLE IF EXISTS `lzh_member_ensure_info`;/* DBReback Separation */ 
 CREATE TABLE `lzh_member_ensure_info` (
  `uid` int(11) NOT NULL,
  `ensuer1_name` varchar(20) NOT NULL,
  `ensuer1_re` varchar(20) NOT NULL,
  `ensuer1_tel` varchar(20) NOT NULL,
  `ensuer2_name` varchar(20) NOT NULL,
  `ensuer2_re` varchar(20) NOT NULL,
  `ensuer2_tel` varchar(20) NOT NULL,
  PRIMARY KEY (`uid`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;/* DBReback Separation */ 
 /* 数据表结构 `lzh_member_financial_info`*/ 
 DROP TABLE IF EXISTS `lzh_member_financial_info`;/* DBReback Separation */ 
 CREATE TABLE `lzh_member_financial_info` (
  `uid` int(10) unsigned NOT NULL,
  `fin_monthin` varchar(20) NOT NULL,
  `fin_incomedes` varchar(2000) NOT NULL,
  `fin_monthout` varchar(20) NOT NULL,
  `fin_outdes` varchar(2000) NOT NULL,
  `fin_house` varchar(50) NOT NULL,
  `fin_housevalue` varchar(20) NOT NULL,
  `fin_car` varchar(20) NOT NULL,
  `fin_carvalue` varchar(20) NOT NULL,
  `fin_stockcompany` varchar(50) NOT NULL,
  `fin_stockcompanyvalue` varchar(50) NOT NULL,
  `fin_otheremark` varchar(2000) NOT NULL,
  PRIMARY KEY (`uid`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;/* DBReback Separation */ 
 /* 数据表结构 `lzh_member_friend`*/ 
 DROP TABLE IF EXISTS `lzh_member_friend`;/* DBReback Separation */ 
 CREATE TABLE `lzh_member_friend` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `uid` int(10) unsigned NOT NULL,
  `friend_id` int(10) unsigned NOT NULL,
  `apply_status` tinyint(3) unsigned NOT NULL DEFAULT '0',
  `add_time` int(10) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;/* DBReback Separation */ 
 /* 数据表结构 `lzh_member_house_info`*/ 
 DROP TABLE IF EXISTS `lzh_member_house_info`;/* DBReback Separation */ 
 CREATE TABLE `lzh_member_house_info` (
  `uid` int(11) NOT NULL,
  `house_dizhi` varchar(200) NOT NULL,
  `house_mianji` float(10,2) NOT NULL,
  `house_nian` varchar(10) NOT NULL,
  `house_gong` varchar(20) NOT NULL,
  `house_suo1` varchar(20) NOT NULL,
  `house_suo2` varchar(20) NOT NULL,
  `house_feng1` float(10,2) NOT NULL,
  `house_feng2` float(10,2) NOT NULL,
  `house_dai` int(11) NOT NULL,
  `house_yuegong` float(10,2) NOT NULL,
  `house_shangxian` float(10,2) NOT NULL,
  `house_anjiebank` varchar(20) NOT NULL,
  PRIMARY KEY (`uid`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;/* DBReback Separation */ 
 /* 数据表结构 `lzh_member_info`*/ 
 DROP TABLE IF EXISTS `lzh_member_info`;/* DBReback Separation */ 
 CREATE TABLE `lzh_member_info` (
  `uid` int(10) unsigned NOT NULL,
  `sex` varchar(20) NOT NULL,
  `zy` varchar(40) NOT NULL,
  `cell_phone` varchar(11) NOT NULL,
  `info` varchar(500) NOT NULL,
  `marry` varchar(20) NOT NULL,
  `education` varchar(50) NOT NULL,
  `income` varchar(20) NOT NULL,
  `age` int(11) NOT NULL,
  `idcard` varchar(20) NOT NULL,
  `card_img` varchar(200) NOT NULL,
  `real_name` varchar(50) NOT NULL,
  `address` varchar(100) NOT NULL,
  `province` int(11) NOT NULL,
  `province_now` int(11) NOT NULL,
  `city` int(11) NOT NULL,
  `city_now` int(11) NOT NULL,
  `area` int(11) NOT NULL,
  `area_now` int(11) NOT NULL,
  `up_time` int(10) unsigned NOT NULL,
  `card_back_img` varchar(200) NOT NULL,
  PRIMARY KEY (`uid`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;/* DBReback Separation */
 /* 插入数据 `lzh_member_info` */
 INSERT INTO `lzh_member_info` VALUES ('1','','','13611012678','','','','','0','','','','','0','0','0','0','0','0','0','');/* DBReback Separation */
 /* 插入数据 `lzh_member_info` */
 INSERT INTO `lzh_member_info` VALUES ('2','','','17701377782','','','','','0','','','','','0','0','0','0','0','0','0','');/* DBReback Separation */
 /* 插入数据 `lzh_member_info` */
 INSERT INTO `lzh_member_info` VALUES ('3','男','销售','13693650065','销售经理','已婚','大专或本科','5000-10000','0','52020219870611247X','UF/Uploads/Idcard/20150423165107309_3.jpg','李泽','','8','2','114','52','991','512','1429779071','UF/Uploads/Idcard/20150423165110625_3_back.jpg');/* DBReback Separation */
 /* 插入数据 `lzh_member_info` */
 INSERT INTO `lzh_member_info` VALUES ('4','男','程序员','18310312295','个人信用极好 无不良记录','未婚','大专或本科','5000-10000','24','130429199203224616','UF/Uploads/Idcard/20150423172530258_4.jpg','王洋洋','','10','2','142','52','1166','512','1429781161','UF/Uploads/Idcard/20150423172541119_4_back.jpg');/* DBReback Separation */
 /* 插入数据 `lzh_member_info` */
 INSERT INTO `lzh_member_info` VALUES ('5','','','13717798492','','','','','0','420922199112146044','UF/Uploads/Idcard/20150423173647704_5.jpg','严敏','','0','0','0','0','0','0','1429781843','UF/Uploads/Idcard/20150423173716851_5_back.jpg');/* DBReback Separation */
 /* 插入数据 `lzh_member_info` */
 INSERT INTO `lzh_member_info` VALUES ('6','','','18611771203','','','','','0','','','公司专用1（其他人员请不要动）','','0','0','0','0','0','0','0','');/* DBReback Separation */
 /* 插入数据 `lzh_member_info` */
 INSERT INTO `lzh_member_info` VALUES ('7','','','15801156647','','','','','0','','','','','0','0','0','0','0','0','0','');/* DBReback Separation */
 /* 插入数据 `lzh_member_info` */
 INSERT INTO `lzh_member_info` VALUES ('8','','','18311050886','','','','','0','','','','','0','0','0','0','0','0','0','');/* DBReback Separation */
 /* 插入数据 `lzh_member_info` */
 INSERT INTO `lzh_member_info` VALUES ('9','女','售后工程师','17701268060','收入稳定，想要合理的理财。','未婚','大专或本科','5000-10000','24','142303199110132645','UF/Uploads/Idcard/20150424125111985_9.jpg','田晓玉','','23','2','306','52','2547','512','1429851075','UF/Uploads/Idcard/20150424125114592_9_back.jpg');/* DBReback Separation */
 /* 插入数据 `lzh_member_info` */
 INSERT INTO `lzh_member_info` VALUES ('10','','','13552437955','','','','','0','130724199306282813','UF/Uploads/Idcard/20150424112813642_10.jpg','赵海洋','','0','0','0','0','0','0','1429846103','UF/Uploads/Idcard/20150424112821474_10_back.jpg');/* DBReback Separation */
 /* 插入数据 `lzh_member_info` */
 INSERT INTO `lzh_member_info` VALUES ('11','','','13552893445','','','','','0','','','','','0','0','0','0','0','0','0','');/* DBReback Separation */
 /* 插入数据 `lzh_member_info` */
 INSERT INTO `lzh_member_info` VALUES ('12','','','15938751859','','','','','0','','','','','0','0','0','0','0','0','0','');/* DBReback Separation */
 /* 插入数据 `lzh_member_info` */
 INSERT INTO `lzh_member_info` VALUES ('13','男','挨踢程序猿','18810889714','奋斗  奋斗   无休止的奋斗','未婚','大专或本科','5000-10000','20','13072819951025003X','UF/Uploads/Idcard/20150424111537362_13.png','郭呈','','10','2','148','52','1245','512','1429845340','UF/Uploads/Idcard/20150424111540269_13_back.png');/* DBReback Separation */
 /* 插入数据 `lzh_member_info` */
 INSERT INTO `lzh_member_info` VALUES ('14','','','17710242027','','','','','0','230203199108091826','UF/Uploads/Idcard/20150424112559146_14.JPG','宋宇','','0','0','0','0','0','0','1429845982','UF/Uploads/Idcard/20150424112621772_14_back.jpg');/* DBReback Separation */
 /* 插入数据 `lzh_member_info` */
 INSERT INTO `lzh_member_info` VALUES ('15','','','15196917118','','','','','0','510922199304264362','UF/Uploads/Idcard/20150424111531529_15.jpg','彭红','','0','0','0','0','0','0','1429845346','UF/Uploads/Idcard/20150424111542508_15_back.jpg');/* DBReback Separation */
 /* 插入数据 `lzh_member_info` */
 INSERT INTO `lzh_member_info` VALUES ('16','','','18511588087','','','','','0','','','','','0','0','0','0','0','0','0','');/* DBReback Separation */
 /* 插入数据 `lzh_member_info` */
 INSERT INTO `lzh_member_info` VALUES ('17','','','13331131834','','','','','0','','','','','0','0','0','0','0','0','0','');/* DBReback Separation */
 /* 插入数据 `lzh_member_info` */
 INSERT INTO `lzh_member_info` VALUES ('18','','','18539659876','','','','','0','','','','','0','0','0','0','0','0','0','');/* DBReback Separation */
 /* 插入数据 `lzh_member_info` */
 INSERT INTO `lzh_member_info` VALUES ('19','女','上班族','15300066405','上班族','未婚','高中以下','5000以下','20','142621199502112247','UF/Uploads/Idcard/20150424141338409_19.jpg','郑雨','','23','2','305','52','2530','512','1429856046','UF/Uploads/Idcard/2015042414134148_19_back.jpg');/* DBReback Separation */
 /* 插入数据 `lzh_member_info` */
 INSERT INTO `lzh_member_info` VALUES ('20','','','18701386300','','','','','0','','','','','0','0','0','0','0','0','0','');/* DBReback Separation */
 /* 插入数据 `lzh_member_info` */
 INSERT INTO `lzh_member_info` VALUES ('21','','','18717338021','','','','','0','','','','','0','0','0','0','0','0','0','');/* DBReback Separation */
 /* 插入数据 `lzh_member_info` */
 INSERT INTO `lzh_member_info` VALUES ('22','男','区域经理','15110088435','北京淘伟科技有限公司南京分公司区域经理','未婚','大专或本科','10000-50000','23','520112199204150013','UF/Uploads/Idcard/20150424112154540_22.jpg','朱世翔','','8','16','111','220','965','1834','1429845721','UF/Uploads/Idcard/20150424112200542_22_back.jpg');/* DBReback Separation */
 /* 插入数据 `lzh_member_info` */
 INSERT INTO `lzh_member_info` VALUES ('23','','','18515157554','','','','','0','','','','','0','0','0','0','0','0','0','');/* DBReback Separation */
 /* 插入数据 `lzh_member_info` */
 INSERT INTO `lzh_member_info` VALUES ('24','女','销售','18500278044','销售','未婚','高中以下','5000以下','20','130732199508172364','UF/Uploads/Idcard/20150424113144197_24.jpg','于文艳','','10','2','148','52','1249','512','1429846347','UF/Uploads/Idcard/20150424113224876_24_back.jpg');/* DBReback Separation */
 /* 插入数据 `lzh_member_info` */
 INSERT INTO `lzh_member_info` VALUES ('25','','','15810123362','','','','','0','','','','','0','0','0','0','0','0','0','');/* DBReback Separation */
 /* 插入数据 `lzh_member_info` */
 INSERT INTO `lzh_member_info` VALUES ('26','男','毒师','15201618692','毒师毒师','未婚','大专或本科','50000以上','300','420921199609243839','UF/Uploads/Idcard/20150424163926711_26.png','鲁康','','13','2','194','52','1623','503','1429864775','UF/Uploads/Idcard/20150424163930326_26_back.png');/* DBReback Separation */
 /* 插入数据 `lzh_member_info` */
 INSERT INTO `lzh_member_info` VALUES ('27','','','13910683486','','','','','0','','','','','0','0','0','0','0','0','0','');/* DBReback Separation */
 /* 插入数据 `lzh_member_info` */
 INSERT INTO `lzh_member_info` VALUES ('28','','','13269501238','','','','','0','','','','','0','0','0','0','0','0','0','');/* DBReback Separation */
 /* 插入数据 `lzh_member_info` */
 INSERT INTO `lzh_member_info` VALUES ('29','','','13810830845','','','','','0','','','','','0','0','0','0','0','0','0','');/* DBReback Separation */
 /* 插入数据 `lzh_member_info` */
 INSERT INTO `lzh_member_info` VALUES ('31','','','13317341134','','','','','0','430406198906171014','UF/Uploads/Idcard/20150424142555183_31.jpg','王林超','','0','0','0','0','0','0','1429856768','UF/Uploads/Idcard/2015042414260028_31_back.jpg');/* DBReback Separation */
 /* 插入数据 `lzh_member_info` */
 INSERT INTO `lzh_member_info` VALUES ('32','','','18713510646','','','','','0','','','','','0','0','0','0','0','0','0','');/* DBReback Separation */
 /* 插入数据 `lzh_member_info` */
 INSERT INTO `lzh_member_info` VALUES ('33','','','15836810328','','','','','0','','','','','0','0','0','0','0','0','0','');/* DBReback Separation */
 /* 插入数据 `lzh_member_info` */
 INSERT INTO `lzh_member_info` VALUES ('34','','','15010198635','','','','','0','130727198810253725','UF/Uploads/Idcard/20150424153056654_34.jpg','胡小钰','','0','0','0','0','0','0','1429860699','UF/Uploads/Idcard/20150424153137342_34_back.jpg');/* DBReback Separation */
 /* 插入数据 `lzh_member_info` */
 INSERT INTO `lzh_member_info` VALUES ('35','','','15618509300','','','','','0','','','','','0','0','0','0','0','0','0','');/* DBReback Separation */
 /* 插入数据 `lzh_member_info` */
 INSERT INTO `lzh_member_info` VALUES ('36','','','13333333333','','','','','0','','','','','0','0','0','0','0','0','0','');/* DBReback Separation */
 /* 插入数据 `lzh_member_info` */
 INSERT INTO `lzh_member_info` VALUES ('37','','','15088696119','','','','','0','','','','','0','0','0','0','0','0','0','');/* DBReback Separation */
 /* 插入数据 `lzh_member_info` */
 INSERT INTO `lzh_member_info` VALUES ('38','','','15564052703','','','','','0','','','','','0','0','0','0','0','0','0','');/* DBReback Separation */
 /* 插入数据 `lzh_member_info` */
 INSERT INTO `lzh_member_info` VALUES ('39','','','13611134321','','','','','0','','','','','0','0','0','0','0','0','0','');/* DBReback Separation */ 
 /* 数据表结构 `lzh_member_integrallog`*/ 
 DROP TABLE IF EXISTS `lzh_member_integrallog`;/* DBReback Separation */ 
 CREATE TABLE `lzh_member_integrallog` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `uid` int(10) unsigned NOT NULL,
  `type` tinyint(3) unsigned NOT NULL,
  `affect_integral` mediumint(9) NOT NULL,
  `active_integral` mediumint(9) NOT NULL,
  `account_integral` mediumint(9) NOT NULL,
  `info` varchar(50) NOT NULL,
  `add_time` int(10) unsigned NOT NULL,
  `add_ip` varchar(16) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `uid` (`uid`,`type`,`id`)
) ENGINE=MyISAM AUTO_INCREMENT=25 DEFAULT CHARSET=utf8;/* DBReback Separation */
 /* 插入数据 `lzh_member_integrallog` */
 INSERT INTO `lzh_member_integrallog` VALUES ('1','13','2','30','30','30','第1号标复审通过，应获积分：30分,投资金额：1000.00元,投资天数：30天','1429861262','106.39.13.9');/* DBReback Separation */
 /* 插入数据 `lzh_member_integrallog` */
 INSERT INTO `lzh_member_integrallog` VALUES ('2','22','2','150','150','150','第1号标复审通过，应获积分：150分,投资金额：5000.00元,投资天数：30天','1429861262','106.39.13.9');/* DBReback Separation */
 /* 插入数据 `lzh_member_integrallog` */
 INSERT INTO `lzh_member_integrallog` VALUES ('3','15','2','30','30','30','第1号标复审通过，应获积分：30分,投资金额：1000.00元,投资天数：30天','1429861262','106.39.13.9');/* DBReback Separation */
 /* 插入数据 `lzh_member_integrallog` */
 INSERT INTO `lzh_member_integrallog` VALUES ('4','3','2','300','300','300','第1号标复审通过，应获积分：300分,投资金额：10000.00元,投资天数：30天','1429861262','106.39.13.9');/* DBReback Separation */
 /* 插入数据 `lzh_member_integrallog` */
 INSERT INTO `lzh_member_integrallog` VALUES ('5','9','2','6','6','6','第1号标复审通过，应获积分：6分,投资金额：200.00元,投资天数：30天','1429861262','106.39.13.9');/* DBReback Separation */
 /* 插入数据 `lzh_member_integrallog` */
 INSERT INTO `lzh_member_integrallog` VALUES ('6','16','2','120','120','120','第1号标复审通过，应获积分：120分,投资金额：4000.00元,投资天数：30天','1429861262','106.39.13.9');/* DBReback Separation */
 /* 插入数据 `lzh_member_integrallog` */
 INSERT INTO `lzh_member_integrallog` VALUES ('7','26','2','150','150','150','第1号标复审通过，应获积分：150分,投资金额：5000.00元,投资天数：30天','1429861262','106.39.13.9');/* DBReback Separation */
 /* 插入数据 `lzh_member_integrallog` */
 INSERT INTO `lzh_member_integrallog` VALUES ('8','26','2','45','195','195','第1号标复审通过，应获积分：45分,投资金额：1500.00元,投资天数：30天','1429861262','106.39.13.9');/* DBReback Separation */
 /* 插入数据 `lzh_member_integrallog` */
 INSERT INTO `lzh_member_integrallog` VALUES ('9','24','2','3','3','3','第1号标复审通过，应获积分：3分,投资金额：100.00元,投资天数：30天','1429861262','106.39.13.9');/* DBReback Separation */
 /* 插入数据 `lzh_member_integrallog` */
 INSERT INTO `lzh_member_integrallog` VALUES ('10','6','2','1200','1200','1200','第1号标复审通过，应获积分：1200分,投资金额：40000.00元,投资天数：30天','1429861262','106.39.13.9');/* DBReback Separation */
 /* 插入数据 `lzh_member_integrallog` */
 INSERT INTO `lzh_member_integrallog` VALUES ('11','19','2','3','3','3','第1号标复审通过，应获积分：3分,投资金额：100.00元,投资天数：30天','1429861262','106.39.13.9');/* DBReback Separation */
 /* 插入数据 `lzh_member_integrallog` */
 INSERT INTO `lzh_member_integrallog` VALUES ('12','14','2','150','150','150','第1号标复审通过，应获积分：150分,投资金额：5000.00元,投资天数：30天','1429861262','106.39.13.9');/* DBReback Separation */
 /* 插入数据 `lzh_member_integrallog` */
 INSERT INTO `lzh_member_integrallog` VALUES ('13','31','2','30','30','30','第1号标复审通过，应获积分：30分,投资金额：1000.00元,投资天数：30天','1429861262','106.39.13.9');/* DBReback Separation */
 /* 插入数据 `lzh_member_integrallog` */
 INSERT INTO `lzh_member_integrallog` VALUES ('14','7','2','15','15','15','第1号标复审通过，应获积分：15分,投资金额：500.00元,投资天数：30天','1429861262','106.39.13.9');/* DBReback Separation */
 /* 插入数据 `lzh_member_integrallog` */
 INSERT INTO `lzh_member_integrallog` VALUES ('15','7','2','15','30','30','第1号标复审通过，应获积分：15分,投资金额：500.00元,投资天数：30天','1429861262','106.39.13.9');/* DBReback Separation */
 /* 插入数据 `lzh_member_integrallog` */
 INSERT INTO `lzh_member_integrallog` VALUES ('16','24','2','12','15','15','第1号标复审通过，应获积分：12分,投资金额：400.00元,投资天数：30天','1429861262','106.39.13.9');/* DBReback Separation */
 /* 插入数据 `lzh_member_integrallog` */
 INSERT INTO `lzh_member_integrallog` VALUES ('17','32','2','30','30','30','第1号标复审通过，应获积分：30分,投资金额：1000.00元,投资天数：30天','1429861262','106.39.13.9');/* DBReback Separation */
 /* 插入数据 `lzh_member_integrallog` */
 INSERT INTO `lzh_member_integrallog` VALUES ('18','6','2','300','1500','1500','第1号标复审通过，应获积分：300分,投资金额：10000.00元,投资天数：30天','1429861262','106.39.13.9');/* DBReback Separation */
 /* 插入数据 `lzh_member_integrallog` */
 INSERT INTO `lzh_member_integrallog` VALUES ('19','12','2','3','3','3','第1号标复审通过，应获积分：3分,投资金额：100.00元,投资天数：30天','1429861263','106.39.13.9');/* DBReback Separation */
 /* 插入数据 `lzh_member_integrallog` */
 INSERT INTO `lzh_member_integrallog` VALUES ('20','15','2','30','60','60','第1号标复审通过，应获积分：30分,投资金额：1000.00元,投资天数：30天','1429861263','106.39.13.9');/* DBReback Separation */
 /* 插入数据 `lzh_member_integrallog` */
 INSERT INTO `lzh_member_integrallog` VALUES ('21','19','2','12','15','15','第1号标复审通过，应获积分：12分,投资金额：400.00元,投资天数：30天','1429861263','106.39.13.9');/* DBReback Separation */
 /* 插入数据 `lzh_member_integrallog` */
 INSERT INTO `lzh_member_integrallog` VALUES ('22','8','2','30','30','30','第1号标复审通过，应获积分：30分,投资金额：1000.00元,投资天数：30天','1429861263','106.39.13.9');/* DBReback Separation */
 /* 插入数据 `lzh_member_integrallog` */
 INSERT INTO `lzh_member_integrallog` VALUES ('23','34','2','30','30','30','第1号标复审通过，应获积分：30分,投资金额：1000.00元,投资天数：30天','1429861263','106.39.13.9');/* DBReback Separation */
 /* 插入数据 `lzh_member_integrallog` */
 INSERT INTO `lzh_member_integrallog` VALUES ('24','6','2','306','1806','1806','第1号标复审通过，应获积分：306分,投资金额：10200.00元,投资天数：30天','1429861263','106.39.13.9');/* DBReback Separation */ 
 /* 数据表结构 `lzh_member_limitlog`*/ 
 DROP TABLE IF EXISTS `lzh_member_limitlog`;/* DBReback Separation */ 
 CREATE TABLE `lzh_member_limitlog` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `uid` int(10) unsigned NOT NULL,
  `type` tinyint(3) unsigned NOT NULL,
  `credit_limit` float(15,2) NOT NULL,
  `borrow_vouch_limit` float(15,2) NOT NULL,
  `invest_vouch_limit` float(15,2) NOT NULL,
  `info` varchar(50) NOT NULL,
  `add_time` int(10) unsigned NOT NULL,
  `add_ip` varchar(16) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `uid` (`uid`,`type`,`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;/* DBReback Separation */ 
 /* 数据表结构 `lzh_member_login`*/ 
 DROP TABLE IF EXISTS `lzh_member_login`;/* DBReback Separation */ 
 CREATE TABLE `lzh_member_login` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `uid` int(10) unsigned NOT NULL,
  `ip` varchar(15) NOT NULL,
  `add_time` int(10) unsigned NOT NULL,
  PRIMARY KEY (`id`),
  KEY `uid` (`uid`,`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;/* DBReback Separation */ 
 /* 数据表结构 `lzh_member_money`*/ 
 DROP TABLE IF EXISTS `lzh_member_money`;/* DBReback Separation */ 
 CREATE TABLE `lzh_member_money` (
  `uid` int(10) unsigned NOT NULL,
  `money_freeze` decimal(15,2) NOT NULL COMMENT '冻结金额',
  `money_collect` decimal(15,2) NOT NULL COMMENT '待收金额',
  `account_money` decimal(15,2) NOT NULL COMMENT '充值资金存放池_可用余额',
  `back_money` decimal(15,2) NOT NULL COMMENT '回款资金存放池_可用余额',
  `credit_limit` decimal(15,2) NOT NULL COMMENT '信用总额度',
  `credit_cuse` decimal(15,2) NOT NULL COMMENT '已用信用额度',
  `borrow_vouch_limit` decimal(15,2) NOT NULL COMMENT '借款担保总额度',
  `borrow_vouch_cuse` decimal(15,2) NOT NULL COMMENT '借款担保已用额度',
  `invest_vouch_limit` decimal(15,2) NOT NULL COMMENT '投资担保总额度',
  `invest_vouch_cuse` decimal(15,2) NOT NULL COMMENT '投资担保已用额度',
  PRIMARY KEY (`uid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;/* DBReback Separation */
 /* 插入数据 `lzh_member_money` */
 INSERT INTO `lzh_member_money` VALUES ('1','10000.00','0.00','90157.70','0.00','0.00','0.00','0.00','0.00','0.00','0.00');/* DBReback Separation */
 /* 插入数据 `lzh_member_money` */
 INSERT INTO `lzh_member_money` VALUES ('2','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00');/* DBReback Separation */
 /* 插入数据 `lzh_member_money` */
 INSERT INTO `lzh_member_money` VALUES ('3','0.00','10106.67','5999.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00');/* DBReback Separation */
 /* 插入数据 `lzh_member_money` */
 INSERT INTO `lzh_member_money` VALUES ('4','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00');/* DBReback Separation */
 /* 插入数据 `lzh_member_money` */
 INSERT INTO `lzh_member_money` VALUES ('5','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00');/* DBReback Separation */
 /* 插入数据 `lzh_member_money` */
 INSERT INTO `lzh_member_money` VALUES ('6','0.00','60842.14','9939800.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00');/* DBReback Separation */
 /* 插入数据 `lzh_member_money` */
 INSERT INTO `lzh_member_money` VALUES ('7','0.00','1010.66','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00');/* DBReback Separation */
 /* 插入数据 `lzh_member_money` */
 INSERT INTO `lzh_member_money` VALUES ('8','0.00','1010.67','2.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00');/* DBReback Separation */
 /* 插入数据 `lzh_member_money` */
 INSERT INTO `lzh_member_money` VALUES ('9','0.00','202.13','0.50','0.00','0.00','0.00','0.00','0.00','0.00','0.00');/* DBReback Separation */
 /* 插入数据 `lzh_member_money` */
 INSERT INTO `lzh_member_money` VALUES ('10','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00');/* DBReback Separation */
 /* 插入数据 `lzh_member_money` */
 INSERT INTO `lzh_member_money` VALUES ('11','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00');/* DBReback Separation */
 /* 插入数据 `lzh_member_money` */
 INSERT INTO `lzh_member_money` VALUES ('12','0.00','101.07','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00');/* DBReback Separation */
 /* 插入数据 `lzh_member_money` */
 INSERT INTO `lzh_member_money` VALUES ('13','0.00','1010.67','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00');/* DBReback Separation */
 /* 插入数据 `lzh_member_money` */
 INSERT INTO `lzh_member_money` VALUES ('14','0.00','5053.33','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00');/* DBReback Separation */
 /* 插入数据 `lzh_member_money` */
 INSERT INTO `lzh_member_money` VALUES ('15','0.00','2021.34','2.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00');/* DBReback Separation */
 /* 插入数据 `lzh_member_money` */
 INSERT INTO `lzh_member_money` VALUES ('16','0.00','4042.67','99.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00');/* DBReback Separation */
 /* 插入数据 `lzh_member_money` */
 INSERT INTO `lzh_member_money` VALUES ('18','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00');/* DBReback Separation */
 /* 插入数据 `lzh_member_money` */
 INSERT INTO `lzh_member_money` VALUES ('19','0.00','505.34','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00');/* DBReback Separation */
 /* 插入数据 `lzh_member_money` */
 INSERT INTO `lzh_member_money` VALUES ('21','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00');/* DBReback Separation */
 /* 插入数据 `lzh_member_money` */
 INSERT INTO `lzh_member_money` VALUES ('22','0.00','5053.33','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00');/* DBReback Separation */
 /* 插入数据 `lzh_member_money` */
 INSERT INTO `lzh_member_money` VALUES ('24','0.00','505.34','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00');/* DBReback Separation */
 /* 插入数据 `lzh_member_money` */
 INSERT INTO `lzh_member_money` VALUES ('26','0.00','6569.33','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00');/* DBReback Separation */
 /* 插入数据 `lzh_member_money` */
 INSERT INTO `lzh_member_money` VALUES ('27','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00');/* DBReback Separation */
 /* 插入数据 `lzh_member_money` */
 INSERT INTO `lzh_member_money` VALUES ('28','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00');/* DBReback Separation */
 /* 插入数据 `lzh_member_money` */
 INSERT INTO `lzh_member_money` VALUES ('31','0.00','1010.67','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00');/* DBReback Separation */
 /* 插入数据 `lzh_member_money` */
 INSERT INTO `lzh_member_money` VALUES ('32','0.00','1010.67','1.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00');/* DBReback Separation */
 /* 插入数据 `lzh_member_money` */
 INSERT INTO `lzh_member_money` VALUES ('33','0.00','0.00','1.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00');/* DBReback Separation */
 /* 插入数据 `lzh_member_money` */
 INSERT INTO `lzh_member_money` VALUES ('34','0.00','1010.67','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00');/* DBReback Separation */
 /* 插入数据 `lzh_member_money` */
 INSERT INTO `lzh_member_money` VALUES ('35','0.00','0.00','1.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00');/* DBReback Separation */
 /* 插入数据 `lzh_member_money` */
 INSERT INTO `lzh_member_money` VALUES ('39','0.00','0.00','2.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00');/* DBReback Separation */ 
 /* 数据表结构 `lzh_member_moneylog`*/ 
 DROP TABLE IF EXISTS `lzh_member_moneylog`;/* DBReback Separation */ 
 CREATE TABLE `lzh_member_moneylog` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `uid` int(10) unsigned NOT NULL,
  `type` tinyint(3) unsigned NOT NULL,
  `affect_money` decimal(15,2) NOT NULL COMMENT '影响金额',
  `account_money` decimal(15,2) NOT NULL COMMENT '充值资金存放池_可用余额',
  `back_money` decimal(15,2) NOT NULL COMMENT '回款资金存放池_可用余额',
  `collect_money` decimal(15,2) NOT NULL COMMENT '待收金额',
  `freeze_money` decimal(15,2) NOT NULL COMMENT '冻结金额',
  `info` varchar(50) NOT NULL,
  `add_time` int(10) unsigned NOT NULL,
  `add_ip` varchar(16) NOT NULL,
  `target_uid` int(11) NOT NULL DEFAULT '0',
  `target_uname` varchar(20) NOT NULL,
  `shares_id` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `uid` (`uid`,`type`,`id`)
) ENGINE=InnoDB AUTO_INCREMENT=150 DEFAULT CHARSET=utf8;/* DBReback Separation */
 /* 插入数据 `lzh_member_moneylog` */
 INSERT INTO `lzh_member_moneylog` VALUES ('1','1','3','998.50','998.50','0.00','0.00','0.00','充值订单号:20150423160739470949','1429776636','114.80.78.215','0','@网站管理员@','');/* DBReback Separation */
 /* 插入数据 `lzh_member_moneylog` */
 INSERT INTO `lzh_member_moneylog` VALUES ('2','1','3','100.00','1098.50','0.00','0.00','0.00','充值订单号:20150423162715926423','1429777707','114.80.78.215','0','@网站管理员@','');/* DBReback Separation */
 /* 插入数据 `lzh_member_moneylog` */
 INSERT INTO `lzh_member_moneylog` VALUES ('3','5','27','1.00','1.00','0.00','0.00','0.00','支付宝充值','1429786486','124.205.215.55','0','@网站管理员@','');/* DBReback Separation */
 /* 插入数据 `lzh_member_moneylog` */
 INSERT INTO `lzh_member_moneylog` VALUES ('4','4','27','1.00','1.00','0.00','0.00','0.00','支付宝充值','1429786496','124.205.215.55','0','@网站管理员@','');/* DBReback Separation */
 /* 插入数据 `lzh_member_moneylog` */
 INSERT INTO `lzh_member_moneylog` VALUES ('5','1','53','1.00','1097.50','0.00','0.00','0.00','订单支付保证金','1429841187','124.205.215.51','0','平台运行商','1');/* DBReback Separation */
 /* 插入数据 `lzh_member_moneylog` */
 INSERT INTO `lzh_member_moneylog` VALUES ('6','16','27','50.00','50.00','0.00','0.00','0.00','支付宝充值','1429845652','106.39.13.9','0','@网站管理员@','');/* DBReback Separation */
 /* 插入数据 `lzh_member_moneylog` */
 INSERT INTO `lzh_member_moneylog` VALUES ('7','13','27','1000.00','1000.00','0.00','0.00','0.00','支付宝充值','1429845886','106.39.13.9','0','@网站管理员@','');/* DBReback Separation */
 /* 插入数据 `lzh_member_moneylog` */
 INSERT INTO `lzh_member_moneylog` VALUES ('8','13','6','-1000.00','0.00','0.00','0.00','1000.00','对1号标进行投标','1429846282','106.39.13.9','1','whttcy','');/* DBReback Separation */
 /* 插入数据 `lzh_member_moneylog` */
 INSERT INTO `lzh_member_moneylog` VALUES ('9','11','27','1.00','1.00','0.00','0.00','0.00','管理员手动审核充值','1429846352','106.39.13.9','0','@网站管理员@','');/* DBReback Separation */
 /* 插入数据 `lzh_member_moneylog` */
 INSERT INTO `lzh_member_moneylog` VALUES ('10','2','27','1.00','1.00','0.00','0.00','0.00','管理员手动审核充值','1429846451','106.39.13.9','0','@网站管理员@','');/* DBReback Separation */
 /* 插入数据 `lzh_member_moneylog` */
 INSERT INTO `lzh_member_moneylog` VALUES ('11','11','53','1.00','0.00','0.00','0.00','0.00','订单支付保证金','1429846616','106.39.13.9','0','平台运行商','6');/* DBReback Separation */
 /* 插入数据 `lzh_member_moneylog` */
 INSERT INTO `lzh_member_moneylog` VALUES ('12','2','53','1.00','0.00','0.00','0.00','0.00','订单支付保证金','1429846870','106.39.13.9','0','平台运行商','7');/* DBReback Separation */
 /* 插入数据 `lzh_member_moneylog` */
 INSERT INTO `lzh_member_moneylog` VALUES ('13','12','27','101.00','101.00','0.00','0.00','0.00','支付宝充值','1429846916','106.39.13.9','0','@网站管理员@','');/* DBReback Separation */
 /* 插入数据 `lzh_member_moneylog` */
 INSERT INTO `lzh_member_moneylog` VALUES ('14','18','27','1.00','1.00','0.00','0.00','0.00','支付宝充值','1429846924','106.39.13.9','0','@网站管理员@','');/* DBReback Separation */
 /* 插入数据 `lzh_member_moneylog` */
 INSERT INTO `lzh_member_moneylog` VALUES ('15','13','27','1.00','1.00','0.00','0.00','1000.00','支付宝充值','1429846940','106.39.13.9','0','@网站管理员@','');/* DBReback Separation */
 /* 插入数据 `lzh_member_moneylog` */
 INSERT INTO `lzh_member_moneylog` VALUES ('16','16','27','50.00','100.00','0.00','0.00','0.00','支付宝充值','1429846973','106.39.13.9','0','@网站管理员@','');/* DBReback Separation */
 /* 插入数据 `lzh_member_moneylog` */
 INSERT INTO `lzh_member_moneylog` VALUES ('17','22','3','5000.00','5000.00','0.00','0.00','0.00','充值订单号:20150424115313808899','1429847651','114.80.78.215','0','@网站管理员@','');/* DBReback Separation */
 /* 插入数据 `lzh_member_moneylog` */
 INSERT INTO `lzh_member_moneylog` VALUES ('18','22','6','-5000.00','0.00','0.00','0.00','5000.00','对1号标进行投标','1429847833','117.62.134.55','1','whttcy','');/* DBReback Separation */
 /* 插入数据 `lzh_member_moneylog` */
 INSERT INTO `lzh_member_moneylog` VALUES ('19','15','27','1003.00','1003.00','0.00','0.00','0.00','管理员手动审核充值','1429848458','106.39.13.9','0','@网站管理员@','');/* DBReback Separation */
 /* 插入数据 `lzh_member_moneylog` */
 INSERT INTO `lzh_member_moneylog` VALUES ('20','26','27','1.00','1.00','0.00','0.00','0.00','支付宝充值','1429849889','106.39.13.9','0','@网站管理员@','');/* DBReback Separation */
 /* 插入数据 `lzh_member_moneylog` */
 INSERT INTO `lzh_member_moneylog` VALUES ('21','21','27','1.00','1.00','0.00','0.00','0.00','支付宝充值','1429850175','106.39.13.9','0','@网站管理员@','');/* DBReback Separation */
 /* 插入数据 `lzh_member_moneylog` */
 INSERT INTO `lzh_member_moneylog` VALUES ('22','15','6','-1000.00','3.00','0.00','0.00','1000.00','对1号标进行投标','1429850894','117.62.134.55','1','whttcy','');/* DBReback Separation */
 /* 插入数据 `lzh_member_moneylog` */
 INSERT INTO `lzh_member_moneylog` VALUES ('23','3','27','16000.00','16000.00','0.00','0.00','0.00','支付宝充值','1429851124','106.39.13.9','0','@网站管理员@','');/* DBReback Separation */
 /* 插入数据 `lzh_member_moneylog` */
 INSERT INTO `lzh_member_moneylog` VALUES ('24','3','6','-10000.00','6000.00','0.00','0.00','10000.00','对1号标进行投标','1429851268','106.39.13.19','1','whttcy','');/* DBReback Separation */
 /* 插入数据 `lzh_member_moneylog` */
 INSERT INTO `lzh_member_moneylog` VALUES ('25','9','27','200.00','200.00','0.00','0.00','0.00','支付宝充值','1429851501','106.39.13.9','0','@网站管理员@','');/* DBReback Separation */
 /* 插入数据 `lzh_member_moneylog` */
 INSERT INTO `lzh_member_moneylog` VALUES ('26','27','27','1.00','1.00','0.00','0.00','0.00','支付宝充值','1429851522','106.39.13.9','0','@网站管理员@','');/* DBReback Separation */
 /* 插入数据 `lzh_member_moneylog` */
 INSERT INTO `lzh_member_moneylog` VALUES ('27','9','6','-200.00','0.00','0.00','0.00','200.00','对1号标进行投标','1429851767','106.39.13.9','1','whttcy','');/* DBReback Separation */
 /* 插入数据 `lzh_member_moneylog` */
 INSERT INTO `lzh_member_moneylog` VALUES ('28','3','53','1.00','5999.00','0.00','0.00','10000.00','订单支付保证金','1429852004','106.39.13.9','0','平台运行商','13');/* DBReback Separation */
 /* 插入数据 `lzh_member_moneylog` */
 INSERT INTO `lzh_member_moneylog` VALUES ('29','21','53','1.00','0.00','0.00','0.00','0.00','订单支付保证金','1429852051','106.39.13.9','0','平台运行商','12');/* DBReback Separation */
 /* 插入数据 `lzh_member_moneylog` */
 INSERT INTO `lzh_member_moneylog` VALUES ('30','28','27','1.00','1.00','0.00','0.00','0.00','支付宝充值','1429852060','106.39.13.9','0','@网站管理员@','');/* DBReback Separation */
 /* 插入数据 `lzh_member_moneylog` */
 INSERT INTO `lzh_member_moneylog` VALUES ('31','26','53','1.00','0.00','0.00','0.00','0.00','订单支付保证金','1429852060','106.39.13.9','0','平台运行商','11');/* DBReback Separation */
 /* 插入数据 `lzh_member_moneylog` */
 INSERT INTO `lzh_member_moneylog` VALUES ('32','12','53','1.00','100.00','0.00','0.00','0.00','订单支付保证金','1429852067','106.39.13.9','0','平台运行商','10');/* DBReback Separation */
 /* 插入数据 `lzh_member_moneylog` */
 INSERT INTO `lzh_member_moneylog` VALUES ('33','18','53','1.00','0.00','0.00','0.00','0.00','订单支付保证金','1429852098','106.39.13.9','0','平台运行商','9');/* DBReback Separation */
 /* 插入数据 `lzh_member_moneylog` */
 INSERT INTO `lzh_member_moneylog` VALUES ('34','13','53','1.00','0.00','0.00','0.00','1000.00','订单支付保证金','1429852106','106.39.13.9','0','平台运行商','5');/* DBReback Separation */
 /* 插入数据 `lzh_member_moneylog` */
 INSERT INTO `lzh_member_moneylog` VALUES ('35','15','53','1.00','2.00','0.00','0.00','1000.00','订单支付保证金','1429852171','106.39.13.9','0','平台运行商','14');/* DBReback Separation */
 /* 插入数据 `lzh_member_moneylog` */
 INSERT INTO `lzh_member_moneylog` VALUES ('36','28','53','1.00','0.00','0.00','0.00','0.00','订单支付保证金','1429852318','106.39.13.9','0','平台运行商','15');/* DBReback Separation */
 /* 插入数据 `lzh_member_moneylog` */
 INSERT INTO `lzh_member_moneylog` VALUES ('37','16','53','1.00','99.00','0.00','0.00','0.00','订单支付保证金','1429852351','106.39.13.9','0','平台运行商','8');/* DBReback Separation */
 /* 插入数据 `lzh_member_moneylog` */
 INSERT INTO `lzh_member_moneylog` VALUES ('38','4','53','1.00','0.00','0.00','0.00','0.00','订单支付保证金','1429852359','106.39.13.9','0','平台运行商','4');/* DBReback Separation */
 /* 插入数据 `lzh_member_moneylog` */
 INSERT INTO `lzh_member_moneylog` VALUES ('39','5','53','1.00','0.00','0.00','0.00','0.00','订单支付保证金','1429852438','106.39.13.9','0','平台运行商','3');/* DBReback Separation */
 /* 插入数据 `lzh_member_moneylog` */
 INSERT INTO `lzh_member_moneylog` VALUES ('40','22','27','1.00','1.00','0.00','0.00','5000.00','支付宝充值','1429852513','106.39.13.9','0','@网站管理员@','');/* DBReback Separation */
 /* 插入数据 `lzh_member_moneylog` */
 INSERT INTO `lzh_member_moneylog` VALUES ('41','14','27','1.00','1.00','0.00','0.00','0.00','支付宝充值','1429852752','106.39.13.9','0','@网站管理员@','');/* DBReback Separation */
 /* 插入数据 `lzh_member_moneylog` */
 INSERT INTO `lzh_member_moneylog` VALUES ('42','9','27','1.00','1.00','0.00','0.00','200.00','支付宝充值','1429852757','106.39.13.9','0','@网站管理员@','');/* DBReback Separation */
 /* 插入数据 `lzh_member_moneylog` */
 INSERT INTO `lzh_member_moneylog` VALUES ('43','14','53','1.00','0.00','0.00','0.00','0.00','订单支付保证金','1429853180','106.39.13.9','0','平台运行商','17');/* DBReback Separation */
 /* 插入数据 `lzh_member_moneylog` */
 INSERT INTO `lzh_member_moneylog` VALUES ('44','14','27','5000.00','5000.00','0.00','0.00','0.00','支付宝充值','1429853243','106.39.13.9','0','@网站管理员@','');/* DBReback Separation */
 /* 插入数据 `lzh_member_moneylog` */
 INSERT INTO `lzh_member_moneylog` VALUES ('45','24','27','1.00','1.00','0.00','0.00','0.00','支付宝充值','1429853250','106.39.13.9','0','@网站管理员@','');/* DBReback Separation */
 /* 插入数据 `lzh_member_moneylog` */
 INSERT INTO `lzh_member_moneylog` VALUES ('46','10','27','1.00','1.00','0.00','0.00','0.00','支付宝充值','1429853548','106.39.13.9','0','@网站管理员@','');/* DBReback Separation */
 /* 插入数据 `lzh_member_moneylog` */
 INSERT INTO `lzh_member_moneylog` VALUES ('47','16','27','4000.00','4099.00','0.00','0.00','0.00','支付宝充值','1429853558','106.39.13.9','0','@网站管理员@','');/* DBReback Separation */
 /* 插入数据 `lzh_member_moneylog` */
 INSERT INTO `lzh_member_moneylog` VALUES ('48','16','6','-4000.00','99.00','0.00','0.00','4000.00','对1号标进行投标','1429853721','106.39.13.9','1','whttcy','');/* DBReback Separation */
 /* 插入数据 `lzh_member_moneylog` */
 INSERT INTO `lzh_member_moneylog` VALUES ('49','22','53','1.00','0.00','0.00','0.00','5000.00','订单支付保证金','1429853986','106.39.13.9','0','平台运行商','16');/* DBReback Separation */
 /* 插入数据 `lzh_member_moneylog` */
 INSERT INTO `lzh_member_moneylog` VALUES ('50','9','53','1.00','0.00','0.00','0.00','200.00','订单支付保证金','1429854013','106.39.13.9','0','平台运行商','18');/* DBReback Separation */
 /* 插入数据 `lzh_member_moneylog` */
 INSERT INTO `lzh_member_moneylog` VALUES ('51','24','53','1.00','0.00','0.00','0.00','0.00','订单支付保证金','1429854017','106.39.13.9','0','平台运行商','19');/* DBReback Separation */
 /* 插入数据 `lzh_member_moneylog` */
 INSERT INTO `lzh_member_moneylog` VALUES ('52','10','53','1.00','0.00','0.00','0.00','0.00','订单支付保证金','1429854033','106.39.13.9','0','平台运行商','20');/* DBReback Separation */
 /* 插入数据 `lzh_member_moneylog` */
 INSERT INTO `lzh_member_moneylog` VALUES ('53','26','27','6500.00','6500.00','0.00','0.00','0.00','支付宝充值','1429856048','106.39.13.9','0','@网站管理员@','');/* DBReback Separation */
 /* 插入数据 `lzh_member_moneylog` */
 INSERT INTO `lzh_member_moneylog` VALUES ('54','26','6','-5000.00','1500.00','0.00','0.00','5000.00','对1号标进行投标','1429856109','106.39.13.9','1','whttcy','');/* DBReback Separation */
 /* 插入数据 `lzh_member_moneylog` */
 INSERT INTO `lzh_member_moneylog` VALUES ('55','26','6','-1500.00','0.00','0.00','0.00','6500.00','对1号标进行投标','1429856116','106.39.13.9','1','whttcy','');/* DBReback Separation */
 /* 插入数据 `lzh_member_moneylog` */
 INSERT INTO `lzh_member_moneylog` VALUES ('56','24','27','100.00','100.00','0.00','0.00','0.00','支付宝充值','1429856160','106.39.13.9','0','@网站管理员@','');/* DBReback Separation */
 /* 插入数据 `lzh_member_moneylog` */
 INSERT INTO `lzh_member_moneylog` VALUES ('57','15','27','1000.00','1002.00','0.00','0.00','1000.00','支付宝充值','1429856203','106.39.13.9','0','@网站管理员@','');/* DBReback Separation */
 /* 插入数据 `lzh_member_moneylog` */
 INSERT INTO `lzh_member_moneylog` VALUES ('58','24','6','-100.00','0.00','0.00','0.00','100.00','对1号标进行投标','1429856225','106.39.13.19','1','whttcy','');/* DBReback Separation */
 /* 插入数据 `lzh_member_moneylog` */
 INSERT INTO `lzh_member_moneylog` VALUES ('59','31','27','1000.00','1000.00','0.00','0.00','0.00','支付宝充值','1429856978','106.39.13.9','0','@网站管理员@','');/* DBReback Separation */
 /* 插入数据 `lzh_member_moneylog` */
 INSERT INTO `lzh_member_moneylog` VALUES ('60','6','7','10000000.00','10000000.00','0.00','0.00','0.00','内部专用','1429857202','106.39.13.9','0','@网站管理员@','');/* DBReback Separation */
 /* 插入数据 `lzh_member_moneylog` */
 INSERT INTO `lzh_member_moneylog` VALUES ('61','6','6','-40000.00','9960000.00','0.00','0.00','40000.00','对1号标进行投标','1429857382','106.39.13.9','1','whttcy','');/* DBReback Separation */
 /* 插入数据 `lzh_member_moneylog` */
 INSERT INTO `lzh_member_moneylog` VALUES ('62','19','27','100.00','100.00','0.00','0.00','0.00','管理员手动审核充值','1429857422','106.39.13.9','0','@网站管理员@','');/* DBReback Separation */
 /* 插入数据 `lzh_member_moneylog` */
 INSERT INTO `lzh_member_moneylog` VALUES ('63','19','6','-100.00','0.00','0.00','0.00','100.00','对1号标进行投标','1429857469','106.39.13.19','1','whttcy','');/* DBReback Separation */
 /* 插入数据 `lzh_member_moneylog` */
 INSERT INTO `lzh_member_moneylog` VALUES ('64','7','27','1000.00','1000.00','0.00','0.00','0.00','支付宝充值','1429857547','106.39.13.9','0','@网站管理员@','');/* DBReback Separation */
 /* 插入数据 `lzh_member_moneylog` */
 INSERT INTO `lzh_member_moneylog` VALUES ('65','14','6','-5000.00','0.00','0.00','0.00','5000.00','对1号标进行投标','1429857549','106.39.13.19','1','whttcy','');/* DBReback Separation */
 /* 插入数据 `lzh_member_moneylog` */
 INSERT INTO `lzh_member_moneylog` VALUES ('66','31','6','-1000.00','0.00','0.00','0.00','1000.00','对1号标进行投标','1429857692','106.39.13.9','1','whttcy','');/* DBReback Separation */
 /* 插入数据 `lzh_member_moneylog` */
 INSERT INTO `lzh_member_moneylog` VALUES ('67','33','27','1.00','1.00','0.00','0.00','0.00','支付宝充值','1429857792','106.39.13.9','0','@网站管理员@','');/* DBReback Separation */
 /* 插入数据 `lzh_member_moneylog` */
 INSERT INTO `lzh_member_moneylog` VALUES ('68','31','53','1.00','-1.00','0.00','0.00','1000.00','订单支付保证金','1429857886','106.39.13.9','0','平台运行商','21');/* DBReback Separation */
 /* 插入数据 `lzh_member_moneylog` */
 INSERT INTO `lzh_member_moneylog` VALUES ('69','7','6','-500.00','500.00','0.00','0.00','500.00','对1号标进行投标','1429857896','106.39.13.9','1','whttcy','');/* DBReback Separation */
 /* 插入数据 `lzh_member_moneylog` */
 INSERT INTO `lzh_member_moneylog` VALUES ('70','24','27','400.00','400.00','0.00','0.00','100.00','支付宝充值','1429857947','106.39.13.9','0','@网站管理员@','');/* DBReback Separation */
 /* 插入数据 `lzh_member_moneylog` */
 INSERT INTO `lzh_member_moneylog` VALUES ('71','7','6','-500.00','0.00','0.00','0.00','1000.00','对1号标进行投标','1429858006','106.39.13.9','1','whttcy','');/* DBReback Separation */
 /* 插入数据 `lzh_member_moneylog` */
 INSERT INTO `lzh_member_moneylog` VALUES ('72','24','6','-400.00','0.00','0.00','0.00','500.00','对1号标进行投标','1429858082','106.39.13.19','1','whttcy','');/* DBReback Separation */
 /* 插入数据 `lzh_member_moneylog` */
 INSERT INTO `lzh_member_moneylog` VALUES ('73','32','27','1000.00','1000.00','0.00','0.00','0.00','支付宝充值','1429858243','106.39.13.9','0','@网站管理员@','');/* DBReback Separation */
 /* 插入数据 `lzh_member_moneylog` */
 INSERT INTO `lzh_member_moneylog` VALUES ('74','32','6','-1000.00','0.00','0.00','0.00','1000.00','对1号标进行投标','1429858427','106.39.13.9','1','whttcy','');/* DBReback Separation */
 /* 插入数据 `lzh_member_moneylog` */
 INSERT INTO `lzh_member_moneylog` VALUES ('75','6','6','-10000.00','9950000.00','0.00','0.00','50000.00','对1号标进行投标','1429858568','106.39.13.9','1','whttcy','');/* DBReback Separation */
 /* 插入数据 `lzh_member_moneylog` */
 INSERT INTO `lzh_member_moneylog` VALUES ('76','12','6','-100.00','0.00','0.00','0.00','100.00','对1号标进行投标','1429858752','106.39.13.9','1','whttcy','');/* DBReback Separation */
 /* 插入数据 `lzh_member_moneylog` */
 INSERT INTO `lzh_member_moneylog` VALUES ('77','15','6','-1000.00','2.00','0.00','0.00','2000.00','对1号标进行投标','1429858877','117.62.134.55','1','whttcy','');/* DBReback Separation */
 /* 插入数据 `lzh_member_moneylog` */
 INSERT INTO `lzh_member_moneylog` VALUES ('78','32','27','1.00','1.00','0.00','0.00','1000.00','支付宝充值','1429859029','106.39.13.9','0','@网站管理员@','');/* DBReback Separation */
 /* 插入数据 `lzh_member_moneylog` */
 INSERT INTO `lzh_member_moneylog` VALUES ('79','19','27','400.00','400.00','0.00','0.00','100.00','支付宝充值','1429859544','106.39.13.9','0','@网站管理员@','');/* DBReback Separation */
 /* 插入数据 `lzh_member_moneylog` */
 INSERT INTO `lzh_member_moneylog` VALUES ('80','8','27','1000.00','1000.00','0.00','0.00','0.00','支付宝充值','1429859571','106.39.13.9','0','@网站管理员@','');/* DBReback Separation */
 /* 插入数据 `lzh_member_moneylog` */
 INSERT INTO `lzh_member_moneylog` VALUES ('81','19','6','-400.00','0.00','0.00','0.00','500.00','对1号标进行投标','1429859594','106.39.13.19','1','whttcy','');/* DBReback Separation */
 /* 插入数据 `lzh_member_moneylog` */
 INSERT INTO `lzh_member_moneylog` VALUES ('82','8','6','-1000.00','0.00','0.00','0.00','1000.00','对1号标进行投标','1429859705','106.39.13.9','1','whttcy','');/* DBReback Separation */
 /* 插入数据 `lzh_member_moneylog` */
 INSERT INTO `lzh_member_moneylog` VALUES ('83','34','3','1000.00','1000.00','0.00','0.00','0.00','充值订单号:20150424151707196731','1429859893','114.80.78.215','0','@网站管理员@','');/* DBReback Separation */
 /* 插入数据 `lzh_member_moneylog` */
 INSERT INTO `lzh_member_moneylog` VALUES ('84','34','6','-1000.00','0.00','0.00','0.00','1000.00','对1号标进行投标','1429860032','106.39.13.19','1','whttcy','');/* DBReback Separation */
 /* 插入数据 `lzh_member_moneylog` */
 INSERT INTO `lzh_member_moneylog` VALUES ('85','6','6','-10200.00','9939800.00','0.00','0.00','60200.00','对1号标进行投标','1429860956','106.39.13.9','1','whttcy','');/* DBReback Separation */
 /* 插入数据 `lzh_member_moneylog` */
 INSERT INTO `lzh_member_moneylog` VALUES ('86','1','17','100000.00','101097.50','0.00','0.00','0.00','第1号标复审通过，借款金额入帐','1429861262','106.39.13.9','0','@网站管理员@','');/* DBReback Separation */
 /* 插入数据 `lzh_member_moneylog` */
 INSERT INTO `lzh_member_moneylog` VALUES ('87','1','18','-1000.00','100097.50','0.00','0.00','0.00','第1号标借款成功，扣除借款管理费','1429861262','106.39.13.9','0','@网站管理员@','');/* DBReback Separation */
 /* 插入数据 `lzh_member_moneylog` */
 INSERT INTO `lzh_member_moneylog` VALUES ('88','1','19','-10000.00','90097.50','0.00','0.00','10000.00','第1号标借款成功，冻结10%的保证金','1429861262','106.39.13.9','0','@网站管理员@','');/* DBReback Separation */
 /* 插入数据 `lzh_member_moneylog` */
 INSERT INTO `lzh_member_moneylog` VALUES ('89','13','15','1000.00','0.00','0.00','1000.00','0.00','第1号标复审通过，冻结本金成为待收金额','1429861262','106.39.13.9','1','whttcy','');/* DBReback Separation */
 /* 插入数据 `lzh_member_moneylog` */
 INSERT INTO `lzh_member_moneylog` VALUES ('90','13','28','10.67','0.00','0.00','1010.67','0.00','第1号标复审通过，应收利息成为待收利息','1429861262','106.39.13.9','1','whttcy','');/* DBReback Separation */
 /* 插入数据 `lzh_member_moneylog` */
 INSERT INTO `lzh_member_moneylog` VALUES ('91','22','15','5000.00','0.00','0.00','5000.00','0.00','第1号标复审通过，冻结本金成为待收金额','1429861262','106.39.13.9','1','whttcy','');/* DBReback Separation */
 /* 插入数据 `lzh_member_moneylog` */
 INSERT INTO `lzh_member_moneylog` VALUES ('92','22','28','53.33','0.00','0.00','5053.33','0.00','第1号标复审通过，应收利息成为待收利息','1429861262','106.39.13.9','1','whttcy','');/* DBReback Separation */
 /* 插入数据 `lzh_member_moneylog` */
 INSERT INTO `lzh_member_moneylog` VALUES ('93','15','15','1000.00','2.00','0.00','1000.00','1000.00','第1号标复审通过，冻结本金成为待收金额','1429861262','106.39.13.9','1','whttcy','');/* DBReback Separation */
 /* 插入数据 `lzh_member_moneylog` */
 INSERT INTO `lzh_member_moneylog` VALUES ('94','15','28','10.67','2.00','0.00','1010.67','1000.00','第1号标复审通过，应收利息成为待收利息','1429861262','106.39.13.9','1','whttcy','');/* DBReback Separation */
 /* 插入数据 `lzh_member_moneylog` */
 INSERT INTO `lzh_member_moneylog` VALUES ('95','8','13','1.00','1.00','0.00','0.00','1000.00','彭红对1号标投资成功，你获得推广奖励1.00元。','1429861262','106.39.13.9','15','彭红','');/* DBReback Separation */
 /* 插入数据 `lzh_member_moneylog` */
 INSERT INTO `lzh_member_moneylog` VALUES ('96','3','15','10000.00','5999.00','0.00','10000.00','0.00','第1号标复审通过，冻结本金成为待收金额','1429861262','106.39.13.9','1','whttcy','');/* DBReback Separation */
 /* 插入数据 `lzh_member_moneylog` */
 INSERT INTO `lzh_member_moneylog` VALUES ('97','3','28','106.67','5999.00','0.00','10106.67','0.00','第1号标复审通过，应收利息成为待收利息','1429861262','106.39.13.9','1','whttcy','');/* DBReback Separation */
 /* 插入数据 `lzh_member_moneylog` */
 INSERT INTO `lzh_member_moneylog` VALUES ('98','9','15','200.00','0.00','0.00','200.00','0.00','第1号标复审通过，冻结本金成为待收金额','1429861262','106.39.13.9','1','whttcy','');/* DBReback Separation */
 /* 插入数据 `lzh_member_moneylog` */
 INSERT INTO `lzh_member_moneylog` VALUES ('99','9','28','2.13','0.00','0.00','202.13','0.00','第1号标复审通过，应收利息成为待收利息','1429861262','106.39.13.9','1','whttcy','');/* DBReback Separation */
 /* 插入数据 `lzh_member_moneylog` */
 INSERT INTO `lzh_member_moneylog` VALUES ('100','16','15','4000.00','99.00','0.00','4000.00','0.00','第1号标复审通过，冻结本金成为待收金额','1429861262','106.39.13.9','1','whttcy','');/* DBReback Separation */
 /* 插入数据 `lzh_member_moneylog` */
 INSERT INTO `lzh_member_moneylog` VALUES ('101','16','28','42.67','99.00','0.00','4042.67','0.00','第1号标复审通过，应收利息成为待收利息','1429861262','106.39.13.9','1','whttcy','');/* DBReback Separation */
 /* 插入数据 `lzh_member_moneylog` */
 INSERT INTO `lzh_member_moneylog` VALUES ('102','26','15','5000.00','0.00','0.00','5000.00','1500.00','第1号标复审通过，冻结本金成为待收金额','1429861262','106.39.13.9','1','whttcy','');/* DBReback Separation */
 /* 插入数据 `lzh_member_moneylog` */
 INSERT INTO `lzh_member_moneylog` VALUES ('103','26','28','53.33','0.00','0.00','5053.33','1500.00','第1号标复审通过，应收利息成为待收利息','1429861262','106.39.13.9','1','whttcy','');/* DBReback Separation */
 /* 插入数据 `lzh_member_moneylog` */
 INSERT INTO `lzh_member_moneylog` VALUES ('104','26','15','1500.00','0.00','0.00','6553.33','0.00','第1号标复审通过，冻结本金成为待收金额','1429861262','106.39.13.9','1','whttcy','');/* DBReback Separation */
 /* 插入数据 `lzh_member_moneylog` */
 INSERT INTO `lzh_member_moneylog` VALUES ('105','26','28','16.00','0.00','0.00','6569.33','0.00','第1号标复审通过，应收利息成为待收利息','1429861262','106.39.13.9','1','whttcy','');/* DBReback Separation */
 /* 插入数据 `lzh_member_moneylog` */
 INSERT INTO `lzh_member_moneylog` VALUES ('106','24','15','100.00','0.00','0.00','100.00','400.00','第1号标复审通过，冻结本金成为待收金额','1429861262','106.39.13.9','1','whttcy','');/* DBReback Separation */
 /* 插入数据 `lzh_member_moneylog` */
 INSERT INTO `lzh_member_moneylog` VALUES ('107','24','28','1.07','0.00','0.00','101.07','400.00','第1号标复审通过，应收利息成为待收利息','1429861262','106.39.13.9','1','whttcy','');/* DBReback Separation */
 /* 插入数据 `lzh_member_moneylog` */
 INSERT INTO `lzh_member_moneylog` VALUES ('108','6','15','40000.00','9939800.00','0.00','40000.00','20200.00','第1号标复审通过，冻结本金成为待收金额','1429861262','106.39.13.9','1','whttcy','');/* DBReback Separation */
 /* 插入数据 `lzh_member_moneylog` */
 INSERT INTO `lzh_member_moneylog` VALUES ('109','6','28','426.67','9939800.00','0.00','40426.67','20200.00','第1号标复审通过，应收利息成为待收利息','1429861262','106.39.13.9','1','whttcy','');/* DBReback Separation */
 /* 插入数据 `lzh_member_moneylog` */
 INSERT INTO `lzh_member_moneylog` VALUES ('110','1','13','40.00','90137.50','0.00','0.00','10000.00','whttcy1对1号标投资成功，你获得推广奖励40.00元。','1429861262','106.39.13.9','6','whttcy1','');/* DBReback Separation */
 /* 插入数据 `lzh_member_moneylog` */
 INSERT INTO `lzh_member_moneylog` VALUES ('111','19','15','100.00','0.00','0.00','100.00','400.00','第1号标复审通过，冻结本金成为待收金额','1429861262','106.39.13.9','1','whttcy','');/* DBReback Separation */
 /* 插入数据 `lzh_member_moneylog` */
 INSERT INTO `lzh_member_moneylog` VALUES ('112','19','28','1.07','0.00','0.00','101.07','400.00','第1号标复审通过，应收利息成为待收利息','1429861262','106.39.13.9','1','whttcy','');/* DBReback Separation */
 /* 插入数据 `lzh_member_moneylog` */
 INSERT INTO `lzh_member_moneylog` VALUES ('113','9','13','0.10','0.10','0.00','202.13','0.00','zhengyu对1号标投资成功，你获得推广奖励0.10元。','1429861262','106.39.13.9','19','zhengyu','');/* DBReback Separation */
 /* 插入数据 `lzh_member_moneylog` */
 INSERT INTO `lzh_member_moneylog` VALUES ('114','14','15','5000.00','0.00','0.00','5000.00','0.00','第1号标复审通过，冻结本金成为待收金额','1429861262','106.39.13.9','1','whttcy','');/* DBReback Separation */
 /* 插入数据 `lzh_member_moneylog` */
 INSERT INTO `lzh_member_moneylog` VALUES ('115','14','28','53.33','0.00','0.00','5053.33','0.00','第1号标复审通过，应收利息成为待收利息','1429861262','106.39.13.9','1','whttcy','');/* DBReback Separation */
 /* 插入数据 `lzh_member_moneylog` */
 INSERT INTO `lzh_member_moneylog` VALUES ('116','31','15','1000.00','0.00','0.00','1000.00','0.00','第1号标复审通过，冻结本金成为待收金额','1429861262','106.39.13.9','1','whttcy','');/* DBReback Separation */
 /* 插入数据 `lzh_member_moneylog` */
 INSERT INTO `lzh_member_moneylog` VALUES ('117','31','28','10.67','0.00','0.00','1010.67','0.00','第1号标复审通过，应收利息成为待收利息','1429861262','106.39.13.9','1','whttcy','');/* DBReback Separation */
 /* 插入数据 `lzh_member_moneylog` */
 INSERT INTO `lzh_member_moneylog` VALUES ('118','7','15','500.00','0.00','0.00','500.00','500.00','第1号标复审通过，冻结本金成为待收金额','1429861262','106.39.13.9','1','whttcy','');/* DBReback Separation */
 /* 插入数据 `lzh_member_moneylog` */
 INSERT INTO `lzh_member_moneylog` VALUES ('119','7','28','5.33','0.00','0.00','505.33','500.00','第1号标复审通过，应收利息成为待收利息','1429861262','106.39.13.9','1','whttcy','');/* DBReback Separation */
 /* 插入数据 `lzh_member_moneylog` */
 INSERT INTO `lzh_member_moneylog` VALUES ('120','7','15','500.00','0.00','0.00','1005.33','0.00','第1号标复审通过，冻结本金成为待收金额','1429861262','106.39.13.9','1','whttcy','');/* DBReback Separation */
 /* 插入数据 `lzh_member_moneylog` */
 INSERT INTO `lzh_member_moneylog` VALUES ('121','7','28','5.33','0.00','0.00','1010.66','0.00','第1号标复审通过，应收利息成为待收利息','1429861262','106.39.13.9','1','whttcy','');/* DBReback Separation */
 /* 插入数据 `lzh_member_moneylog` */
 INSERT INTO `lzh_member_moneylog` VALUES ('122','24','15','400.00','0.00','0.00','501.07','0.00','第1号标复审通过，冻结本金成为待收金额','1429861262','106.39.13.9','1','whttcy','');/* DBReback Separation */
 /* 插入数据 `lzh_member_moneylog` */
 INSERT INTO `lzh_member_moneylog` VALUES ('123','24','28','4.27','0.00','0.00','505.34','0.00','第1号标复审通过，应收利息成为待收利息','1429861262','106.39.13.9','1','whttcy','');/* DBReback Separation */
 /* 插入数据 `lzh_member_moneylog` */
 INSERT INTO `lzh_member_moneylog` VALUES ('124','32','15','1000.00','1.00','0.00','1000.00','0.00','第1号标复审通过，冻结本金成为待收金额','1429861262','106.39.13.9','1','whttcy','');/* DBReback Separation */
 /* 插入数据 `lzh_member_moneylog` */
 INSERT INTO `lzh_member_moneylog` VALUES ('125','32','28','10.67','1.00','0.00','1010.67','0.00','第1号标复审通过，应收利息成为待收利息','1429861262','106.39.13.9','1','whttcy','');/* DBReback Separation */
 /* 插入数据 `lzh_member_moneylog` */
 INSERT INTO `lzh_member_moneylog` VALUES ('126','6','15','10000.00','9939800.00','0.00','50426.67','10200.00','第1号标复审通过，冻结本金成为待收金额','1429861263','106.39.13.9','1','whttcy','');/* DBReback Separation */
 /* 插入数据 `lzh_member_moneylog` */
 INSERT INTO `lzh_member_moneylog` VALUES ('127','6','28','106.67','9939800.00','0.00','50533.34','10200.00','第1号标复审通过，应收利息成为待收利息','1429861263','106.39.13.9','1','whttcy','');/* DBReback Separation */
 /* 插入数据 `lzh_member_moneylog` */
 INSERT INTO `lzh_member_moneylog` VALUES ('128','1','13','10.00','90147.50','0.00','0.00','10000.00','whttcy1对1号标投资成功，你获得推广奖励10.00元。','1429861263','106.39.13.9','6','whttcy1','');/* DBReback Separation */
 /* 插入数据 `lzh_member_moneylog` */
 INSERT INTO `lzh_member_moneylog` VALUES ('129','12','15','100.00','0.00','0.00','100.00','0.00','第1号标复审通过，冻结本金成为待收金额','1429861263','106.39.13.9','1','whttcy','');/* DBReback Separation */
 /* 插入数据 `lzh_member_moneylog` */
 INSERT INTO `lzh_member_moneylog` VALUES ('130','12','28','1.07','0.00','0.00','101.07','0.00','第1号标复审通过，应收利息成为待收利息','1429861263','106.39.13.9','1','whttcy','');/* DBReback Separation */
 /* 插入数据 `lzh_member_moneylog` */
 INSERT INTO `lzh_member_moneylog` VALUES ('131','15','15','1000.00','2.00','0.00','2010.67','0.00','第1号标复审通过，冻结本金成为待收金额','1429861263','106.39.13.9','1','whttcy','');/* DBReback Separation */
 /* 插入数据 `lzh_member_moneylog` */
 INSERT INTO `lzh_member_moneylog` VALUES ('132','15','28','10.67','2.00','0.00','2021.34','0.00','第1号标复审通过，应收利息成为待收利息','1429861263','106.39.13.9','1','whttcy','');/* DBReback Separation */
 /* 插入数据 `lzh_member_moneylog` */
 INSERT INTO `lzh_member_moneylog` VALUES ('133','8','13','1.00','2.00','0.00','0.00','1000.00','彭红对1号标投资成功，你获得推广奖励1.00元。','1429861263','106.39.13.9','15','彭红','');/* DBReback Separation */
 /* 插入数据 `lzh_member_moneylog` */
 INSERT INTO `lzh_member_moneylog` VALUES ('134','19','15','400.00','0.00','0.00','501.07','0.00','第1号标复审通过，冻结本金成为待收金额','1429861263','106.39.13.9','1','whttcy','');/* DBReback Separation */
 /* 插入数据 `lzh_member_moneylog` */
 INSERT INTO `lzh_member_moneylog` VALUES ('135','19','28','4.27','0.00','0.00','505.34','0.00','第1号标复审通过，应收利息成为待收利息','1429861263','106.39.13.9','1','whttcy','');/* DBReback Separation */
 /* 插入数据 `lzh_member_moneylog` */
 INSERT INTO `lzh_member_moneylog` VALUES ('136','9','13','0.40','0.50','0.00','202.13','0.00','zhengyu对1号标投资成功，你获得推广奖励0.40元。','1429861263','106.39.13.9','19','zhengyu','');/* DBReback Separation */
 /* 插入数据 `lzh_member_moneylog` */
 INSERT INTO `lzh_member_moneylog` VALUES ('137','8','15','1000.00','2.00','0.00','1000.00','0.00','第1号标复审通过，冻结本金成为待收金额','1429861263','106.39.13.9','1','whttcy','');/* DBReback Separation */
 /* 插入数据 `lzh_member_moneylog` */
 INSERT INTO `lzh_member_moneylog` VALUES ('138','8','28','10.67','2.00','0.00','1010.67','0.00','第1号标复审通过，应收利息成为待收利息','1429861263','106.39.13.9','1','whttcy','');/* DBReback Separation */
 /* 插入数据 `lzh_member_moneylog` */
 INSERT INTO `lzh_member_moneylog` VALUES ('139','34','15','1000.00','0.00','0.00','1000.00','0.00','第1号标复审通过，冻结本金成为待收金额','1429861263','106.39.13.9','1','whttcy','');/* DBReback Separation */
 /* 插入数据 `lzh_member_moneylog` */
 INSERT INTO `lzh_member_moneylog` VALUES ('140','34','28','10.67','0.00','0.00','1010.67','0.00','第1号标复审通过，应收利息成为待收利息','1429861263','106.39.13.9','1','whttcy','');/* DBReback Separation */
 /* 插入数据 `lzh_member_moneylog` */
 INSERT INTO `lzh_member_moneylog` VALUES ('141','6','15','10200.00','9939800.00','0.00','60733.34','0.00','第1号标复审通过，冻结本金成为待收金额','1429861263','106.39.13.9','1','whttcy','');/* DBReback Separation */
 /* 插入数据 `lzh_member_moneylog` */
 INSERT INTO `lzh_member_moneylog` VALUES ('142','6','28','108.80','9939800.00','0.00','60842.14','0.00','第1号标复审通过，应收利息成为待收利息','1429861263','106.39.13.9','1','whttcy','');/* DBReback Separation */
 /* 插入数据 `lzh_member_moneylog` */
 INSERT INTO `lzh_member_moneylog` VALUES ('143','1','13','10.20','90157.70','0.00','0.00','10000.00','whttcy1对1号标投资成功，你获得推广奖励10.20元。','1429861263','106.39.13.9','6','whttcy1','');/* DBReback Separation */
 /* 插入数据 `lzh_member_moneylog` */
 INSERT INTO `lzh_member_moneylog` VALUES ('144','35','27','1.00','1.00','0.00','0.00','0.00','支付宝充值','1429861941','106.39.13.9','0','@网站管理员@','');/* DBReback Separation */
 /* 插入数据 `lzh_member_moneylog` */
 INSERT INTO `lzh_member_moneylog` VALUES ('145','39','27','1.00','1.00','0.00','0.00','0.00','支付宝充值','1430099591','106.39.13.15','0','@网站管理员@','');/* DBReback Separation */
 /* 插入数据 `lzh_member_moneylog` */
 INSERT INTO `lzh_member_moneylog` VALUES ('146','39','27','1.00','2.00','0.00','0.00','0.00','支付宝充值','1430099594','106.39.13.15','0','@网站管理员@','');/* DBReback Separation */
 /* 插入数据 `lzh_member_moneylog` */
 INSERT INTO `lzh_member_moneylog` VALUES ('147','39','27','1.00','3.00','0.00','0.00','0.00','支付宝充值','1430099598','106.39.13.15','0','@网站管理员@','');/* DBReback Separation */
 /* 插入数据 `lzh_member_moneylog` */
 INSERT INTO `lzh_member_moneylog` VALUES ('148','39','53','1.00','2.00','0.00','0.00','0.00','订单支付保证金','1430100164','106.39.13.15','0','平台运行商','26');/* DBReback Separation */
 /* 插入数据 `lzh_member_moneylog` */
 INSERT INTO `lzh_member_moneylog` VALUES ('149','27','53','1.00','0.00','0.00','0.00','0.00','订单支付保证金','1430113603','106.39.13.15','0','平台运行商','27');/* DBReback Separation */ 
 /* 数据表结构 `lzh_member_msg`*/ 
 DROP TABLE IF EXISTS `lzh_member_msg`;/* DBReback Separation */ 
 CREATE TABLE `lzh_member_msg` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `from_uid` int(11) NOT NULL,
  `from_uname` varchar(20) NOT NULL,
  `to_uid` int(11) NOT NULL,
  `to_uname` varchar(20) NOT NULL,
  `title` varchar(50) NOT NULL,
  `msg` varchar(2000) NOT NULL,
  `add_time` int(10) unsigned NOT NULL,
  `is_read` tinyint(3) unsigned NOT NULL DEFAULT '0',
  `type` smallint(6) NOT NULL,
  `to_del` tinyint(4) NOT NULL DEFAULT '0',
  `from_del` tinyint(4) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;/* DBReback Separation */ 
 /* 数据表结构 `lzh_member_payonline`*/ 
 DROP TABLE IF EXISTS `lzh_member_payonline`;/* DBReback Separation */ 
 CREATE TABLE `lzh_member_payonline` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `uid` int(10) unsigned NOT NULL,
  `nid` char(32) NOT NULL,
  `money` decimal(15,2) NOT NULL,
  `fee` decimal(8,2) NOT NULL,
  `way` varchar(20) NOT NULL,
  `status` tinyint(4) NOT NULL DEFAULT '0',
  `add_time` int(10) unsigned NOT NULL,
  `add_ip` varchar(16) NOT NULL,
  `tran_id` varchar(50) NOT NULL,
  `off_bank` varchar(50) NOT NULL,
  `off_way` varchar(100) NOT NULL,
  `deal_user` varchar(40) NOT NULL,
  `deal_uid` int(11) NOT NULL,
  `payimg` varchar(1000) NOT NULL COMMENT '上传打款凭证',
  PRIMARY KEY (`id`),
  KEY `uid` (`uid`,`status`,`nid`,`id`),
  KEY `uid_2` (`uid`,`money`,`add_time`)
) ENGINE=InnoDB AUTO_INCREMENT=65 DEFAULT CHARSET=utf8;/* DBReback Separation */
 /* 插入数据 `lzh_member_payonline` */
 INSERT INTO `lzh_member_payonline` VALUES ('1','1','8f3e16c8301a992d1c1af23fc514388d','1000.00','1.50','ecpss','3','1429776443','124.205.215.55','','','','admin','113','');/* DBReback Separation */
 /* 插入数据 `lzh_member_payonline` */
 INSERT INTO `lzh_member_payonline` VALUES ('2','1','88c25ec71eade5e260eb176e26dcd7ec','1000.00','1.50','ecpss','1','1429776459','124.205.215.55','20150423160739470949','','','','0','');/* DBReback Separation */
 /* 插入数据 `lzh_member_payonline` */
 INSERT INTO `lzh_member_payonline` VALUES ('3','1','65e1027fb2cfaca60d5b7443aaa195d5','100.00','0.00','ecpss','1','1429777635','124.205.215.55','20150423162715926423','','','','0','');/* DBReback Separation */
 /* 插入数据 `lzh_member_payonline` */
 INSERT INTO `lzh_member_payonline` VALUES ('4','2','741e8287ac5cef811d81768397b1f10c','50.00','0.00','ecpss','3','1429778241','124.205.215.55','','','','admin','113','');/* DBReback Separation */
 /* 插入数据 `lzh_member_payonline` */
 INSERT INTO `lzh_member_payonline` VALUES ('5','4','8d5d8f0c326075fde7dfe03be657a660','60.00','0.00','ecpss','3','1429784333','124.205.215.55','','','','admin','113','');/* DBReback Separation */
 /* 插入数据 `lzh_member_payonline` */
 INSERT INTO `lzh_member_payonline` VALUES ('6','5','cd006d0bf6a0514af0ab428633cd5088','1000.00','0.00','ecpss','3','1429785409','124.205.215.55','','','','admin','113','');/* DBReback Separation */
 /* 插入数据 `lzh_member_payonline` */
 INSERT INTO `lzh_member_payonline` VALUES ('7','5','alipay','1.00','0.00','alipay','1','1429786486','124.205.215.55','','','','admin','113','');/* DBReback Separation */
 /* 插入数据 `lzh_member_payonline` */
 INSERT INTO `lzh_member_payonline` VALUES ('8','4','alipay','1.00','0.00','alipay','1','1429786496','124.205.215.55','','','','admin','113','');/* DBReback Separation */
 /* 插入数据 `lzh_member_payonline` */
 INSERT INTO `lzh_member_payonline` VALUES ('9','13','6bcb8f78c4151d7340202b1e6b069e92','1000.00','0.00','ecpss','3','1429845484','106.39.13.9','','','','admin','113','');/* DBReback Separation */
 /* 插入数据 `lzh_member_payonline` */
 INSERT INTO `lzh_member_payonline` VALUES ('10','16','alipay','50.00','0.00','alipay','1','1429845652','106.39.13.9','','','','admin','113','');/* DBReback Separation */
 /* 插入数据 `lzh_member_payonline` */
 INSERT INTO `lzh_member_payonline` VALUES ('11','13','alipay','1000.00','0.00','alipay','1','1429845886','106.39.13.9','','','','admin','113','');/* DBReback Separation */
 /* 插入数据 `lzh_member_payonline` */
 INSERT INTO `lzh_member_payonline` VALUES ('12','11','alipay','1.00','0.00','alipay','3','1429846260','106.39.13.9','','','','admin','113','');/* DBReback Separation */
 /* 插入数据 `lzh_member_payonline` */
 INSERT INTO `lzh_member_payonline` VALUES ('13','9','96f53cec7384c406bc2399843fbade1c','100.00','0.00','ecpss','3','1429846301','106.39.13.9','','','','admin','113','');/* DBReback Separation */
 /* 插入数据 `lzh_member_payonline` */
 INSERT INTO `lzh_member_payonline` VALUES ('14','11','offline','1.00','0.00','off','1','1429846338','106.39.13.9','99999',' 开户名：','当面给的','admin','113','');/* DBReback Separation */
 /* 插入数据 `lzh_member_payonline` */
 INSERT INTO `lzh_member_payonline` VALUES ('15','2','offline','1.00','0.00','off','1','1429846431','106.39.13.9','9999999',' 开户名：','当前给的','admin','113','');/* DBReback Separation */
 /* 插入数据 `lzh_member_payonline` */
 INSERT INTO `lzh_member_payonline` VALUES ('16','12','alipay','101.00','0.00','alipay','1','1429846916','106.39.13.9','','','','admin','113','');/* DBReback Separation */
 /* 插入数据 `lzh_member_payonline` */
 INSERT INTO `lzh_member_payonline` VALUES ('17','18','alipay','1.00','0.00','alipay','1','1429846924','106.39.13.9','','','','admin','113','');/* DBReback Separation */
 /* 插入数据 `lzh_member_payonline` */
 INSERT INTO `lzh_member_payonline` VALUES ('18','13','alipay','1.00','0.00','alipay','1','1429846940','106.39.13.9','','','','admin','113','');/* DBReback Separation */
 /* 插入数据 `lzh_member_payonline` */
 INSERT INTO `lzh_member_payonline` VALUES ('19','16','alipay','50.00','0.00','alipay','1','1429846973','106.39.13.9','','','','admin','113','');/* DBReback Separation */
 /* 插入数据 `lzh_member_payonline` */
 INSERT INTO `lzh_member_payonline` VALUES ('20','15','3fe8c3f7448aacfcb7daebd25448bca1','1003.00','0.00','ecpss','1','1429847313','117.62.134.55','','','','admin','113','');/* DBReback Separation */
 /* 插入数据 `lzh_member_payonline` */
 INSERT INTO `lzh_member_payonline` VALUES ('21','22','b92b1ede30e4bd7b283fb5a9b3a223ec','5000.00','0.00','ecpss','1','1429847593','117.62.134.55','20150424115313808899','','','','0','');/* DBReback Separation */
 /* 插入数据 `lzh_member_payonline` */
 INSERT INTO `lzh_member_payonline` VALUES ('22','26','alipay','1.00','0.00','alipay','1','1429849889','106.39.13.9','','','','admin','113','');/* DBReback Separation */
 /* 插入数据 `lzh_member_payonline` */
 INSERT INTO `lzh_member_payonline` VALUES ('23','21','alipay','1.00','0.00','alipay','1','1429850175','106.39.13.9','','','','admin','113','');/* DBReback Separation */
 /* 插入数据 `lzh_member_payonline` */
 INSERT INTO `lzh_member_payonline` VALUES ('24','23','alipay','0.00','0.00','alipay','3','1429850747','106.39.13.9','','','','admin','113','');/* DBReback Separation */
 /* 插入数据 `lzh_member_payonline` */
 INSERT INTO `lzh_member_payonline` VALUES ('25','3','alipay','16000.00','0.00','alipay','1','1429851124','106.39.13.9','','','','admin','113','');/* DBReback Separation */
 /* 插入数据 `lzh_member_payonline` */
 INSERT INTO `lzh_member_payonline` VALUES ('26','9','alipay','200.00','0.00','alipay','1','1429851501','106.39.13.9','','','','admin','113','');/* DBReback Separation */
 /* 插入数据 `lzh_member_payonline` */
 INSERT INTO `lzh_member_payonline` VALUES ('27','27','alipay','1.00','0.00','alipay','1','1429851522','106.39.13.9','','','','admin','113','');/* DBReback Separation */
 /* 插入数据 `lzh_member_payonline` */
 INSERT INTO `lzh_member_payonline` VALUES ('28','14','7491eb1cbd2649893d35d6b98e617172','100.00','0.00','ecpss','3','1429851753','106.39.13.19','','','','admin','113','');/* DBReback Separation */
 /* 插入数据 `lzh_member_payonline` */
 INSERT INTO `lzh_member_payonline` VALUES ('29','28','alipay','1.00','0.00','alipay','1','1429852060','106.39.13.9','','','','admin','113','');/* DBReback Separation */
 /* 插入数据 `lzh_member_payonline` */
 INSERT INTO `lzh_member_payonline` VALUES ('30','22','alipay','1.00','0.00','alipay','1','1429852513','106.39.13.9','','','','admin','113','');/* DBReback Separation */
 /* 插入数据 `lzh_member_payonline` */
 INSERT INTO `lzh_member_payonline` VALUES ('31','14','alipay','1.00','0.00','alipay','1','1429852752','106.39.13.9','','','','admin','113','');/* DBReback Separation */
 /* 插入数据 `lzh_member_payonline` */
 INSERT INTO `lzh_member_payonline` VALUES ('32','9','alipay','1.00','0.00','alipay','1','1429852757','106.39.13.9','','','','admin','113','');/* DBReback Separation */
 /* 插入数据 `lzh_member_payonline` */
 INSERT INTO `lzh_member_payonline` VALUES ('33','14','alipay','5000.00','0.00','alipay','1','1429853243','106.39.13.9','','','','admin','113','');/* DBReback Separation */
 /* 插入数据 `lzh_member_payonline` */
 INSERT INTO `lzh_member_payonline` VALUES ('34','24','alipay','1.00','0.00','alipay','1','1429853250','106.39.13.9','','','','admin','113','');/* DBReback Separation */
 /* 插入数据 `lzh_member_payonline` */
 INSERT INTO `lzh_member_payonline` VALUES ('35','10','alipay','1.00','0.00','alipay','1','1429853548','106.39.13.9','','','','admin','113','');/* DBReback Separation */
 /* 插入数据 `lzh_member_payonline` */
 INSERT INTO `lzh_member_payonline` VALUES ('36','16','alipay','4000.00','0.00','alipay','1','1429853558','106.39.13.9','','','','admin','113','');/* DBReback Separation */
 /* 插入数据 `lzh_member_payonline` */
 INSERT INTO `lzh_member_payonline` VALUES ('37','30','7ae6ada1d5854bd24f5c98afff80dc3d','50.00','0.00','ecpss','3','1429853722','106.39.13.9','','','','admin','113','');/* DBReback Separation */
 /* 插入数据 `lzh_member_payonline` */
 INSERT INTO `lzh_member_payonline` VALUES ('38','30','b961706c3ff386f12167dd201f9e67f6','50.00','0.00','ecpss','3','1429853741','106.39.13.9','','','','admin','113','');/* DBReback Separation */
 /* 插入数据 `lzh_member_payonline` */
 INSERT INTO `lzh_member_payonline` VALUES ('39','30','545c92a74b6f704f774a0d32165722bd','50.00','0.00','ecpss','3','1429853813','106.39.13.9','','','','admin','113','');/* DBReback Separation */
 /* 插入数据 `lzh_member_payonline` */
 INSERT INTO `lzh_member_payonline` VALUES ('40','30','12384fcd78ccb7b9c1ce841446fd6dbf','50.00','0.00','ecpss','3','1429853874','106.39.13.9','','','','admin','113','');/* DBReback Separation */
 /* 插入数据 `lzh_member_payonline` */
 INSERT INTO `lzh_member_payonline` VALUES ('41','30','alipay','50.00','0.00','alipay','3','1429855665','106.39.13.9','','','','admin','113','');/* DBReback Separation */
 /* 插入数据 `lzh_member_payonline` */
 INSERT INTO `lzh_member_payonline` VALUES ('42','26','alipay','6500.00','0.00','alipay','1','1429856048','106.39.13.9','','','','admin','113','');/* DBReback Separation */
 /* 插入数据 `lzh_member_payonline` */
 INSERT INTO `lzh_member_payonline` VALUES ('43','24','alipay','100.00','0.00','alipay','1','1429856160','106.39.13.9','','','','admin','113','');/* DBReback Separation */
 /* 插入数据 `lzh_member_payonline` */
 INSERT INTO `lzh_member_payonline` VALUES ('44','15','alipay','1000.00','0.00','alipay','1','1429856203','106.39.13.9','','','','admin','113','');/* DBReback Separation */
 /* 插入数据 `lzh_member_payonline` */
 INSERT INTO `lzh_member_payonline` VALUES ('45','19','b405a6cc3c76bb302026775194c420b3','100.00','0.00','ecpss','1','1429856506','106.39.13.19','','','','admin','113','');/* DBReback Separation */
 /* 插入数据 `lzh_member_payonline` */
 INSERT INTO `lzh_member_payonline` VALUES ('46','7','1766e402181e29d0dfe2c9893534df63','1000.00','0.00','ecpss','3','1429856648','106.39.13.9','','','','admin','113','');/* DBReback Separation */
 /* 插入数据 `lzh_member_payonline` */
 INSERT INTO `lzh_member_payonline` VALUES ('47','31','alipay','1000.00','0.00','alipay','1','1429856978','106.39.13.9','','','','admin','113','');/* DBReback Separation */
 /* 插入数据 `lzh_member_payonline` */
 INSERT INTO `lzh_member_payonline` VALUES ('48','7','alipay','1000.00','0.00','alipay','1','1429857547','106.39.13.9','','','','admin','113','');/* DBReback Separation */
 /* 插入数据 `lzh_member_payonline` */
 INSERT INTO `lzh_member_payonline` VALUES ('49','31','alipay','1000.00','0.00','alipay','3','1429857700','106.39.13.9','','','','admin','113','');/* DBReback Separation */
 /* 插入数据 `lzh_member_payonline` */
 INSERT INTO `lzh_member_payonline` VALUES ('50','33','alipay','1.00','0.00','alipay','1','1429857792','106.39.13.9','','','','admin','113','');/* DBReback Separation */
 /* 插入数据 `lzh_member_payonline` */
 INSERT INTO `lzh_member_payonline` VALUES ('51','24','alipay','400.00','0.00','alipay','1','1429857947','106.39.13.9','','','','admin','113','');/* DBReback Separation */
 /* 插入数据 `lzh_member_payonline` */
 INSERT INTO `lzh_member_payonline` VALUES ('52','32','alipay','1000.00','0.00','alipay','1','1429858243','106.39.13.9','','','','admin','113','');/* DBReback Separation */
 /* 插入数据 `lzh_member_payonline` */
 INSERT INTO `lzh_member_payonline` VALUES ('53','32','alipay','1.00','0.00','alipay','1','1429859029','106.39.13.9','','','','admin','113','');/* DBReback Separation */
 /* 插入数据 `lzh_member_payonline` */
 INSERT INTO `lzh_member_payonline` VALUES ('54','19','alipay','400.00','0.00','alipay','1','1429859544','106.39.13.9','','','','admin','113','');/* DBReback Separation */
 /* 插入数据 `lzh_member_payonline` */
 INSERT INTO `lzh_member_payonline` VALUES ('55','8','alipay','1000.00','0.00','alipay','1','1429859571','106.39.13.9','','','','admin','113','');/* DBReback Separation */
 /* 插入数据 `lzh_member_payonline` */
 INSERT INTO `lzh_member_payonline` VALUES ('56','34','55745c5ca1d1c0c7904313838c3702bf','1000.00','0.00','ecpss','1','1429859827','106.39.13.19','20150424151707196731','','','','0','');/* DBReback Separation */
 /* 插入数据 `lzh_member_payonline` */
 INSERT INTO `lzh_member_payonline` VALUES ('57','21','e6c18d5634d2af45c96d323e9a584cf6','1000.00','0.00','ecpss','3','1429860830','106.39.13.9','','','','admin','113','');/* DBReback Separation */
 /* 插入数据 `lzh_member_payonline` */
 INSERT INTO `lzh_member_payonline` VALUES ('58','21','1e575bed8e8f999394f2e90472eba371','1000.00','0.00','ecpss','3','1429861174','106.39.13.9','','','','admin','113','');/* DBReback Separation */
 /* 插入数据 `lzh_member_payonline` */
 INSERT INTO `lzh_member_payonline` VALUES ('59','35','alipay','1.00','0.00','alipay','1','1429861941','106.39.13.9','','','','admin','113','');/* DBReback Separation */
 /* 插入数据 `lzh_member_payonline` */
 INSERT INTO `lzh_member_payonline` VALUES ('60','21','9a08e166e19538a14bf0f30f40296a18','1000.00','0.00','ecpss','3','1429862212','106.39.13.9','','','','admin','113','');/* DBReback Separation */
 /* 插入数据 `lzh_member_payonline` */
 INSERT INTO `lzh_member_payonline` VALUES ('61','35','e69975578dd5e353714db1db76649649','50.00','0.00','ecpss','3','1429862246','106.39.13.9','','','','admin','113','');/* DBReback Separation */
 /* 插入数据 `lzh_member_payonline` */
 INSERT INTO `lzh_member_payonline` VALUES ('62','39','alipay','1.00','0.00','alipay','1','1430099591','106.39.13.15','','','','admin','113','');/* DBReback Separation */
 /* 插入数据 `lzh_member_payonline` */
 INSERT INTO `lzh_member_payonline` VALUES ('63','39','alipay','1.00','0.00','alipay','1','1430099594','106.39.13.15','','','','admin','113','');/* DBReback Separation */
 /* 插入数据 `lzh_member_payonline` */
 INSERT INTO `lzh_member_payonline` VALUES ('64','39','alipay','1.00','0.00','alipay','1','1430099598','106.39.13.15','','','','admin','113','');/* DBReback Separation */ 
 /* 数据表结构 `lzh_member_remark`*/ 
 DROP TABLE IF EXISTS `lzh_member_remark`;/* DBReback Separation */ 
 CREATE TABLE `lzh_member_remark` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `user_id` int(11) NOT NULL,
  `user_name` varchar(50) NOT NULL,
  `remark` varchar(500) NOT NULL,
  `admin_id` int(11) NOT NULL,
  `admin_real_name` varchar(50) NOT NULL,
  `add_time` int(10) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;/* DBReback Separation */ 
 /* 数据表结构 `lzh_member_safequestion`*/ 
 DROP TABLE IF EXISTS `lzh_member_safequestion`;/* DBReback Separation */ 
 CREATE TABLE `lzh_member_safequestion` (
  `uid` int(10) unsigned NOT NULL,
  `question1` varchar(100) NOT NULL,
  `answer1` varchar(100) NOT NULL,
  `question2` varchar(100) NOT NULL,
  `answer2` varchar(100) NOT NULL,
  `add_time` int(11) NOT NULL,
  PRIMARY KEY (`uid`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;/* DBReback Separation */ 
 /* 数据表结构 `lzh_member_withdraw`*/ 
 DROP TABLE IF EXISTS `lzh_member_withdraw`;/* DBReback Separation */ 
 CREATE TABLE `lzh_member_withdraw` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `uid` int(10) unsigned NOT NULL,
  `withdraw_money` decimal(15,2) NOT NULL,
  `withdraw_status` tinyint(4) NOT NULL,
  `withdraw_fee` decimal(15,2) NOT NULL,
  `add_time` int(10) unsigned NOT NULL,
  `add_ip` varchar(16) NOT NULL,
  `deal_time` int(10) unsigned NOT NULL,
  `deal_user` varchar(50) NOT NULL,
  `deal_info` varchar(200) NOT NULL,
  `second_fee` decimal(15,2) NOT NULL COMMENT '修改后的提现手续费',
  `success_money` decimal(15,2) NOT NULL COMMENT '实际到账金额',
  PRIMARY KEY (`id`),
  KEY `uid` (`uid`,`withdraw_status`,`add_time`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;/* DBReback Separation */ 
 /* 数据表结构 `lzh_members`*/ 
 DROP TABLE IF EXISTS `lzh_members`;/* DBReback Separation */ 
 CREATE TABLE `lzh_members` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `user_name` varchar(50) NOT NULL,
  `user_pass` char(32) NOT NULL,
  `user_type` tinyint(3) unsigned NOT NULL DEFAULT '1',
  `pin_pass` char(32) NOT NULL,
  `user_email` varchar(50) NOT NULL,
  `user_phone` varchar(11) NOT NULL,
  `reg_time` int(10) unsigned NOT NULL,
  `reg_ip` varchar(15) NOT NULL,
  `user_leve` tinyint(4) NOT NULL DEFAULT '0',
  `time_limit` int(10) unsigned NOT NULL,
  `credits` int(10) NOT NULL,
  `recommend_id` int(10) unsigned NOT NULL DEFAULT '0',
  `customer_id` int(10) unsigned NOT NULL,
  `customer_name` varchar(20) NOT NULL,
  `province` int(10) unsigned NOT NULL,
  `city` int(10) unsigned NOT NULL,
  `area` int(10) unsigned NOT NULL,
  `is_ban` int(11) NOT NULL DEFAULT '0' COMMENT '是否冻结0：否； 1：是',
  `reward_money` decimal(15,2) NOT NULL COMMENT '奖金金额',
  `invest_credits` decimal(15,2) unsigned NOT NULL,
  `integral` int(15) NOT NULL COMMENT '会员总积分',
  `active_integral` int(15) NOT NULL COMMENT '会员活跃积分',
  `is_borrow` int(2) NOT NULL DEFAULT '1' COMMENT '是否允许会员发标。0：不允许；1：允许',
  `is_transfer` int(2) NOT NULL DEFAULT '0' COMMENT '是否是流转会员 0代表非流转会员，1代表是流转会员',
  `is_vip` tinyint(3) NOT NULL DEFAULT '0' COMMENT '是否开启特权发标，0：不开启；1：开启',
  `last_log_ip` char(15) NOT NULL,
  `last_log_time` int(10) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `user_email` (`user_email`),
  KEY `user_name` (`user_name`)
) ENGINE=InnoDB AUTO_INCREMENT=40 DEFAULT CHARSET=utf8;/* DBReback Separation */
 /* 插入数据 `lzh_members` */
 INSERT INTO `lzh_members` VALUES ('1','whttcy','de4f94fa98f56d12bb4c8eb67c5129e3','1','b79eb2b6d6de707baf9a76ee28b1670d','whttcy@163.com','13611012678','1429776333','124.205.215.55','0','0','100010','0','0','','0','0','0','0','0.00','0.00','0','0','1','1','1','124.205.215.55','1429776333');/* DBReback Separation */
 /* 插入数据 `lzh_members` */
 INSERT INTO `lzh_members` VALUES ('2','dongqiang','33d1d1475038a01f44b1529014a5f1d9','1','','690370941@qq.com','17701377782','1429778210','124.205.215.55','0','0','10','0','0','','0','0','0','0','0.00','0.00','0','0','1','0','0','124.205.215.55','1429793620');/* DBReback Separation */
 /* 插入数据 `lzh_members` */
 INSERT INTO `lzh_members` VALUES ('3','lize','941968115b9e290e9bd2f97c1b58886e','1','6dc2624c0eafcfda3399cd6eaad8e16e','325173966@qq.com','13693650065','1429778358','124.205.215.55','1','1461473160','40','0','113','admin','0','0','0','0','0.00','0.00','300','300','1','0','0','124.205.215.55','1429849764');/* DBReback Separation */
 /* 插入数据 `lzh_members` */
 INSERT INTO `lzh_members` VALUES ('4','wangyang','b1860dac1e44203372c22f24771b57d2','1','','wangyang@rongtianxia.com','18310312295','1429780244','124.205.215.55','1','1461462378','30','0','113','admin','0','0','0','0','0.00','0.00','0','0','1','0','0','124.205.215.55','1429785331');/* DBReback Separation */
 /* 插入数据 `lzh_members` */
 INSERT INTO `lzh_members` VALUES ('5','yanmin','670b14728ad9902aecba32e22fa4f6bd','1','d5982717e6e908b861d1beefe608f4e2','247286691@qq.com','13717798492','1429781403','124.205.215.55','0','0','20','4','0','','0','0','0','0','0.00','0.00','0','0','1','0','0','124.205.215.55','1429783123');/* DBReback Separation */
 /* 插入数据 `lzh_members` */
 INSERT INTO `lzh_members` VALUES ('6','whttcy1','71745de791a1031dd062969131faf25d','1','b79eb2b6d6de707baf9a76ee28b1670d','whttcy2008@126.com','18611771203','1429781897','124.205.215.55','0','0','10010','1','0','','0','0','0','0','0.00','0.00','1806','1806','1','1','1','124.205.215.55','1429781897');/* DBReback Separation */
 /* 插入数据 `lzh_members` */
 INSERT INTO `lzh_members` VALUES ('7','zsh123','b7469f313dee57339f9a1477cec3cf46','1','81f10ba4ee1fb4bfdc917c0a01040a6e','81510693@qq.com','15801156647','1429784022','124.205.215.55','0','0','10','0','0','','0','0','0','0','0.00','0.00','30','30','1','0','0','124.205.215.55','1429784022');/* DBReback Separation */
 /* 插入数据 `lzh_members` */
 INSERT INTO `lzh_members` VALUES ('8','shubiao','cf2fc01ba4e072ab58f81aabcd668fc7','1','18cc7e5d5d6bb3dbcbb661a8c359874b','1043858720@qq.com','18311050886','1429785886','124.205.215.55','0','0','10','0','0','','0','0','0','0','0.00','0.00','30','30','1','1','0','124.205.215.55','1429859280');/* DBReback Separation */
 /* 插入数据 `lzh_members` */
 INSERT INTO `lzh_members` VALUES ('9','田晓玉','e10adc3949ba59abbe56e057f20f883e','1','6c44e5cd17f0019c64b042e4a745412a','2880707529@qq.com','17701268060','1429844109','124.205.215.51','1','1461478100','40','0','113','admin','0','0','0','0','0.00','0.00','6','6','1','0','0','124.205.215.51','1429845768');/* DBReback Separation */
 /* 插入数据 `lzh_members` */
 INSERT INTO `lzh_members` VALUES ('10','小屌丝','0e09d6eb70f748cc0b639c328011a32b','1','db1aa3d14fed0c52007d58e2719caa21','752072276@qq.com','13552437955','1429844112','124.205.215.48','1','1461468211','40','0','113','admin','0','0','0','0','0.00','0.00','0','0','1','0','0','124.205.215.48','1429844923');/* DBReback Separation */
 /* 插入数据 `lzh_members` */
 INSERT INTO `lzh_members` VALUES ('11','dzsfo','025d68d1d9f66b18ce17a80e931241ad','1','','130066051@qq.com','13552893445','1429844444','124.205.215.51','0','0','10','0','0','','0','0','0','0','0.00','0.00','0','0','1','0','0','124.205.215.51','1429844444');/* DBReback Separation */
 /* 插入数据 `lzh_members` */
 INSERT INTO `lzh_members` VALUES ('12','mengqingmin','65a0ec385ca6a0c1e20d1f8270c28303','1','30926c80b3724a37df9a5f760eb509ec','1165728217@qq.com','15938751859','1429844463','124.205.215.51','0','0','20','0','0','','0','0','0','0','0.00','0.00','3','3','1','0','0','124.205.215.51','1429846477');/* DBReback Separation */
 /* 插入数据 `lzh_members` */
 INSERT INTO `lzh_members` VALUES ('13','chenguser','cc6ebeb7ffc92407025fde5860f1d4af','1','137699c4f3844e0d9c46dfb237b3731a','1362478848@qq.com','18810889714','1429844471','124.205.215.51','1','1461468189','40','0','113','admin','0','0','0','0','0.00','0.00','30','30','1','0','0','124.205.215.51','1429845102');/* DBReback Separation */
 /* 插入数据 `lzh_members` */
 INSERT INTO `lzh_members` VALUES ('14','songyu','77b57ef226df33eb844fe6f3ab837883','1','cff4508a1b20bdf8163acfa81a0760cb','2880707522@qq.com','17710242027','1429844541','124.205.215.48','1','1461468178','40','0','113','admin','0','0','0','0','0.00','0.00','150','150','1','0','0','124.205.215.48','1429844771');/* DBReback Separation */
 /* 插入数据 `lzh_members` */
 INSERT INTO `lzh_members` VALUES ('15','彭红','c5a01f2bfbbb45e2f81cf469ec47b00a','1','53580bb5216f0d4d59569c99d0a99662','1084341895@qq.com','15196917118','1429844585','117.62.134.55','1','1461468184','40','8','113','admin','0','0','0','0','0.00','0.00','60','60','1','0','0','117.62.134.55','1429845410');/* DBReback Separation */
 /* 插入数据 `lzh_members` */
 INSERT INTO `lzh_members` VALUES ('16','shouzhishouzhi','fc429dd72563b574f5d71e02adefa7d1','1','fc429dd72563b574f5d71e02adefa7d1','1048148517@qq.com','18511588087','1429844609','124.205.215.51','1','1461478092','20','0','113','admin','0','0','0','0','0.00','0.00','120','120','1','0','0','124.205.215.51','1429854686');/* DBReback Separation */
 /* 插入数据 `lzh_members` */
 INSERT INTO `lzh_members` VALUES ('17','xiaobai','62f26f60e2a6fc7408a04deaabd4d213','1','826fe79af6122a9bb98c3cbb0b3360d6','726061235@qq.com','13331131834','1429844642','124.205.215.48','1','1461467261','20','10','113','admin','0','0','0','0','0.00','0.00','0','0','1','0','0','124.205.215.48','1429844642');/* DBReback Separation */
 /* 插入数据 `lzh_members` */
 INSERT INTO `lzh_members` VALUES ('18','jdz_ios','3d974ac5453b7f66c9250778745524e5','1','b977919d0b69aa90468c3c8a62bcbafc','328870247@qq.com','18539659876','1429844754','124.205.215.51','0','0','0','0','0','','0','0','0','0','0.00','0.00','0','0','1','0','0','124.205.215.51','1429844754');/* DBReback Separation */
 /* 插入数据 `lzh_members` */
 INSERT INTO `lzh_members` VALUES ('19','zhengyu','96170fa2b37bfc731e38bfbfba7b83c0','1','4060505d0c58f66bf5743380be1ec242','412066051@qq.com','15300066405','1429844885','106.39.13.19','0','0','30','9','0','','0','0','0','0','0.00','0.00','15','15','1','0','0','106.39.13.19','1429844993');/* DBReback Separation */
 /* 插入数据 `lzh_members` */
 INSERT INTO `lzh_members` VALUES ('20','wanghui','d0c501c9bd32b5f83cd02c8787a2fadf','1','cb810b2da7ae289ade271e4bdfeb0faa','wangzheguilaihui@126.com','18701386300','1429845075','106.39.13.19','1','1461468202','10','0','113','admin','0','0','0','0','0.00','0.00','0','0','1','0','0','106.39.13.19','1429845075');/* DBReback Separation */
 /* 插入数据 `lzh_members` */
 INSERT INTO `lzh_members` VALUES ('21','chaoyong','95ae732049f171fc273a61ff3e2719fe','1','','183692160@qq.com','18717338021','1429845339','106.39.13.9','0','0','10','0','0','','0','0','0','0','0.00','0.00','0','0','1','0','0','106.39.13.9','1429845339');/* DBReback Separation */
 /* 插入数据 `lzh_members` */
 INSERT INTO `lzh_members` VALUES ('22','swm0415','d2475ebda6fb9d1ef0958baa981aa4ec','1','ea75764bd2db5278bcbe564375ded751','443067607@qq.com','15110088435','1429845351','117.62.134.55','1','1461468195','40','0','113','admin','0','0','0','0','0.00','0.00','150','150','1','0','0','117.62.134.55','1429845397');/* DBReback Separation */
 /* 插入数据 `lzh_members` */
 INSERT INTO `lzh_members` VALUES ('23','root','bc6a1493c017a83f603368c0fce7dc86','1','','675563543@qq.com','18515157554','1429845895','106.39.13.9','0','0','10','0','0','','0','0','0','0','0.00','0.00','0','0','1','0','0','106.39.13.9','1429845895');/* DBReback Separation */
 /* 插入数据 `lzh_members` */
 INSERT INTO `lzh_members` VALUES ('24','tiantian','3e4c2734ee64f73b3a0128d929b74f8f','1','1581eed567048e41b95498b9c43fb7f0','2880707521@qq.com','18500278044','1429846016','106.39.13.19','0','0','20','0','0','','0','0','0','0','0.00','0.00','15','15','1','0','0','106.39.13.19','1429846016');/* DBReback Separation */
 /* 插入数据 `lzh_members` */
 INSERT INTO `lzh_members` VALUES ('25','昊燃','44ac71a9e872d835c79f3a4d83c52301','1','','317785351@qq.com','15810123362','1429846128','106.39.13.19','0','0','10','10','0','','0','0','0','0','0.00','0.00','0','0','1','0','0','106.39.13.19','1429846128');/* DBReback Separation */
 /* 插入数据 `lzh_members` */
 INSERT INTO `lzh_members` VALUES ('26','1029131145','b1372222269e44e3a90321e90ba6f9a0','1','6583fff6ffee9b0e3fed695023160a71','1029131145@qq.com','15201618692','1429846510','106.39.13.9','0','0','20','0','0','','0','0','0','0','0.00','0.00','195','195','1','0','0','106.39.13.9','1429849981');/* DBReback Separation */
 /* 插入数据 `lzh_members` */
 INSERT INTO `lzh_members` VALUES ('27','cs415419597','385d410043ef35a0e87b4feb157b8556','1','6dcae2201a719a46111a22e16cc3828d','415419597@qq.com','13910683486','1429846579','106.39.13.9','0','0','0','0','0','','0','0','0','0','0.00','0.00','0','0','1','0','0','106.39.13.9','1429846579');/* DBReback Separation */
 /* 插入数据 `lzh_members` */
 INSERT INTO `lzh_members` VALUES ('28','请低下头','e26df757a03608ceaacc6dec16dd48c6','1','e10adc3949ba59abbe56e057f20f883e','980165003@qq.com','13269501238','1429847031','106.39.13.9','0','0','0','18','0','','0','0','0','0','0.00','0.00','0','0','1','0','0','106.39.13.9','1429847031');/* DBReback Separation */
 /* 插入数据 `lzh_members` */
 INSERT INTO `lzh_members` VALUES ('29','毛迪','a11a668be7d9ab89808b7486c26cc44f','1','','525671273@qq.com','13810830845','1429851917','106.39.13.19','0','0','10','0','0','','0','0','0','0','0.00','0.00','0','0','1','0','0','106.39.13.19','1429851917');/* DBReback Separation */
 /* 插入数据 `lzh_members` */
 INSERT INTO `lzh_members` VALUES ('30','yhl123','a1d2c8d0db5cc8ebcb436c1ae6190808','1','','15010120837@163.com','','1429853630','106.39.13.9','0','0','0','0','0','','0','0','0','0','0.00','0.00','0','0','1','0','0','106.39.13.9','1429853630');/* DBReback Separation */
 /* 插入数据 `lzh_members` */
 INSERT INTO `lzh_members` VALUES ('31','wanglincha','1f43a48d4c51dc871fe536dcc3d7c8b9','1','1f43a48d4c51dc871fe536dcc3d7c8b9','283994901@qq.com','13317341134','1429856643','106.39.13.9','0','0','20','0','0','','0','0','0','0','0.00','0.00','30','30','1','0','0','106.39.13.9','1429856660');/* DBReback Separation */
 /* 插入数据 `lzh_members` */
 INSERT INTO `lzh_members` VALUES ('32','648195165','bce4181dfae22c6f5370284fb0576355','1','d6016265c6e2c8863ba1de35e691e8eb','648195165@qq.com','18713510646','1429857400','106.39.13.9','0','0','10','0','0','','0','0','0','0','0.00','0.00','30','30','1','0','0','106.39.13.9','1429857400');/* DBReback Separation */
 /* 插入数据 `lzh_members` */
 INSERT INTO `lzh_members` VALUES ('33','咩咩','e2ea7e47f74626f6a7e338275af1a4ed','1','','a582040738@163.com','15836810328','1429857556','106.39.13.9','0','0','10','0','0','','0','0','0','0','0.00','0.00','0','0','1','0','0','106.39.13.9','1429857556');/* DBReback Separation */
 /* 插入数据 `lzh_members` */
 INSERT INTO `lzh_members` VALUES ('34','Xiao.Y','76764b5f24ef3d3c8e5db33ec6bd7c8d','1','981db83251f6ebb2c36e21f5d71b288f','928276155@qq.com','15010198635','1429859367','106.39.13.19','0','0','20','0','0','','0','0','0','0','0.00','0.00','30','30','1','0','0','106.39.13.19','1429860947');/* DBReback Separation */
 /* 插入数据 `lzh_members` */
 INSERT INTO `lzh_members` VALUES ('35','xiedong123x','18eb1992c34b8d0a58481ade67c477cd','1','','442578666@qq.com','15618509300','1429861629','106.39.13.9','0','0','0','0','0','','0','0','0','0','0.00','0.00','0','0','1','0','0','106.39.13.9','1429861629');/* DBReback Separation */
 /* 插入数据 `lzh_members` */
 INSERT INTO `lzh_members` VALUES ('36','athan','1dbb570a45304e147af0fa42382554fd','1','','athan@qq.com','13333333333','1429862091','106.39.13.9','0','0','0','0','0','','0','0','0','0','0.00','0.00','0','0','1','0','0','106.39.13.9','1429862091');/* DBReback Separation */
 /* 插入数据 `lzh_members` */
 INSERT INTO `lzh_members` VALUES ('37','jgj0911','8a6f2805b4515ac12058e79e66539be9','1','','jgj0911@126.com','15088696119','1429975566','183.158.92.110','0','0','10','0','0','','0','0','0','0','0.00','0.00','0','0','1','0','0','183.158.92.110','1429975566');/* DBReback Separation */
 /* 插入数据 `lzh_members` */
 INSERT INTO `lzh_members` VALUES ('38','qiuyong','e3ddcca405275ca69f596532396a3516','1','140f355ba624c9204b38b1821da4f454','1875707090@qq.com','15564052703','1430029214','182.38.128.146','0','0','10','0','0','','0','0','0','0','0.00','0.00','0','0','1','0','0','182.38.128.146','1430029214');/* DBReback Separation */
 /* 插入数据 `lzh_members` */
 INSERT INTO `lzh_members` VALUES ('39','崔永锋','a3c6103f425d72dda892cc5207fe899d','1','','hrcyf@163.com','13611134321','1430098347','106.39.13.15','0','0','10','0','0','','0','0','0','0','0.00','0.00','0','0','1','0','0','106.39.13.15','1430098347');/* DBReback Separation */ 
 /* 数据表结构 `lzh_members_status`*/ 
 DROP TABLE IF EXISTS `lzh_members_status`;/* DBReback Separation */ 
 CREATE TABLE `lzh_members_status` (
  `uid` int(10) unsigned NOT NULL,
  `phone_status` tinyint(3) unsigned NOT NULL DEFAULT '0',
  `phone_credits` int(10) unsigned NOT NULL DEFAULT '0',
  `id_status` tinyint(3) unsigned NOT NULL DEFAULT '0' COMMENT '0:未上传1:验证通过2:等待验证',
  `id_credits` int(10) unsigned NOT NULL DEFAULT '0',
  `face_status` tinyint(4) NOT NULL DEFAULT '0',
  `face_credits` int(10) unsigned NOT NULL DEFAULT '0',
  `email_status` tinyint(3) unsigned NOT NULL DEFAULT '0',
  `email_credits` int(10) unsigned NOT NULL DEFAULT '0',
  `account_status` tinyint(3) unsigned NOT NULL DEFAULT '0',
  `account_credits` int(10) unsigned NOT NULL DEFAULT '0',
  `credit_status` tinyint(4) NOT NULL DEFAULT '0',
  `credit_credits` int(10) unsigned NOT NULL DEFAULT '0',
  `safequestion_status` tinyint(3) unsigned NOT NULL DEFAULT '0',
  `safequestion_credits` int(10) unsigned NOT NULL DEFAULT '0',
  `video_status` tinyint(4) NOT NULL DEFAULT '0',
  `video_credits` int(10) unsigned NOT NULL DEFAULT '0',
  `vip_status` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `vip_credits` int(10) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`uid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;/* DBReback Separation */
 /* 插入数据 `lzh_members_status` */
 INSERT INTO `lzh_members_status` VALUES ('1','1','10','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0');/* DBReback Separation */
 /* 插入数据 `lzh_members_status` */
 INSERT INTO `lzh_members_status` VALUES ('2','1','10','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0');/* DBReback Separation */
 /* 插入数据 `lzh_members_status` */
 INSERT INTO `lzh_members_status` VALUES ('3','1','10','1','10','0','0','1','10','0','0','0','0','0','0','0','0','1','10');/* DBReback Separation */
 /* 插入数据 `lzh_members_status` */
 INSERT INTO `lzh_members_status` VALUES ('4','1','10','1','10','0','0','0','0','0','0','0','0','0','0','0','0','1','10');/* DBReback Separation */
 /* 插入数据 `lzh_members_status` */
 INSERT INTO `lzh_members_status` VALUES ('5','1','10','1','10','0','0','0','0','0','0','0','0','0','0','0','0','0','0');/* DBReback Separation */
 /* 插入数据 `lzh_members_status` */
 INSERT INTO `lzh_members_status` VALUES ('6','1','10','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0');/* DBReback Separation */
 /* 插入数据 `lzh_members_status` */
 INSERT INTO `lzh_members_status` VALUES ('7','1','10','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0');/* DBReback Separation */
 /* 插入数据 `lzh_members_status` */
 INSERT INTO `lzh_members_status` VALUES ('8','1','10','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0');/* DBReback Separation */
 /* 插入数据 `lzh_members_status` */
 INSERT INTO `lzh_members_status` VALUES ('9','1','10','1','10','0','0','1','10','0','0','0','0','0','0','0','0','1','10');/* DBReback Separation */
 /* 插入数据 `lzh_members_status` */
 INSERT INTO `lzh_members_status` VALUES ('10','1','10','1','10','0','0','1','10','0','0','0','0','0','0','0','0','1','10');/* DBReback Separation */
 /* 插入数据 `lzh_members_status` */
 INSERT INTO `lzh_members_status` VALUES ('11','1','10','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0');/* DBReback Separation */
 /* 插入数据 `lzh_members_status` */
 INSERT INTO `lzh_members_status` VALUES ('12','1','10','0','0','0','0','1','10','0','0','0','0','0','0','0','0','0','0');/* DBReback Separation */
 /* 插入数据 `lzh_members_status` */
 INSERT INTO `lzh_members_status` VALUES ('13','1','10','0','10','0','0','1','10','0','0','0','0','0','0','0','0','1','10');/* DBReback Separation */
 /* 插入数据 `lzh_members_status` */
 INSERT INTO `lzh_members_status` VALUES ('14','1','10','1','10','0','0','1','10','0','0','0','0','0','0','0','0','1','10');/* DBReback Separation */
 /* 插入数据 `lzh_members_status` */
 INSERT INTO `lzh_members_status` VALUES ('15','1','10','1','10','0','0','1','10','0','0','0','0','0','0','0','0','1','10');/* DBReback Separation */
 /* 插入数据 `lzh_members_status` */
 INSERT INTO `lzh_members_status` VALUES ('16','1','10','0','0','0','0','0','0','0','0','0','0','0','0','0','0','1','10');/* DBReback Separation */
 /* 插入数据 `lzh_members_status` */
 INSERT INTO `lzh_members_status` VALUES ('17','1','10','0','0','0','0','0','0','0','0','0','0','0','0','0','0','1','10');/* DBReback Separation */
 /* 插入数据 `lzh_members_status` */
 INSERT INTO `lzh_members_status` VALUES ('19','1','10','1','10','0','0','1','10','0','0','0','0','0','0','0','0','0','0');/* DBReback Separation */
 /* 插入数据 `lzh_members_status` */
 INSERT INTO `lzh_members_status` VALUES ('20','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','1','10');/* DBReback Separation */
 /* 插入数据 `lzh_members_status` */
 INSERT INTO `lzh_members_status` VALUES ('21','1','10','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0');/* DBReback Separation */
 /* 插入数据 `lzh_members_status` */
 INSERT INTO `lzh_members_status` VALUES ('22','1','10','1','10','0','0','1','10','0','0','0','0','0','0','0','0','1','10');/* DBReback Separation */
 /* 插入数据 `lzh_members_status` */
 INSERT INTO `lzh_members_status` VALUES ('23','1','10','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0');/* DBReback Separation */
 /* 插入数据 `lzh_members_status` */
 INSERT INTO `lzh_members_status` VALUES ('24','1','10','1','10','0','0','0','0','0','0','0','0','0','0','0','0','0','0');/* DBReback Separation */
 /* 插入数据 `lzh_members_status` */
 INSERT INTO `lzh_members_status` VALUES ('25','1','10','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0');/* DBReback Separation */
 /* 插入数据 `lzh_members_status` */
 INSERT INTO `lzh_members_status` VALUES ('26','1','10','3','0','0','0','1','10','0','0','0','0','0','0','0','0','0','0');/* DBReback Separation */
 /* 插入数据 `lzh_members_status` */
 INSERT INTO `lzh_members_status` VALUES ('29','1','10','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0');/* DBReback Separation */
 /* 插入数据 `lzh_members_status` */
 INSERT INTO `lzh_members_status` VALUES ('31','1','10','1','10','0','0','0','0','0','0','0','0','0','0','0','0','0','0');/* DBReback Separation */
 /* 插入数据 `lzh_members_status` */
 INSERT INTO `lzh_members_status` VALUES ('32','1','10','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0');/* DBReback Separation */
 /* 插入数据 `lzh_members_status` */
 INSERT INTO `lzh_members_status` VALUES ('33','1','10','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0');/* DBReback Separation */
 /* 插入数据 `lzh_members_status` */
 INSERT INTO `lzh_members_status` VALUES ('34','1','10','1','10','0','0','0','0','0','0','0','0','0','0','0','0','0','0');/* DBReback Separation */
 /* 插入数据 `lzh_members_status` */
 INSERT INTO `lzh_members_status` VALUES ('37','1','10','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0');/* DBReback Separation */
 /* 插入数据 `lzh_members_status` */
 INSERT INTO `lzh_members_status` VALUES ('38','1','10','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0');/* DBReback Separation */
 /* 插入数据 `lzh_members_status` */
 INSERT INTO `lzh_members_status` VALUES ('39','1','10','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0');/* DBReback Separation */ 
 /* 数据表结构 `lzh_name_apply`*/ 
 DROP TABLE IF EXISTS `lzh_name_apply`;/* DBReback Separation */ 
 CREATE TABLE `lzh_name_apply` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `uid` int(10) unsigned NOT NULL,
  `up_time` int(10) NOT NULL,
  `status` tinyint(3) unsigned NOT NULL,
  `idcard` varchar(20) NOT NULL,
  `deal_info` varchar(80) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=19 DEFAULT CHARSET=utf8;/* DBReback Separation */
 /* 插入数据 `lzh_name_apply` */
 INSERT INTO `lzh_name_apply` VALUES ('1','1','1429778071','0','37292919801101391X','');/* DBReback Separation */
 /* 插入数据 `lzh_name_apply` */
 INSERT INTO `lzh_name_apply` VALUES ('2','3','1429779071','1','52020219870611247X','');/* DBReback Separation */
 /* 插入数据 `lzh_name_apply` */
 INSERT INTO `lzh_name_apply` VALUES ('3','4','1429781161','1','130429199203224616','');/* DBReback Separation */
 /* 插入数据 `lzh_name_apply` */
 INSERT INTO `lzh_name_apply` VALUES ('4','5','1429781843','1','420922199112146044','');/* DBReback Separation */
 /* 插入数据 `lzh_name_apply` */
 INSERT INTO `lzh_name_apply` VALUES ('5','14','1429845982','1','230203199108091826','');/* DBReback Separation */
 /* 插入数据 `lzh_name_apply` */
 INSERT INTO `lzh_name_apply` VALUES ('6','13','1429845340','1','13072819951025003X','');/* DBReback Separation */
 /* 插入数据 `lzh_name_apply` */
 INSERT INTO `lzh_name_apply` VALUES ('7','15','1429845346','1','510922199304264362','');/* DBReback Separation */
 /* 插入数据 `lzh_name_apply` */
 INSERT INTO `lzh_name_apply` VALUES ('8','22','1429845721','1','520112199204150013','');/* DBReback Separation */
 /* 插入数据 `lzh_name_apply` */
 INSERT INTO `lzh_name_apply` VALUES ('9','10','1429846103','1','130724199306282813','');/* DBReback Separation */
 /* 插入数据 `lzh_name_apply` */
 INSERT INTO `lzh_name_apply` VALUES ('10','24','1429846347','1','130732199508172364','');/* DBReback Separation */
 /* 插入数据 `lzh_name_apply` */
 INSERT INTO `lzh_name_apply` VALUES ('11','12','1429846658','0','41138119900605453X','');/* DBReback Separation */
 /* 插入数据 `lzh_name_apply` */
 INSERT INTO `lzh_name_apply` VALUES ('12','18','1429846720','0','411527199309042512','');/* DBReback Separation */
 /* 插入数据 `lzh_name_apply` */
 INSERT INTO `lzh_name_apply` VALUES ('13','9','1429851075','1','142303199110132645','');/* DBReback Separation */
 /* 插入数据 `lzh_name_apply` */
 INSERT INTO `lzh_name_apply` VALUES ('14','19','1429856046','1','142621199502112247','');/* DBReback Separation */
 /* 插入数据 `lzh_name_apply` */
 INSERT INTO `lzh_name_apply` VALUES ('15','31','1429856768','1','430406198906171014','');/* DBReback Separation */
 /* 插入数据 `lzh_name_apply` */
 INSERT INTO `lzh_name_apply` VALUES ('16','8','1429859310','0','412723198911221224','');/* DBReback Separation */
 /* 插入数据 `lzh_name_apply` */
 INSERT INTO `lzh_name_apply` VALUES ('17','34','1429860699','1','130727198810253725','');/* DBReback Separation */
 /* 插入数据 `lzh_name_apply` */
 INSERT INTO `lzh_name_apply` VALUES ('18','26','1429864775','0','420921199609243839','');/* DBReback Separation */ 
 /* 数据表结构 `lzh_navigation`*/ 
 DROP TABLE IF EXISTS `lzh_navigation`;/* DBReback Separation */ 
 CREATE TABLE `lzh_navigation` (
  `id` smallint(6) NOT NULL AUTO_INCREMENT,
  `type_name` varchar(40) NOT NULL,
  `type_url` varchar(200) NOT NULL,
  `type_keyword` varchar(200) NOT NULL,
  `type_info` varchar(400) NOT NULL,
  `type_content` text NOT NULL,
  `sort_order` int(11) NOT NULL,
  `type_set` tinyint(1) NOT NULL DEFAULT '0',
  `parent_id` smallint(6) NOT NULL,
  `type_nid` varchar(50) NOT NULL,
  `is_hiden` int(1) unsigned NOT NULL DEFAULT '0',
  `add_time` int(10) unsigned NOT NULL,
  `is_sys` tinyint(3) unsigned NOT NULL,
  `model` char(30) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=65 DEFAULT CHARSET=utf8;/* DBReback Separation */
 /* 插入数据 `lzh_navigation` */
 INSERT INTO `lzh_navigation` VALUES ('1','首页','/','','','','12','2','0','indexs','0','1386156845','0','navigation');/* DBReback Separation */
 /* 插入数据 `lzh_navigation` */
 INSERT INTO `lzh_navigation` VALUES ('2','借款理财','/invest/index.html','','','','9','2','0','invests','1','1386156886','0','navigation');/* DBReback Separation */
 /* 插入数据 `lzh_navigation` */
 INSERT INTO `lzh_navigation` VALUES ('3','谁与争锋','','','','','8','2','0','borrows','1','1386156927','0','navigation');/* DBReback Separation */
 /* 插入数据 `lzh_navigation` */
 INSERT INTO `lzh_navigation` VALUES ('5','积分商城','/market/index/','','','','6','2','0','market','1','1386157007','0','navigation');/* DBReback Separation */
 /* 插入数据 `lzh_navigation` */
 INSERT INTO `lzh_navigation` VALUES ('7','关于我们','/aboutus/jianjie.html','','','<div><img style=\"margin:10px;width:360px;float:right;height:256px;\" alt=\"\" src=\"/UF/Uploads/Article/20131125183424.gif\" /> 　　XXX网站隶属于XXXXXX管理有限公司。XXXXXX经工商局登记注册于2013年成立，注册资本1000万。位于XXXXXXXXXXXXXXXXXXXXXXXXX。是目前XX地区最安全、最专业的网络信贷理财平台之一</div><div>XXXX顺应全球电子商务未来发展的趋势，充分挖掘互联网金融市场潜力，通过建立一个安全、高效、诚信、互惠互助的网络借贷平台，让人们有机会相互帮助实现双赢的结果，帮助投资者及创业者更好地应对目前世界金融危机影响下的经济困境。</div><div>我们深信，依赖现代网络创新技术将民间借贷引入的模式，定会在快捷、便利、透明的体系下得到更健康的发展，并实现利益最大化！</div><div>XXXXX严格遵守国家相关法律法规，并敦促其会员在信息发布和使用过程中严格遵守相关法规。同时，我们也将竭尽所能，不断完善对网站平台的管理！</div><div>让我们携起手来，愿您的财富同xxxx一起成长！</div><div>愿您的创业梦想，在盛世下飞翔！</div><div>&nbsp;</div><div><div><strong><span style=\"font-size:24px;\">P2P平台介绍</span></strong></div><div>XXXXX采用创新的技术和理念，通过互联网建立一个安全、高效、诚信的平台，规范了个人之间的借贷行为，使之更加安全、有效。让人们有机会得到帮助，以及帮助到需要的朋友，同时得到更好的回报。</div><div>现实中朋友家人之间往往由于面子等问题不方便借款以及不好意思催款。XXXXX鼓励大家通过这一平台来帮助解决这些问题。另外，如果朋友家人正好没有钱帮您，而朋友的朋友很可能有闲钱，大家通过人人聚财这个平台就可传递这种信赖关系,扩大信赖的朋友圈子，解决自己的问题。</div><div>通过下面图片可以了解XXXXX如何工作的：需要钱的人发布信息，其他人以竞标方式参与，聚合大众的力量，以市场化的方式决定利率，以及监督借款行为。</div><div style=\"text-align:center;\">&nbsp;<img style=\"margin:0px;float:none;\" alt=\"\" src=\"/UF/Uploads/Article/20131125182918.gif\" /></div><div><strong><span style=\"font-size:24px;\">平成立目的台</span></strong></div><div>为有需要帮助的人伸出援手！为有能力的人实现资产增值！让我们成为成功路上最好的伙伴！&nbsp;</div><div>&nbsp;</div><div><strong><span style=\"font-size:24px;\">愿景</span></strong></div><div>打造一个全民参与、安全、高效、诚信、互惠互利的互联网金融服务平台</div><div>&nbsp;</div></div>','4','2','0','about','0','1386157108','0','navigation');/* DBReback Separation */
 /* 插入数据 `lzh_navigation` */
 INSERT INTO `lzh_navigation` VALUES ('9','快速配资','/daystock/index','','','','10','2','0','members','0','1386157201','0','navigation');/* DBReback Separation */
 /* 插入数据 `lzh_navigation` */
 INSERT INTO `lzh_navigation` VALUES ('18','企业直投','/tinvest/index.html','','','','8','2','2','tinvest ','1','1386212356','0','navigation');/* DBReback Separation */
 /* 插入数据 `lzh_navigation` */
 INSERT INTO `lzh_navigation` VALUES ('19','我要理财','/invest/index.html','','','','10','2','62','borrowing','0','1386212416','0','navigation');/* DBReback Separation */
 /* 插入数据 `lzh_navigation` */
 INSERT INTO `lzh_navigation` VALUES ('46','公司证件','/aboutus/zizhi.html','','','','5','2','7','','1','1399189538','0','navigation');/* DBReback Separation */
 /* 插入数据 `lzh_navigation` */
 INSERT INTO `lzh_navigation` VALUES ('45','财融天下','/aboutus/jianjie.html','','','','10','2','7','','0','1399189491','0','navigation');/* DBReback Separation */
 /* 插入数据 `lzh_navigation` */
 INSERT INTO `lzh_navigation` VALUES ('41','债权转让','/debt/index','','','','8','2','62','debt','0','1389583429','0','navigation');/* DBReback Separation */
 /* 插入数据 `lzh_navigation` */
 INSERT INTO `lzh_navigation` VALUES ('42','积分抽奖','/market/lottery/','','','','1','2','5','choujiang','0','1389956064','0','navigation');/* DBReback Separation */
 /* 插入数据 `lzh_navigation` */
 INSERT INTO `lzh_navigation` VALUES ('43','积分兑换','/market/index/','','','','2','2','5','exchange','0','1389956169','0','navigation');/* DBReback Separation */
 /* 插入数据 `lzh_navigation` */
 INSERT INTO `lzh_navigation` VALUES ('49','金融合作','/Enterprise/index','','','','0','2','0','','1','1403329268','0','navigation');/* DBReback Separation */
 /* 插入数据 `lzh_navigation` */
 INSERT INTO `lzh_navigation` VALUES ('50','企业融资','/rongzi/index','','','','1','2','0','','1','1407118197','0','navigation');/* DBReback Separation */
 /* 插入数据 `lzh_navigation` */
 INSERT INTO `lzh_navigation` VALUES ('51','天天盈','/daystock/index','','','','3','2','9','','0','1427710660','0','navigation');/* DBReback Separation */
 /* 插入数据 `lzh_navigation` */
 INSERT INTO `lzh_navigation` VALUES ('52','月月盈','/Monthstock/index','','','','2','2','9','','0','1427710685','0','navigation');/* DBReback Separation */
 /* 插入数据 `lzh_navigation` */
 INSERT INTO `lzh_navigation` VALUES ('53','我是操盘手','/Imtrader/index','','','','1','2','9','','0','1427710752','0','navigation');/* DBReback Separation */
 /* 插入数据 `lzh_navigation` */
 INSERT INTO `lzh_navigation` VALUES ('54','免费体验','/freestock/index','','','','11','2','0','','0','1427791507','0','navigation');/* DBReback Separation */
 /* 插入数据 `lzh_navigation` */
 INSERT INTO `lzh_navigation` VALUES ('55','我要借款','/borrow/loan','','','','0','2','2','','1','1427791638','0','navigation');/* DBReback Separation */
 /* 插入数据 `lzh_navigation` */
 INSERT INTO `lzh_navigation` VALUES ('56','我要推广','/help/invite','','','','7','2','0','','1','1427791696','0','navigation');/* DBReback Separation */
 /* 插入数据 `lzh_navigation` */
 INSERT INTO `lzh_navigation` VALUES ('57','联系我们','/aboutus/lianxi.html','','','','0','2','7','','0','1428032181','0','navigation');/* DBReback Separation */
 /* 插入数据 `lzh_navigation` */
 INSERT INTO `lzh_navigation` VALUES ('58','安全保障','/aboutus/anquan.html','','','','9','2','7','','0','1428373804','0','navigation');/* DBReback Separation */
 /* 插入数据 `lzh_navigation` */
 INSERT INTO `lzh_navigation` VALUES ('61','活期理财','/current/index','','','','10','2','2','','1','1428405757','0','navigation');/* DBReback Separation */
 /* 插入数据 `lzh_navigation` */
 INSERT INTO `lzh_navigation` VALUES ('62','快速赚钱','/invest/index.html','','','','9','2','0','','0','1429669549','0','navigation');/* DBReback Separation */
 /* 插入数据 `lzh_navigation` */
 INSERT INTO `lzh_navigation` VALUES ('63','配资学院','','','','','7','2','0','','1','1429670977','0','navigation');/* DBReback Separation */
 /* 插入数据 `lzh_navigation` */
 INSERT INTO `lzh_navigation` VALUES ('64','股票加油站','/bbs','','','','6','2','0','','0','1429671318','0','navigation');/* DBReback Separation */ 
 /* 数据表结构 `lzh_oauth`*/ 
 DROP TABLE IF EXISTS `lzh_oauth`;/* DBReback Separation */ 
 CREATE TABLE `lzh_oauth` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `is_bind` tinyint(30) NOT NULL DEFAULT '0',
  `site` varchar(30) NOT NULL DEFAULT '',
  `openid` varchar(255) NOT NULL DEFAULT '',
  `nickname` varchar(255) NOT NULL DEFAULT '',
  `avatar` varchar(255) NOT NULL DEFAULT '',
  `url` varchar(255) NOT NULL DEFAULT '',
  `logintimes` int(10) unsigned NOT NULL DEFAULT '0',
  `logintime` int(10) unsigned NOT NULL DEFAULT '0',
  `bind_uid` int(10) NOT NULL DEFAULT '0',
  `addtime` int(10) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `site` (`site`,`openid`),
  KEY `uname` (`is_bind`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;/* DBReback Separation */ 
 /* 数据表结构 `lzh_payment_log`*/ 
 DROP TABLE IF EXISTS `lzh_payment_log`;/* DBReback Separation */ 
 CREATE TABLE `lzh_payment_log` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `title` varchar(50) NOT NULL,
  `content` varchar(200) NOT NULL,
  `money` decimal(15,2) NOT NULL DEFAULT '0.00',
  `auser_id` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;/* DBReback Separation */ 
 /* 数据表结构 `lzh_qq`*/ 
 DROP TABLE IF EXISTS `lzh_qq`;/* DBReback Separation */ 
 CREATE TABLE `lzh_qq` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `qq_num` varchar(50) NOT NULL,
  `qq_title` varchar(100) NOT NULL,
  `qq_order` int(2) NOT NULL,
  `is_show` int(1) NOT NULL DEFAULT '1',
  `type` int(1) NOT NULL COMMENT '0：qq号；1：qq群；2：客服电话',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;/* DBReback Separation */ 
 /* 数据表结构 `lzh_rongzi`*/ 
 DROP TABLE IF EXISTS `lzh_rongzi`;/* DBReback Separation */ 
 CREATE TABLE `lzh_rongzi` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `qiyename` varchar(100) NOT NULL COMMENT '企业名称',
  `zhucehao` varchar(60) NOT NULL COMMENT '注册号',
  `faren` varchar(30) NOT NULL COMMENT '法人/负责人',
  `shenfenzheng` varchar(30) NOT NULL COMMENT '身份证号',
  `phone` varchar(30) NOT NULL COMMENT '联系电话',
  `city` varchar(50) NOT NULL COMMENT '所在城市',
  `jine` decimal(15,2) NOT NULL COMMENT '借款金额',
  `zhouqi` varchar(10) NOT NULL COMMENT '结款周期',
  `yongtu` varchar(300) NOT NULL COMMENT '借款用途',
  `huankuanlaiyuan` varchar(200) NOT NULL COMMENT '还款来源',
  `ip` varchar(16) NOT NULL,
  `add_time` int(10) NOT NULL,
  `is_read` int(2) NOT NULL COMMENT '是否已查看',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8;/* DBReback Separation */
 /* 插入数据 `lzh_rongzi` */
 INSERT INTO `lzh_rongzi` VALUES ('2','企业名称','注册号','法人','3333333333','0530-555555','城市','50000.00','12','借款用途','还款来源','127.0.0.1','1390712710','1');/* DBReback Separation */ 
 /* 数据表结构 `lzh_shares_additional`*/ 
 DROP TABLE IF EXISTS `lzh_shares_additional`;/* DBReback Separation */ 
 CREATE TABLE `lzh_shares_additional` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `principal` decimal(10,2) NOT NULL COMMENT '追加本金',
  `shares_money` decimal(10,2) NOT NULL COMMENT '追加配资金额',
  `manage_rate` float NOT NULL COMMENT '管理费比率',
  `manage_fee` decimal(10,2) NOT NULL COMMENT '管理费',
  `shares_id` int(11) NOT NULL COMMENT '配资id',
  `add_time` int(11) NOT NULL COMMENT '添加时间',
  `status` tinyint(1) NOT NULL COMMENT '状态 1待审核 2审核通过 3审核未通过',
  `u_name` varchar(50) DEFAULT NULL COMMENT '用户名',
  `order` varchar(50) DEFAULT NULL COMMENT '配资订单号',
  `duration` int(11) DEFAULT NULL COMMENT '当前管理费使用期限',
  `examine_time` int(11) DEFAULT NULL COMMENT '审核时间',
  `open_ratio` decimal(15,2) DEFAULT NULL COMMENT '平仓线',
  `alert_ratio` decimal(15,2) DEFAULT NULL COMMENT '警戒线',
  `new_interest` decimal(15,2) DEFAULT NULL COMMENT '现所选一天管理费',
  `y_interest` decimal(15,2) DEFAULT NULL COMMENT '原本一天管理费',
  `yy_day` int(11) DEFAULT NULL COMMENT '已用天数',
  `sy_day` int(11) DEFAULT NULL COMMENT '剩余天数',
  `type_id` tinyint(1) DEFAULT NULL,
  `is_additional` tinyint(1) DEFAULT NULL,
  `info` varchar(200) DEFAULT NULL COMMENT '审核说明',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;/* DBReback Separation */ 
 /* 数据表结构 `lzh_shares_apply`*/ 
 DROP TABLE IF EXISTS `lzh_shares_apply`;/* DBReback Separation */ 
 CREATE TABLE `lzh_shares_apply` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `uid` int(11) NOT NULL COMMENT '申请人uid',
  `principal` decimal(10,2) NOT NULL COMMENT '本金',
  `manage_fee` decimal(10,2) NOT NULL COMMENT '管理费',
  `type_id` int(11) NOT NULL COMMENT '类型id',
  `lever_id` int(11) NOT NULL COMMENT '杠杆id',
  `shares_money` decimal(10,2) NOT NULL COMMENT '所获配资金额',
  `order` varchar(50) NOT NULL COMMENT '订单号',
  `open` decimal(10,2) NOT NULL COMMENT '平仓线',
  `alert` decimal(10,2) NOT NULL COMMENT '警戒线',
  `lever_ratio` int(11) NOT NULL COMMENT '杠杆比率',
  `manage_rate` float NOT NULL COMMENT '管理费比率',
  `open_ratio` float NOT NULL COMMENT '平仓线比率',
  `alert_ratio` float NOT NULL COMMENT '警戒线比率',
  `surplus_money` decimal(10,2) DEFAULT NULL COMMENT '回收剩余金额',
  `add_time` int(11) NOT NULL COMMENT '添加时间',
  `ip_address` varchar(50) NOT NULL COMMENT 'IP地址',
  `status` tinyint(1) NOT NULL COMMENT '状态:1待审核 2审核通过进行中 3回收完成 4审核未通过 5审核通过待发送homs账号密码',
  `recovery_time` int(11) NOT NULL COMMENT '回收时间',
  `already_manage_fee` decimal(10,2) NOT NULL COMMENT '已支出管理费',
  `trading_time` tinyint(1) NOT NULL COMMENT '交易开始时间 :1今天 2下个交易日',
  `duration` int(3) NOT NULL COMMENT '使用期限',
  `client_user` varchar(30) DEFAULT NULL COMMENT '客户端帐号',
  `client_pass` varchar(100) DEFAULT NULL COMMENT '客户端密码',
  `total_money` decimal(10,2) NOT NULL COMMENT '总金额',
  `examine_time` int(11) DEFAULT NULL COMMENT '审核时间',
  `deduction_time` int(11) DEFAULT NULL COMMENT '上次扣款时间',
  `endtime` int(11) DEFAULT NULL COMMENT '结束时间',
  `u_name` varchar(50) DEFAULT NULL COMMENT '用户名',
  `is_want_open` tinyint(1) NOT NULL DEFAULT '0',
  `one_manage_fee` decimal(10,0) DEFAULT NULL COMMENT '单次管理费',
  `info` varchar(200) DEFAULT NULL COMMENT '审核说明',
  `stock_admin_id` int(11) DEFAULT NULL,
  `want_open_time` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=28 DEFAULT CHARSET=utf8 COMMENT='股权配资申请表';/* DBReback Separation */
 /* 插入数据 `lzh_shares_apply` */
 INSERT INTO `lzh_shares_apply` VALUES ('1','1','1.00','0.00','4','0','2000.00','FPZ8971429782950','0.00','0.00','0','0','0','0','','1429782950','124.205.215.55','2','1429782950','0.00','1','2','25036020','123456','2001.00','1429841187','','1429891200','whttcy','0','','','','');/* DBReback Separation */
 /* 插入数据 `lzh_shares_apply` */
 INSERT INTO `lzh_shares_apply` VALUES ('2','1','1000.00','2.40','1','0','1000.00','PZT_1429783028118','1300.00','1400.00','1','1.2','30','40','0.00','1429783028','124.205.215.55','4','0','0.00','1','2','','','2000.00','','','345600','whttcy','0','1','审核不通过','','');/* DBReback Separation */
 /* 插入数据 `lzh_shares_apply` */
 INSERT INTO `lzh_shares_apply` VALUES ('3','5','1.00','0.00','4','0','2000.00','FPZ4201429786754','0.00','0.00','0','0','0','0','','1429786754','124.205.215.55','2','1429786754','0.00','1','2','25036007','123456','2001.00','1429852438','','1429891200','yanmin','0','','','','');/* DBReback Separation */
 /* 插入数据 `lzh_shares_apply` */
 INSERT INTO `lzh_shares_apply` VALUES ('4','4','1.00','0.00','4','0','2000.00','FPZ7531429837705','0.00','0.00','0','0','0','0','','1429837705','124.205.215.51','2','1429837705','0.00','1','2','25036008','123456','2001.00','1429852359','','1429891200','wangyang','0','','','','');/* DBReback Separation */
 /* 插入数据 `lzh_shares_apply` */
 INSERT INTO `lzh_shares_apply` VALUES ('5','13','1.00','0.00','4','0','2000.00','FPZ6871429845906','0.00','0.00','0','0','0','0','','1429845906','106.39.13.9','2','1429845906','0.00','1','2','25036012','123456','2001.00','1429852106','','1429891200','chenguser','0','','','','');/* DBReback Separation */
 /* 插入数据 `lzh_shares_apply` */
 INSERT INTO `lzh_shares_apply` VALUES ('6','11','1.00','0.00','4','0','2000.00','FPZ6981429846479','0.00','0.00','0','0','0','0','','1429846479','106.39.13.9','2','1429846479','0.00','1','2','25036019','123456','2001.00','1429846616','','1429891200','dzsfo','0','','','','');/* DBReback Separation */
 /* 插入数据 `lzh_shares_apply` */
 INSERT INTO `lzh_shares_apply` VALUES ('7','2','1.00','0.00','4','0','2000.00','FPZ5701429846494','0.00','0.00','0','0','0','0','','1429846494','106.39.13.9','2','1429846494','0.00','1','2','25036018','123456','2001.00','1429846870','','1429891200','dongqiang','0','','','','');/* DBReback Separation */
 /* 插入数据 `lzh_shares_apply` */
 INSERT INTO `lzh_shares_apply` VALUES ('8','16','1.00','0.00','4','0','2000.00','FPZ3881429846748','0.00','0.00','0','0','0','0','','1429846748','106.39.13.9','2','1429846748','0.00','1','2','25036009','123456','2001.00','1429852351','','1429891200','shouzhishouzhi','0','','','','');/* DBReback Separation */
 /* 插入数据 `lzh_shares_apply` */
 INSERT INTO `lzh_shares_apply` VALUES ('9','18','1.00','0.00','4','0','2000.00','FPZ4471429846950','0.00','0.00','0','0','0','0','','1429846950','106.39.13.9','2','1429846950','0.00','1','2','25036013','123456','2001.00','1429852098','','1429891200','jdz_ios','0','','','','');/* DBReback Separation */
 /* 插入数据 `lzh_shares_apply` */
 INSERT INTO `lzh_shares_apply` VALUES ('10','12','1.00','0.00','4','0','2000.00','FPZ7931429846978','0.00','0.00','0','0','0','0','','1429846978','106.39.13.9','2','1429846978','0.00','1','2','25036014','123456','2001.00','1429852067','','1429891200','mengqingmin','0','','','','');/* DBReback Separation */
 /* 插入数据 `lzh_shares_apply` */
 INSERT INTO `lzh_shares_apply` VALUES ('11','26','1.00','0.00','4','0','2000.00','FPZ2471429849895','0.00','0.00','0','0','0','0','','1429849895','106.39.13.9','2','1429849895','0.00','1','2','25036015','123456','2001.00','1429852060','','1429891200','1029131145','0','','','','');/* DBReback Separation */
 /* 插入数据 `lzh_shares_apply` */
 INSERT INTO `lzh_shares_apply` VALUES ('12','21','1.00','0.00','4','0','2000.00','FPZ281429850238','0.00','0.00','0','0','0','0','','1429850238','106.39.13.9','2','1429850238','0.00','1','2','25036016','123456','2001.00','1429852051','','1429891200','chaoyong','0','','','','');/* DBReback Separation */
 /* 插入数据 `lzh_shares_apply` */
 INSERT INTO `lzh_shares_apply` VALUES ('13','3','1.00','0.00','4','0','2000.00','FPZ3371429851659','0.00','0.00','0','0','0','0','','1429851659','106.39.13.19','2','1429851659','0.00','1','2','25036017','123456','2001.00','1429852004','','1429891200','lize','0','','','','');/* DBReback Separation */
 /* 插入数据 `lzh_shares_apply` */
 INSERT INTO `lzh_shares_apply` VALUES ('14','15','1.00','0.00','4','0','2000.00','FPZ9641429852090','0.00','0.00','0','0','0','0','','1429852090','117.62.134.55','2','1429852090','0.00','1','2','25036011','123456','2001.00','1429852171','','1429891200','彭红','0','','','','');/* DBReback Separation */
 /* 插入数据 `lzh_shares_apply` */
 INSERT INTO `lzh_shares_apply` VALUES ('15','28','1.00','0.00','4','0','2000.00','FPZ2741429852150','0.00','0.00','0','0','0','0','','1429852150','106.39.13.9','2','1429852150','0.00','1','2','25036010','123456','2001.00','1429852318','','1429891200','请低下头','0','','','','');/* DBReback Separation */
 /* 插入数据 `lzh_shares_apply` */
 INSERT INTO `lzh_shares_apply` VALUES ('16','22','1.00','0.00','4','0','2000.00','FPZ2051429852541','0.00','0.00','0','0','0','0','','1429852541','117.62.134.55','2','1429852541','0.00','1','2','25036005','123456','2001.00','1429853986','','1429891200','swm0415','0','','','','');/* DBReback Separation */
 /* 插入数据 `lzh_shares_apply` */
 INSERT INTO `lzh_shares_apply` VALUES ('17','14','1.00','0.00','4','0','2000.00','FPZ2521429852772','0.00','0.00','0','0','0','0','','1429852772','106.39.13.19','2','1429852772','0.00','1','2','25036006','123456','2001.00','1429853180','','1429891200','songyu','0','','','','');/* DBReback Separation */
 /* 插入数据 `lzh_shares_apply` */
 INSERT INTO `lzh_shares_apply` VALUES ('18','9','1.00','0.00','4','0','2000.00','FPZ8791429852795','0.00','0.00','0','0','0','0','','1429852795','106.39.13.9','2','1429852795','0.00','1','2','25036004','123456','2001.00','1429854013','','1429891200','田晓玉','0','','','','');/* DBReback Separation */
 /* 插入数据 `lzh_shares_apply` */
 INSERT INTO `lzh_shares_apply` VALUES ('19','24','1.00','0.00','4','0','2000.00','FPZ1221429853314','0.00','0.00','0','0','0','0','','1429853314','106.39.13.19','2','1429853314','0.00','1','2','25036003','123456','2001.00','1429854017','','1429891200','tiantian','0','','','','');/* DBReback Separation */
 /* 插入数据 `lzh_shares_apply` */
 INSERT INTO `lzh_shares_apply` VALUES ('20','10','1.00','0.00','4','0','2000.00','FPZ9081429853629','0.00','0.00','0','0','0','0','','1429853629','106.39.13.19','2','1429853629','0.00','1','2','25036002','123456','2001.00','1429854033','','1429891200','小屌丝','0','','','','');/* DBReback Separation */
 /* 插入数据 `lzh_shares_apply` */
 INSERT INTO `lzh_shares_apply` VALUES ('21','31','1.00','0.00','4','0','2000.00','FPZ6131429857219','0.00','0.00','0','0','0','0','','1429857219','106.39.13.9','2','1429857219','0.00','1','2','25036001','123456','2001.00','1429857886','','1429891200','wanglincha','0','','','','');/* DBReback Separation */
 /* 插入数据 `lzh_shares_apply` */
 INSERT INTO `lzh_shares_apply` VALUES ('22','33','1.00','0.00','4','0','2000.00','FPZ2411429857835','0.00','0.00','0','0','0','0','','1429857835','106.39.13.9','1','1429857835','0.00','1','2','','','2001.00','','','','咩咩','0','','','','');/* DBReback Separation */
 /* 插入数据 `lzh_shares_apply` */
 INSERT INTO `lzh_shares_apply` VALUES ('23','32','1.00','0.00','4','0','2000.00','FPZ8741429859122','0.00','0.00','0','0','0','0','','1429859122','106.39.13.9','1','1429859122','0.00','1','2','','','2001.00','','','','648195165','0','','','','');/* DBReback Separation */
 /* 插入数据 `lzh_shares_apply` */
 INSERT INTO `lzh_shares_apply` VALUES ('24','31','0.00','0.00','1','0','0.00','PZT_1429863468392','0.00','0.00','10','1.2','30','40','0.00','1429863468','106.39.13.9','4','0','0.00','1','30','','','0.00','','','3628800','wanglincha','0','0','','','');/* DBReback Separation */
 /* 插入数据 `lzh_shares_apply` */
 INSERT INTO `lzh_shares_apply` VALUES ('25','11','0.00','0.00','1','0','0.00','PZT_1429864161168','0.00','0.00','1','1.2','30','40','0.00','1429864161','106.39.13.9','4','0','0.00','1','2','','','0.00','','','345600','dzsfo','0','0','','','');/* DBReback Separation */
 /* 插入数据 `lzh_shares_apply` */
 INSERT INTO `lzh_shares_apply` VALUES ('26','39','1.00','0.00','4','0','2000.00','FPZ5021430099771','0.00','0.00','0','0','0','0','','1430099771','106.39.13.15','2','1430099771','0.00','1','2','25036030','123456','2001.00','1430100164','','1430150400','崔永锋','0','','','','');/* DBReback Separation */
 /* 插入数据 `lzh_shares_apply` */
 INSERT INTO `lzh_shares_apply` VALUES ('27','27','1.00','0.00','4','0','2000.00','FPZ5831430113535','0.00','0.00','0','0','0','0','','1430113535','106.39.13.15','2','1430113535','0.00','1','2','25036029','123456','2001.00','1430113603','','1430150400','cs415419597','0','','','','');/* DBReback Separation */ 
 /* 数据表结构 `lzh_shares_global`*/ 
 DROP TABLE IF EXISTS `lzh_shares_global`;/* DBReback Separation */ 
 CREATE TABLE `lzh_shares_global` (
  `id` smallint(6) NOT NULL AUTO_INCREMENT,
  `type` varchar(10) NOT NULL COMMENT '标签类型',
  `text` text NOT NULL COMMENT '参数内容',
  `name` varchar(50) NOT NULL DEFAULT ' ' COMMENT '参数标题',
  `tip` varchar(200) NOT NULL DEFAULT ' ' COMMENT '参数提示',
  `order_sn` int(11) NOT NULL DEFAULT '0' COMMENT '是否为系统参数',
  `code` varchar(20) NOT NULL DEFAULT ' ' COMMENT '参数标识',
  `is_sys` tinyint(3) unsigned NOT NULL DEFAULT '0' COMMENT '排序',
  `type_id` int(11) NOT NULL COMMENT '类型id',
  `times_type` tinyint(4) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=150 DEFAULT CHARSET=utf8;/* DBReback Separation */
 /* 插入数据 `lzh_shares_global` */
 INSERT INTO `lzh_shares_global` VALUES ('144','input','6|1.2|30|40','6倍参数配置','6|1.2|40|30，表示6倍杠杆，1.2利率，平仓比率为40%，警戒线比率为30%。','6','Six','0','1','1');/* DBReback Separation */
 /* 插入数据 `lzh_shares_global` */
 INSERT INTO `lzh_shares_global` VALUES ('145','input','7|1.2|30|40','7倍参数配置','7|1.2|40|30，表示7倍杠杆，1.2利率，平仓比率为40%，警戒线比率为30%。','7','Seven','0','1','1');/* DBReback Separation */
 /* 插入数据 `lzh_shares_global` */
 INSERT INTO `lzh_shares_global` VALUES ('142','input','3|1.2|30|40','3倍参数配置','3|1.5|40|30，表示3倍杠杆，每天千分之1.2利率，平仓比率为40%，警戒线比率为30%(Ten)(twenty)','3','Three','0','1','1');/* DBReback Separation */
 /* 插入数据 `lzh_shares_global` */
 INSERT INTO `lzh_shares_global` VALUES ('126','input','2|30','设置配资天数','2|30，表示2天到30天','0','days','0','1','0');/* DBReback Separation */
 /* 插入数据 `lzh_shares_global` */
 INSERT INTO `lzh_shares_global` VALUES ('129','input','400000','最高本金','用户可以用于配资的最高本金','0','cps_2','0','3','0');/* DBReback Separation */
 /* 插入数据 `lzh_shares_global` */
 INSERT INTO `lzh_shares_global` VALUES ('128','input','2000','最低本金','用户可以用于配资的最低本金','1','cps_1','0','3','0');/* DBReback Separation */
 /* 插入数据 `lzh_shares_global` */
 INSERT INTO `lzh_shares_global` VALUES ('130','input','5','杆杆倍率参数配置','本金*杆杆倍数=配资金额','0','cps_3','0','3','0');/* DBReback Separation */
 /* 插入数据 `lzh_shares_global` */
 INSERT INTO `lzh_shares_global` VALUES ('131','input','60','亏损警戒线比率','% &nbsp;&nbsp; 亏损警戒线 = 亏损警戒线比率*分险保证金+配资金额','0','cps_4','0','3','0');/* DBReback Separation */
 /* 插入数据 `lzh_shares_global` */
 INSERT INTO `lzh_shares_global` VALUES ('132','input','40','平仓线比率','% &nbsp;&nbsp;平仓线 = 平仓线比率*分险保证金+配资金额','0','cps_5','0','3','0');/* DBReback Separation */
 /* 插入数据 `lzh_shares_global` */
 INSERT INTO `lzh_shares_global` VALUES ('133','input','10','投资日期','允许用户投资的时间限制','0','cps_6','0','3','0');/* DBReback Separation */
 /* 插入数据 `lzh_shares_global` */
 INSERT INTO `lzh_shares_global` VALUES ('134','input','1000','最小配资金额设置','1000，表示最小配资金额为1000元','0','Match_small','0','1','0');/* DBReback Separation */
 /* 插入数据 `lzh_shares_global` */
 INSERT INTO `lzh_shares_global` VALUES ('135','input','1000000','最大配资金额设置','1000000,表示最大配资金额为1000000元','0','Match_big','0','1','0');/* DBReback Separation */
 /* 插入数据 `lzh_shares_global` */
 INSERT INTO `lzh_shares_global` VALUES ('136','input','3|7','分成比例','3|7  意为平台分成3成用户得7成','0','cps_7','0','3','0');/* DBReback Separation */
 /* 插入数据 `lzh_shares_global` */
 INSERT INTO `lzh_shares_global` VALUES ('143','input','5|1.2|30|40','5倍参数配置','5|1.2|40|30，表示5倍杠杆，1.2利率，平仓比率为40%，警戒线比率为30%。','5','Five','0','1','1');/* DBReback Separation */
 /* 插入数据 `lzh_shares_global` */
 INSERT INTO `lzh_shares_global` VALUES ('141','input','2|1.2|30|40','2倍参数配置','2|1.5|40|30，表示2倍杠杆，每天千分之1.2利率，平仓比率为40%，警戒线比率为30%(Ten)','2','two','0','1','1');/* DBReback Separation */
 /* 插入数据 `lzh_shares_global` */
 INSERT INTO `lzh_shares_global` VALUES ('140','input','1|1.2|30|40','1倍参数配置','1|1.2|40|30，表示1倍杠杆，每天千分之1.2利率，平仓比率为40%，警戒线比率为30%','1','one','0','1','1');/* DBReback Separation */
 /* 插入数据 `lzh_shares_global` */
 INSERT INTO `lzh_shares_global` VALUES ('146','input','8|1.2|30|40','8倍参数配置','8|1.2|40|30，表示8倍杠杆，1.2利率，平仓比率为40%，警戒线比率为30%。','8','Eight','0','1','1');/* DBReback Separation */
 /* 插入数据 `lzh_shares_global` */
 INSERT INTO `lzh_shares_global` VALUES ('147','input','9|1.2|30|40','9倍参数配置','9|1.2|40|30，表示9倍杠杆，1.2利率，平仓比率为40%，警戒线比率为30%。','9','Nine','0','1','1');/* DBReback Separation */
 /* 插入数据 `lzh_shares_global` */
 INSERT INTO `lzh_shares_global` VALUES ('148','input','10|1.2|30|40','10倍参数配置','10|1.2|40|30表示10倍杠杆，每天1.2%利率，平仓比率为40%，警戒线比率为30%','10','Ten','0','1','1');/* DBReback Separation */ 
 /* 数据表结构 `lzh_shares_holiday`*/ 
 DROP TABLE IF EXISTS `lzh_shares_holiday`;/* DBReback Separation */ 
 CREATE TABLE `lzh_shares_holiday` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `from_date` varchar(12) NOT NULL COMMENT '节假日开始日',
  `to_date` varchar(12) NOT NULL COMMENT '节假日结束日',
  `info` varchar(50) NOT NULL COMMENT '说明',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='股票配资节假日表 ';/* DBReback Separation */ 
 /* 数据表结构 `lzh_shares_lever`*/ 
 DROP TABLE IF EXISTS `lzh_shares_lever`;/* DBReback Separation */ 
 CREATE TABLE `lzh_shares_lever` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `type_id` int(11) NOT NULL COMMENT '类型id',
  `lever_ratio` int(3) NOT NULL COMMENT '杠杆比率',
  `manage_rate` float NOT NULL COMMENT '管理费率',
  `open_ratio` float NOT NULL COMMENT '亏损线平仓比率',
  `alert_ratio` float NOT NULL COMMENT '亏损警戒线比率',
  `status` tinyint(1) NOT NULL COMMENT '杠杆状态 1开放 2关闭 3不开放',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=2 DEFAULT CHARSET=utf8 COMMENT='配资杠杆表';/* DBReback Separation */
 /* 插入数据 `lzh_shares_lever` */
 INSERT INTO `lzh_shares_lever` VALUES ('1','2','5','0','7','10','1');/* DBReback Separation */ 
 /* 数据表结构 `lzh_shares_rateconfig`*/ 
 DROP TABLE IF EXISTS `lzh_shares_rateconfig`;/* DBReback Separation */ 
 CREATE TABLE `lzh_shares_rateconfig` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `start_month` varchar(2) NOT NULL,
  `end_month` varchar(2) NOT NULL,
  `rate_config` varchar(200) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=19 DEFAULT CHARSET=utf8;/* DBReback Separation */
 /* 插入数据 `lzh_shares_rateconfig` */
 INSERT INTO `lzh_shares_rateconfig` VALUES ('15','1','2','1-1000,1.8|1001-2000,1.7|2001-5000,1.6|5001-999999999,1.5');/* DBReback Separation */
 /* 插入数据 `lzh_shares_rateconfig` */
 INSERT INTO `lzh_shares_rateconfig` VALUES ('16','3','4','1-1000,1.8|1001-2000,1.7|2001-5000,1.6|5001-999999999,1.5');/* DBReback Separation */
 /* 插入数据 `lzh_shares_rateconfig` */
 INSERT INTO `lzh_shares_rateconfig` VALUES ('17','5','6','1-1000,1.8|1001-2000,1.7|2001-5000,1.6|5001-999999999,1.5');/* DBReback Separation */
 /* 插入数据 `lzh_shares_rateconfig` */
 INSERT INTO `lzh_shares_rateconfig` VALUES ('18','7','8','1-1000,1.8|1001-2000,1.7|2001-5000,1.6|5001-999999999,1.5');/* DBReback Separation */ 
 /* 数据表结构 `lzh_shares_record`*/ 
 DROP TABLE IF EXISTS `lzh_shares_record`;/* DBReback Separation */ 
 CREATE TABLE `lzh_shares_record` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `shares_id` int(11) NOT NULL COMMENT '股票配额id',
  `uid` int(11) NOT NULL COMMENT '用户id',
  `profit_loss` decimal(10,2) NOT NULL COMMENT '盈亏',
  `add_time` int(11) NOT NULL COMMENT '添加时间',
  `type_id` int(11) NOT NULL COMMENT '类型id',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COMMENT='配额记录表';/* DBReback Separation */ 
 /* 数据表结构 `lzh_shares_supply`*/ 
 DROP TABLE IF EXISTS `lzh_shares_supply`;/* DBReback Separation */ 
 CREATE TABLE `lzh_shares_supply` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `uid` int(11) NOT NULL COMMENT '用户id',
  `supply_money` decimal(10,2) NOT NULL COMMENT '申请补充金额',
  `type_id` int(11) NOT NULL COMMENT '类型 天/月/操盘手',
  `shares_id` int(11) NOT NULL COMMENT '配资id',
  `add_time` int(11) NOT NULL COMMENT '添加时间',
  `status` tinyint(1) NOT NULL COMMENT '状态 1等待审核 2审核通过 3审核未通',
  `u_name` varchar(50) DEFAULT NULL COMMENT '用户名',
  `order` varchar(50) DEFAULT NULL COMMENT '配资订单号',
  `examine_time` int(11) DEFAULT NULL COMMENT '审核时间',
  `info` varchar(200) DEFAULT NULL COMMENT '审核说明',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;/* DBReback Separation */ 
 /* 数据表结构 `lzh_shares_type`*/ 
 DROP TABLE IF EXISTS `lzh_shares_type`;/* DBReback Separation */ 
 CREATE TABLE `lzh_shares_type` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(50) NOT NULL COMMENT '类型名',
  `type` tinyint(2) NOT NULL COMMENT '类别 1天 2月 3免息',
  `introduction` varchar(2000) DEFAULT NULL COMMENT '简介',
  `explain` varchar(2000) DEFAULT NULL COMMENT '说明',
  `notice` varchar(2000) DEFAULT NULL COMMENT '操盘须知',
  `term` varchar(20) DEFAULT NULL COMMENT '月数范围',
  `money` varchar(50) DEFAULT NULL COMMENT '金额范围',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=5 DEFAULT CHARSET=utf8 COMMENT='配资类型表';/* DBReback Separation */
 /* 插入数据 `lzh_shares_type` */
 INSERT INTO `lzh_shares_type` VALUES ('1','天天配','1','按天配资','按天配资','按天配资','','');/* DBReback Separation */
 /* 插入数据 `lzh_shares_type` */
 INSERT INTO `lzh_shares_type` VALUES ('2','月月配','2','按月配资','按月配资','按月配资','1|6','1000|1500000');/* DBReback Separation */
 /* 插入数据 `lzh_shares_type` */
 INSERT INTO `lzh_shares_type` VALUES ('3','操盘手','3','操盘手免利息','操盘手免利息','操盘手免利息','','');/* DBReback Separation */
 /* 插入数据 `lzh_shares_type` */
 INSERT INTO `lzh_shares_type` VALUES ('4','免费体验','4','免费体验','免费体验','免费体验','','');/* DBReback Separation */ 
 /* 数据表结构 `lzh_smslog`*/ 
 DROP TABLE IF EXISTS `lzh_smslog`;/* DBReback Separation */ 
 CREATE TABLE `lzh_smslog` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `admin_id` int(11) NOT NULL,
  `admin_real_name` varchar(50) NOT NULL,
  `user_name` varchar(50) NOT NULL,
  `user_email` varchar(50) NOT NULL,
  `user_phone` varchar(50) NOT NULL,
  `title` varchar(20) NOT NULL,
  `content` varchar(500) NOT NULL,
  `add_time` int(10) NOT NULL DEFAULT '0',
  `is_inner` int(4) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=2 DEFAULT CHARSET=utf8;/* DBReback Separation */
 /* 插入数据 `lzh_smslog` */
 INSERT INTO `lzh_smslog` VALUES ('1','113','admin','whttcy','','13611012678','你好，测试下','你好，测试下','1429841925','1');/* DBReback Separation */ 
 /* 数据表结构 `lzh_sys_tip`*/ 
 DROP TABLE IF EXISTS `lzh_sys_tip`;/* DBReback Separation */ 
 CREATE TABLE `lzh_sys_tip` (
  `uid` int(10) unsigned NOT NULL,
  `tipset` varchar(300) NOT NULL,
  PRIMARY KEY (`uid`),
  KEY `tipset` (`tipset`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;/* DBReback Separation */ 
 /* 数据表结构 `lzh_today_reward`*/ 
 DROP TABLE IF EXISTS `lzh_today_reward`;/* DBReback Separation */ 
 CREATE TABLE `lzh_today_reward` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `borrow_id` int(10) unsigned NOT NULL,
  `reward_uid` int(10) unsigned NOT NULL,
  `invest_money` decimal(15,2) unsigned NOT NULL,
  `reward_money` decimal(10,2) unsigned NOT NULL,
  `reward_status` tinyint(3) unsigned NOT NULL DEFAULT '0',
  `add_time` int(10) NOT NULL,
  `deal_time` int(10) NOT NULL,
  `add_ip` varchar(20) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;/* DBReback Separation */ 
 /* 数据表结构 `lzh_transfer_borrow_info`*/ 
 DROP TABLE IF EXISTS `lzh_transfer_borrow_info`;/* DBReback Separation */ 
 CREATE TABLE `lzh_transfer_borrow_info` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `borrow_name` varchar(50) NOT NULL,
  `borrow_uid` int(11) NOT NULL,
  `borrow_duration` tinyint(3) unsigned NOT NULL,
  `borrow_money` decimal(15,2) NOT NULL,
  `borrow_interest` decimal(15,2) NOT NULL,
  `borrow_interest_rate` decimal(5,2) NOT NULL,
  `repayment_money` decimal(15,2) NOT NULL,
  `repayment_interest` decimal(15,2) NOT NULL,
  `repayment_type` tinyint(3) unsigned NOT NULL,
  `borrow_status` tinyint(3) unsigned NOT NULL,
  `transfer_out` int(10) NOT NULL,
  `transfer_back` int(10) unsigned NOT NULL,
  `transfer_total` int(10) NOT NULL,
  `per_transfer` int(10) NOT NULL,
  `add_time` int(10) NOT NULL,
  `deadline` int(10) unsigned NOT NULL,
  `add_ip` varchar(16) NOT NULL,
  `deal_user` int(10) unsigned NOT NULL,
  `deal_time` int(10) unsigned NOT NULL,
  `deal_info` varchar(500) NOT NULL,
  `borrow_info` varchar(2000) NOT NULL,
  `ensure_department` varchar(10) NOT NULL,
  `updata` varchar(2000) NOT NULL,
  `progress` tinyint(3) unsigned NOT NULL,
  `total` tinyint(4) NOT NULL,
  `is_show` tinyint(4) NOT NULL DEFAULT '1',
  `min_month` tinyint(4) NOT NULL DEFAULT '0',
  `reward_rate` float(5,2) NOT NULL DEFAULT '0.00' COMMENT '网站奖励(每月)',
  `increase_rate` float(5,2) NOT NULL DEFAULT '0.00' COMMENT '每月增加年利率',
  `borrow_fee` decimal(15,2) NOT NULL COMMENT '借款管理费',
  `level_can` tinyint(3) NOT NULL DEFAULT '0' COMMENT '0:允许普通会员投标；1:只允许VIP投标',
  `borrow_min` int(11) NOT NULL COMMENT '最低投标额度',
  `borrow_max` int(11) NOT NULL COMMENT '最高投标额度',
  `danbao` int(15) NOT NULL COMMENT '担保机构',
  `is_tuijian` tinyint(3) NOT NULL DEFAULT '0' COMMENT '是否设为推荐标 0表示不推荐；1表示推荐',
  `borrow_type` int(11) NOT NULL DEFAULT '6' COMMENT '刘',
  `b_img` varchar(200) NOT NULL COMMENT '流转标展示图片',
  `collect_day` int(10) NOT NULL COMMENT '允许投标的期限',
  `is_auto` tinyint(3) NOT NULL DEFAULT '0' COMMENT '是否允许自动投标 0：否；1：是。',
  `huilv` float NOT NULL,
  PRIMARY KEY (`id`),
  KEY `borrow_uid` (`borrow_uid`,`borrow_status`) USING BTREE,
  KEY `borrow_status` (`is_show`) USING BTREE
) ENGINE=InnoDB DEFAULT CHARSET=utf8;/* DBReback Separation */ 
 /* 数据表结构 `lzh_transfer_borrow_info_lock`*/ 
 DROP TABLE IF EXISTS `lzh_transfer_borrow_info_lock`;/* DBReback Separation */ 
 CREATE TABLE `lzh_transfer_borrow_info_lock` (
  `id` int(10) NOT NULL AUTO_INCREMENT,
  `suo` int(10) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;/* DBReback Separation */ 
 /* 数据表结构 `lzh_transfer_borrow_investor`*/ 
 DROP TABLE IF EXISTS `lzh_transfer_borrow_investor`;/* DBReback Separation */ 
 CREATE TABLE `lzh_transfer_borrow_investor` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `status` tinyint(3) unsigned NOT NULL DEFAULT '0',
  `borrow_id` int(10) unsigned NOT NULL,
  `investor_uid` int(10) unsigned NOT NULL,
  `borrow_uid` int(11) NOT NULL,
  `investor_capital` decimal(15,2) NOT NULL,
  `investor_interest` decimal(15,2) NOT NULL,
  `invest_fee` decimal(15,2) NOT NULL,
  `receive_capital` decimal(15,2) NOT NULL,
  `receive_interest` decimal(15,2) NOT NULL,
  `add_time` int(10) unsigned NOT NULL,
  `deadline` int(10) unsigned NOT NULL,
  `is_auto` tinyint(3) unsigned NOT NULL DEFAULT '0',
  `reward_money` decimal(15,2) NOT NULL,
  `transfer_num` int(10) unsigned NOT NULL DEFAULT '0',
  `transfer_month` int(10) unsigned NOT NULL DEFAULT '0',
  `back_time` int(10) unsigned NOT NULL,
  `final_interest_rate` float(5,2) NOT NULL DEFAULT '0.00',
  PRIMARY KEY (`id`),
  KEY `investor_uid` (`investor_uid`,`status`) USING BTREE,
  KEY `borrow_id` (`borrow_id`,`investor_uid`,`status`) USING BTREE,
  KEY `deadline` (`deadline`,`status`) USING BTREE
) ENGINE=InnoDB DEFAULT CHARSET=utf8;/* DBReback Separation */ 
 /* 数据表结构 `lzh_transfer_detail`*/ 
 DROP TABLE IF EXISTS `lzh_transfer_detail`;/* DBReback Separation */ 
 CREATE TABLE `lzh_transfer_detail` (
  `borrow_id` int(10) unsigned NOT NULL,
  `borrow_breif` varchar(2000) NOT NULL,
  `borrow_capital` varchar(2000) NOT NULL,
  `borrow_use` varchar(2000) NOT NULL,
  `borrow_risk` varchar(2000) NOT NULL,
  `borrow_guarantee` varchar(50) NOT NULL,
  `borrow_img` varchar(2000) NOT NULL,
  PRIMARY KEY (`borrow_id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;/* DBReback Separation */ 
 /* 数据表结构 `lzh_transfer_investor_detail`*/ 
 DROP TABLE IF EXISTS `lzh_transfer_investor_detail`;/* DBReback Separation */ 
 CREATE TABLE `lzh_transfer_investor_detail` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `repayment_time` int(10) unsigned NOT NULL DEFAULT '0',
  `borrow_id` int(10) unsigned NOT NULL,
  `invest_id` int(10) unsigned NOT NULL,
  `investor_uid` int(10) unsigned NOT NULL,
  `borrow_uid` int(10) unsigned NOT NULL,
  `capital` decimal(15,2) NOT NULL,
  `interest` decimal(15,2) NOT NULL,
  `interest_fee` decimal(15,2) NOT NULL,
  `status` tinyint(3) unsigned NOT NULL,
  `receive_interest` decimal(15,2) NOT NULL,
  `receive_capital` decimal(15,2) NOT NULL,
  `sort_order` tinyint(3) unsigned NOT NULL,
  `total` tinyint(3) unsigned NOT NULL,
  `deadline` int(10) unsigned NOT NULL,
  `expired_money` decimal(15,2) NOT NULL,
  `expired_days` tinyint(3) unsigned NOT NULL DEFAULT '0',
  `call_fee` decimal(5,2) NOT NULL,
  `substitute_money` decimal(15,2) NOT NULL,
  `substitute_time` int(10) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `invest_id` (`invest_id`,`status`,`deadline`) USING BTREE,
  KEY `borrow_id` (`borrow_id`,`sort_order`,`investor_uid`) USING BTREE
) ENGINE=InnoDB DEFAULT CHARSET=utf8;/* DBReback Separation */ 
 /* 数据表结构 `lzh_verify`*/ 
 DROP TABLE IF EXISTS `lzh_verify`;/* DBReback Separation */ 
 CREATE TABLE `lzh_verify` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `code` varchar(32) NOT NULL,
  `send_time` int(10) NOT NULL,
  `ukey` int(10) unsigned NOT NULL,
  `type` tinyint(3) unsigned NOT NULL COMMENT '1:邮件激活验证',
  PRIMARY KEY (`id`),
  KEY `code` (`ukey`,`type`,`send_time`,`code`)
) ENGINE=MyISAM AUTO_INCREMENT=64 DEFAULT CHARSET=utf8;/* DBReback Separation */
 /* 插入数据 `lzh_verify` */
 INSERT INTO `lzh_verify` VALUES ('1','RzsgYzOhlShDxkuEjWvfwKLAOELdNblu','1429779038','3','1');/* DBReback Separation */
 /* 插入数据 `lzh_verify` */
 INSERT INTO `lzh_verify` VALUES ('2','dqiMMOhWuZSYfsrQzOjgbrYLYwTQanDg','1429780268','4','1');/* DBReback Separation */
 /* 插入数据 `lzh_verify` */
 INSERT INTO `lzh_verify` VALUES ('3','jFQzSJjcYdUtBTOwRHWsHaItNLonwdFd','1429780270','4','1');/* DBReback Separation */
 /* 插入数据 `lzh_verify` */
 INSERT INTO `lzh_verify` VALUES ('4','iSOKywBwsQpXMaZjhtpgHhfdEePEAqAo','1429780271','4','1');/* DBReback Separation */
 /* 插入数据 `lzh_verify` */
 INSERT INTO `lzh_verify` VALUES ('5','AOxBkUXjjciHPKQrnaOfWSlljImZwhip','1429780274','4','1');/* DBReback Separation */
 /* 插入数据 `lzh_verify` */
 INSERT INTO `lzh_verify` VALUES ('6','JyVTMkIiYVKlSFpNsLhLGTjZnroXqUKV','1429780284','4','1');/* DBReback Separation */
 /* 插入数据 `lzh_verify` */
 INSERT INTO `lzh_verify` VALUES ('7','frAEmdhGDgCXlsViRMKHtdqHeMWjSzfB','1429780285','4','1');/* DBReback Separation */
 /* 插入数据 `lzh_verify` */
 INSERT INTO `lzh_verify` VALUES ('8','OTHVdoubMtmxOIycKAXnLyEYfMHRhrhk','1429780287','4','1');/* DBReback Separation */
 /* 插入数据 `lzh_verify` */
 INSERT INTO `lzh_verify` VALUES ('9','bhybJmYvTmvoHKIFLpFEXIpchaSTJHDu','1429780333','4','1');/* DBReback Separation */
 /* 插入数据 `lzh_verify` */
 INSERT INTO `lzh_verify` VALUES ('10','391038','1429780383','4','2');/* DBReback Separation */
 /* 插入数据 `lzh_verify` */
 INSERT INTO `lzh_verify` VALUES ('11','qcYOLAhCwxfkpramtDJaiiHSddzWWhCj','1429780408','4','1');/* DBReback Separation */
 /* 插入数据 `lzh_verify` */
 INSERT INTO `lzh_verify` VALUES ('12','nTrZWKzXdGkzjwGchDYAFHjblXYgVORS','1429780595','4','1');/* DBReback Separation */
 /* 插入数据 `lzh_verify` */
 INSERT INTO `lzh_verify` VALUES ('13','zAIcOebvxvbCaiaUSRfQpJFYNvTuJCWC','1429781235','4','1');/* DBReback Separation */
 /* 插入数据 `lzh_verify` */
 INSERT INTO `lzh_verify` VALUES ('14','huvVrCwHyAkbQkTaUhZrGyeQODwwqqnG','1429781237','4','1');/* DBReback Separation */
 /* 插入数据 `lzh_verify` */
 INSERT INTO `lzh_verify` VALUES ('15','EMNkYMAXwugPlAhuxUEGJoAGaSjxtwSL','1429781238','4','1');/* DBReback Separation */
 /* 插入数据 `lzh_verify` */
 INSERT INTO `lzh_verify` VALUES ('16','rZgaMhlRAvUrfkmnFzdgmIZKQClEPeYE','1429781246','4','1');/* DBReback Separation */
 /* 插入数据 `lzh_verify` */
 INSERT INTO `lzh_verify` VALUES ('17','SGGMQKmpnecgwPgaPnSEOCtjSjVkMFRK','1429781247','4','1');/* DBReback Separation */
 /* 插入数据 `lzh_verify` */
 INSERT INTO `lzh_verify` VALUES ('18','GgoshwRGEUIwIiRahrSZnLwmLiEflVXk','1429781248','4','1');/* DBReback Separation */
 /* 插入数据 `lzh_verify` */
 INSERT INTO `lzh_verify` VALUES ('19','eZgDcySWrYQSfuLUyDBTmvpfnCPkSsfY','1429781249','4','1');/* DBReback Separation */
 /* 插入数据 `lzh_verify` */
 INSERT INTO `lzh_verify` VALUES ('20','qBFmSaHklYjkYYjjrXDyVAHCCDNFBcxI','1429781255','4','1');/* DBReback Separation */
 /* 插入数据 `lzh_verify` */
 INSERT INTO `lzh_verify` VALUES ('21','YXYeVQjMVNnjBjrruOCIXCKzJOYLdtmI','1429781256','4','1');/* DBReback Separation */
 /* 插入数据 `lzh_verify` */
 INSERT INTO `lzh_verify` VALUES ('22','bPCqgwxYqoKBVdjhFNzePeWFIjXJxrxV','1429781393','4','1');/* DBReback Separation */
 /* 插入数据 `lzh_verify` */
 INSERT INTO `lzh_verify` VALUES ('23','AuHXranYeAgoyXCmSVsxhFxbNOyMjlot','1429781403','5','1');/* DBReback Separation */
 /* 插入数据 `lzh_verify` */
 INSERT INTO `lzh_verify` VALUES ('24','mQBIuwvJgOGocONDHlbjDCBZKvMPjVKE','1429781771','4','1');/* DBReback Separation */
 /* 插入数据 `lzh_verify` */
 INSERT INTO `lzh_verify` VALUES ('25','390567','1429781858','5','2');/* DBReback Separation */
 /* 插入数据 `lzh_verify` */
 INSERT INTO `lzh_verify` VALUES ('26','HhMuTqJpXuXfxxiasFSermOoJPIkXAOA','1429781902','5','1');/* DBReback Separation */
 /* 插入数据 `lzh_verify` */
 INSERT INTO `lzh_verify` VALUES ('27','gMKeEbKXtEqCDoAwKmycHpiHkRbokJRe','1429782004','5','1');/* DBReback Separation */
 /* 插入数据 `lzh_verify` */
 INSERT INTO `lzh_verify` VALUES ('28','eWlbbCQcCBKSLDjHzxFsilJpSoktdAVi','1429782483','5','1');/* DBReback Separation */
 /* 插入数据 `lzh_verify` */
 INSERT INTO `lzh_verify` VALUES ('29','lPZeYGbPoEhitKnnSGAmCgOOyMzieFWX','1429782485','5','1');/* DBReback Separation */
 /* 插入数据 `lzh_verify` */
 INSERT INTO `lzh_verify` VALUES ('30','iJAWGglKkUIxIXzycOUHumwnyPaWqWba','1429782903','4','1');/* DBReback Separation */
 /* 插入数据 `lzh_verify` */
 INSERT INTO `lzh_verify` VALUES ('31','BiYvpJphijKXwNjIkqUOulwmRErReyWW','1429783108','5','1');/* DBReback Separation */
 /* 插入数据 `lzh_verify` */
 INSERT INTO `lzh_verify` VALUES ('32','oxviYSLHZthfszfbIZdzBbCSenpAjlWh','1429783110','5','1');/* DBReback Separation */
 /* 插入数据 `lzh_verify` */
 INSERT INTO `lzh_verify` VALUES ('33','zIypheHDlPGoLxQAGhtlrbwcLDdHZvuw','1429783111','5','1');/* DBReback Separation */
 /* 插入数据 `lzh_verify` */
 INSERT INTO `lzh_verify` VALUES ('34','ncGRhrhgjAwGzmkddjkVzpsurgxXRVOw','1429783115','5','1');/* DBReback Separation */
 /* 插入数据 `lzh_verify` */
 INSERT INTO `lzh_verify` VALUES ('35','eXfQvLstNzpbjasbXlCugudtlcphSNVm','1429783116','5','1');/* DBReback Separation */
 /* 插入数据 `lzh_verify` */
 INSERT INTO `lzh_verify` VALUES ('36','tSGXcBIbpZDdvexMVQdkkaJjKtsHjbDN','1429783117','5','1');/* DBReback Separation */
 /* 插入数据 `lzh_verify` */
 INSERT INTO `lzh_verify` VALUES ('37','RZEnLvwgwtQujTCZiHdrMbIlSVYCoxdm','1429783123','5','1');/* DBReback Separation */
 /* 插入数据 `lzh_verify` */
 INSERT INTO `lzh_verify` VALUES ('38','JIsHPQfaYcrDpDrODKESGyJbaylWMRDX','1429785273','4','1');/* DBReback Separation */
 /* 插入数据 `lzh_verify` */
 INSERT INTO `lzh_verify` VALUES ('39','rQwjVkMGJSPwHAUjIzEnWJExZHEnLJzm','1429785331','4','1');/* DBReback Separation */
 /* 插入数据 `lzh_verify` */
 INSERT INTO `lzh_verify` VALUES ('40','zNQoqmfByWOrfjvESnfUMwGLEqaJaHem','1429788095','2','1');/* DBReback Separation */
 /* 插入数据 `lzh_verify` */
 INSERT INTO `lzh_verify` VALUES ('41','WDBRWcftJmmjphBLdUcUrimQufAqspdt','1429788102','2','1');/* DBReback Separation */
 /* 插入数据 `lzh_verify` */
 INSERT INTO `lzh_verify` VALUES ('42','mKTAwYAdUzJDAcUXoAufOQULZefBbnXz','1429793620','2','1');/* DBReback Separation */
 /* 插入数据 `lzh_verify` */
 INSERT INTO `lzh_verify` VALUES ('43','706540','1429840048','1','2');/* DBReback Separation */
 /* 插入数据 `lzh_verify` */
 INSERT INTO `lzh_verify` VALUES ('44','SSsiogLzWoIxvLkyUFEpnCkCInqIjjdT','1429844771','14','1');/* DBReback Separation */
 /* 插入数据 `lzh_verify` */
 INSERT INTO `lzh_verify` VALUES ('45','oKocpHBOxOimBEXmAGgYTSSLkQoVHRWs','1429844923','10','1');/* DBReback Separation */
 /* 插入数据 `lzh_verify` */
 INSERT INTO `lzh_verify` VALUES ('46','rjNomgtCGLxyHtrAOxeAQYfBLmTvKRwA','1429844993','19','1');/* DBReback Separation */
 /* 插入数据 `lzh_verify` */
 INSERT INTO `lzh_verify` VALUES ('47','AhWNwItUQaQALbgabxBqHCFPtpgzXxcv','1429845000','17','7');/* DBReback Separation */
 /* 插入数据 `lzh_verify` */
 INSERT INTO `lzh_verify` VALUES ('48','873527','1429845026','19','2');/* DBReback Separation */
 /* 插入数据 `lzh_verify` */
 INSERT INTO `lzh_verify` VALUES ('49','llQcynIBFEAjldyDuGNsCOlhGBpaPeQz','1429845102','13','1');/* DBReback Separation */
 /* 插入数据 `lzh_verify` */
 INSERT INTO `lzh_verify` VALUES ('50','QxqQdNOkJNqfYrgvtpjIoWESyFkTKpWL','1429845210','17','7');/* DBReback Separation */
 /* 插入数据 `lzh_verify` */
 INSERT INTO `lzh_verify` VALUES ('51','492351','1429845390','15','2');/* DBReback Separation */
 /* 插入数据 `lzh_verify` */
 INSERT INTO `lzh_verify` VALUES ('52','ewavYwdBTyyyefqntYJbPMfUbOLHSrDg','1429845397','22','1');/* DBReback Separation */
 /* 插入数据 `lzh_verify` */
 INSERT INTO `lzh_verify` VALUES ('53','VyEJTdBQHWygpHlcklbTQwXhncSAunSz','1429845410','15','1');/* DBReback Separation */
 /* 插入数据 `lzh_verify` */
 INSERT INTO `lzh_verify` VALUES ('54','NtmlEPgIURCiLvpCuBkxuHSJDQLAWvOK','1429845768','9','1');/* DBReback Separation */
 /* 插入数据 `lzh_verify` */
 INSERT INTO `lzh_verify` VALUES ('55','NhcnNSDReqPCiHAXbteOTzoCSFyRIqDg','1429846477','12','1');/* DBReback Separation */
 /* 插入数据 `lzh_verify` */
 INSERT INTO `lzh_verify` VALUES ('56','WGPZtaYwmejnuxaByNPkuDvVKnSrnREe','1429849764','3','1');/* DBReback Separation */
 /* 插入数据 `lzh_verify` */
 INSERT INTO `lzh_verify` VALUES ('57','QZdNeKySFYgZdsSXrINBEpbEurnRDUOe','1429849981','26','1');/* DBReback Separation */
 /* 插入数据 `lzh_verify` */
 INSERT INTO `lzh_verify` VALUES ('58','uIuUBytuFmplLywvYEzKNgIEmqCQjsLV','1429854686','16','1');/* DBReback Separation */
 /* 插入数据 `lzh_verify` */
 INSERT INTO `lzh_verify` VALUES ('59','DrdiMjWhEWVlXaPFtYDJFWzzQVsyAfbc','1429856657','31','1');/* DBReback Separation */
 /* 插入数据 `lzh_verify` */
 INSERT INTO `lzh_verify` VALUES ('60','DGWEkOXiHeRxxvqgjawzOFdfKUYzsyfc','1429856660','31','1');/* DBReback Separation */
 /* 插入数据 `lzh_verify` */
 INSERT INTO `lzh_verify` VALUES ('61','RfZeUlEcfWQetOeoBToiuEyXVSvMklhX','1429859280','8','1');/* DBReback Separation */
 /* 插入数据 `lzh_verify` */
 INSERT INTO `lzh_verify` VALUES ('62','BiIplXBzWQUTYbTYutUCkCpexnLfyBii','1429860599','34','1');/* DBReback Separation */
 /* 插入数据 `lzh_verify` */
 INSERT INTO `lzh_verify` VALUES ('63','GBwctOSllRPFNTGzrBcpiTvLQkrINALA','1429860947','34','1');/* DBReback Separation */ 
 /* 数据表结构 `lzh_video_apply`*/ 
 DROP TABLE IF EXISTS `lzh_video_apply`;/* DBReback Separation */ 
 CREATE TABLE `lzh_video_apply` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `uid` int(10) unsigned NOT NULL,
  `add_time` int(10) unsigned NOT NULL,
  `add_ip` varchar(16) NOT NULL,
  `apply_status` tinyint(3) unsigned NOT NULL DEFAULT '0',
  `credits` int(11) NOT NULL DEFAULT '0',
  `deal_user` int(10) unsigned NOT NULL,
  `deal_time` int(10) unsigned NOT NULL,
  `deal_info` varchar(50) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `uid` (`uid`,`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;/* DBReback Separation */ 
 /* 数据表结构 `lzh_vip_apply`*/ 
 DROP TABLE IF EXISTS `lzh_vip_apply`;/* DBReback Separation */ 
 CREATE TABLE `lzh_vip_apply` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `uid` int(10) unsigned NOT NULL,
  `kfid` int(10) unsigned NOT NULL,
  `province_now` int(10) unsigned NOT NULL,
  `city_now` int(11) NOT NULL,
  `area_now` int(11) NOT NULL,
  `des` varchar(1000) NOT NULL,
  `add_time` int(10) NOT NULL,
  `status` tinyint(3) unsigned NOT NULL,
  `deal_time` int(10) unsigned NOT NULL,
  `deal_user` int(10) unsigned NOT NULL,
  `deal_info` varchar(200) NOT NULL COMMENT '处理意见',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=12 DEFAULT CHARSET=utf8;/* DBReback Separation */
 /* 插入数据 `lzh_vip_apply` */
 INSERT INTO `lzh_vip_apply` VALUES ('1','4','113','0','0','0','我要借款','1429786029','1','1429839977','113','内部测试');/* DBReback Separation */
 /* 插入数据 `lzh_vip_apply` */
 INSERT INTO `lzh_vip_apply` VALUES ('2','17','113','0','0','0','申请vip','1429844661','1','1429844861','113','内部');/* DBReback Separation */
 /* 插入数据 `lzh_vip_apply` */
 INSERT INTO `lzh_vip_apply` VALUES ('3','10','113','0','0','0','听说投资的越多利息越高','1429844899','1','1429845810','113','通过');/* DBReback Separation */
 /* 插入数据 `lzh_vip_apply` */
 INSERT INTO `lzh_vip_apply` VALUES ('4','14','113','0','0','0','给我通过下 亲','1429844901','1','1429845778','113','通过');/* DBReback Separation */
 /* 插入数据 `lzh_vip_apply` */
 INSERT INTO `lzh_vip_apply` VALUES ('5','20','113','0','0','0','王辉','1429845124','1','1429845802','113','通过');/* DBReback Separation */
 /* 插入数据 `lzh_vip_apply` */
 INSERT INTO `lzh_vip_apply` VALUES ('6','13','113','0','0','0','郭呈','1429845323','1','1429845789','113','通过');/* DBReback Separation */
 /* 插入数据 `lzh_vip_apply` */
 INSERT INTO `lzh_vip_apply` VALUES ('7','15','113','0','0','0','融天下网贷系统南京分公司，售前彭红。申请VIP，请通过^^','1429845472','1','1429845783','113','通过');/* DBReback Separation */
 /* 插入数据 `lzh_vip_apply` */
 INSERT INTO `lzh_vip_apply` VALUES ('8','22','113','0','0','0','申请vip哟！','1429845787','1','1429845794','113','通过');/* DBReback Separation */
 /* 插入数据 `lzh_vip_apply` */
 INSERT INTO `lzh_vip_apply` VALUES ('9','3','113','0','0','0','ceshi','1429849631','1','1429850760','113','内部');/* DBReback Separation */
 /* 插入数据 `lzh_vip_apply` */
 INSERT INTO `lzh_vip_apply` VALUES ('10','9','113','0','0','0','申请vip','1429854435','1','1429855700','113','内部');/* DBReback Separation */
 /* 插入数据 `lzh_vip_apply` */
 INSERT INTO `lzh_vip_apply` VALUES ('11','16','113','0','0','0','wdssdfd','1429854565','1','1429855692','113','内部');/* DBReback Separation */